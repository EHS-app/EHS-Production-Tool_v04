--
-- PostgreSQL database dump
--

\restrict rbHzkvWaRJhHbJKN3mr29YobYrZeDwfEpg43rM9DZaYy0yZ2BMNFBPkm6psW31F

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.gigs DROP CONSTRAINT IF EXISTS gigs_brief_id_project_briefs_id_fk;
ALTER TABLE IF EXISTS ONLY public.brief_room_assignments DROP CONSTRAINT IF EXISTS brief_room_assignments_brief_id_project_briefs_id_fk;
ALTER TABLE IF EXISTS ONLY public.brief_assignments DROP CONSTRAINT IF EXISTS brief_assignments_brief_id_project_briefs_id_fk;
DROP INDEX IF EXISTS public.venue_memory_user_venue_key;
DROP INDEX IF EXISTS public.projects_user_id_idx;
DROP INDEX IF EXISTS public.project_briefs_owner_idx;
DROP INDEX IF EXISTS public.gigs_freelancer_idx;
DROP INDEX IF EXISTS public.gigs_brief_idx;
DROP INDEX IF EXISTS public.brief_assignments_freelancer_idx;
DROP INDEX IF EXISTS public.brief_assignments_brief_idx;
DROP INDEX IF EXISTS public.brief_assignments_brief_freelancer_unique;
ALTER TABLE IF EXISTS ONLY public.venue_memory DROP CONSTRAINT IF EXISTS venue_memory_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.project_briefs DROP CONSTRAINT IF EXISTS project_briefs_pkey;
ALTER TABLE IF EXISTS ONLY public.gigs DROP CONSTRAINT IF EXISTS gigs_pkey;
ALTER TABLE IF EXISTS ONLY public.freelancer_profiles DROP CONSTRAINT IF EXISTS freelancer_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.brief_room_assignments DROP CONSTRAINT IF EXISTS brief_room_assignments_brief_id_freelancer_user_id_pk;
ALTER TABLE IF EXISTS ONLY public.brief_assignments DROP CONSTRAINT IF EXISTS brief_assignments_pkey;
ALTER TABLE IF EXISTS public.venue_memory ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.venue_memory_id_seq;
DROP TABLE IF EXISTS public.venue_memory;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.project_briefs;
DROP TABLE IF EXISTS public.gigs;
DROP TABLE IF EXISTS public.freelancer_profiles;
DROP TABLE IF EXISTS public.brief_room_assignments;
DROP TABLE IF EXISTS public.brief_assignments;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brief_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brief_assignments (
    id text NOT NULL,
    brief_id text NOT NULL,
    freelancer_user_id text NOT NULL,
    crew_id text DEFAULT ''::text NOT NULL,
    decision text DEFAULT 'pending'::text NOT NULL,
    decided_at timestamp with time zone,
    accepted_snapshot jsonb,
    accepted_gig_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: brief_room_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.brief_room_assignments (
    brief_id text NOT NULL,
    freelancer_user_id text NOT NULL,
    room_key text NOT NULL,
    locked boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: freelancer_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.freelancer_profiles (
    user_id text NOT NULL,
    full_name text DEFAULT ''::text NOT NULL,
    phone text DEFAULT ''::text NOT NULL,
    primary_role text DEFAULT ''::text NOT NULL,
    city text DEFAULT ''::text NOT NULL,
    bio text DEFAULT ''::text NOT NULL,
    insurance text DEFAULT ''::text NOT NULL,
    dietary text DEFAULT ''::text NOT NULL,
    bank_account text DEFAULT ''::text NOT NULL,
    org_number text DEFAULT ''::text NOT NULL,
    languages text[] DEFAULT '{}'::text[] NOT NULL,
    skills text[] DEFAULT '{}'::text[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    email text DEFAULT ''::text NOT NULL,
    allergies text DEFAULT ''::text NOT NULL,
    work_types text[] DEFAULT '{}'::text[] NOT NULL,
    consoles text[] DEFAULT '{}'::text[] NOT NULL,
    certs text[] DEFAULT '{}'::text[] NOT NULL,
    room_share text DEFAULT 'either'::text NOT NULL,
    gender text DEFAULT ''::text NOT NULL
);


--
-- Name: gigs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gigs (
    id text NOT NULL,
    freelancer_user_id text NOT NULL,
    brief_id text,
    project_name text DEFAULT ''::text NOT NULL,
    client text DEFAULT ''::text NOT NULL,
    venue text DEFAULT ''::text NOT NULL,
    role text DEFAULT ''::text NOT NULL,
    start_date date,
    end_date date,
    hours numeric(8,2) DEFAULT '0'::numeric NOT NULL,
    rate numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    flat_fee numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'confirmed'::text NOT NULL,
    check_in jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    assigned_dates date[] DEFAULT '{}'::date[] NOT NULL,
    hotel_required boolean DEFAULT false NOT NULL,
    check_in_date date,
    check_out_date date,
    hotel_dates date[] DEFAULT '{}'::date[] NOT NULL
);


--
-- Name: project_briefs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_briefs (
    id text NOT NULL,
    owner_user_id text NOT NULL,
    project_name text DEFAULT ''::text NOT NULL,
    client text DEFAULT ''::text NOT NULL,
    venue text DEFAULT ''::text NOT NULL,
    start_date date,
    end_date date,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    name text DEFAULT 'Untitled'::text NOT NULL,
    venue text DEFAULT ''::text NOT NULL,
    client text DEFAULT ''::text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: venue_memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.venue_memory (
    id integer NOT NULL,
    user_id text NOT NULL,
    venue_name text NOT NULL,
    venue_key text NOT NULL,
    data jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: venue_memory_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.venue_memory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: venue_memory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.venue_memory_id_seq OWNED BY public.venue_memory.id;


--
-- Name: venue_memory id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.venue_memory ALTER COLUMN id SET DEFAULT nextval('public.venue_memory_id_seq'::regclass);


--
-- Data for Name: brief_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brief_assignments (id, brief_id, freelancer_user_id, crew_id, decision, decided_at, accepted_snapshot, accepted_gig_id, created_at, updated_at) FROM stdin;
e17229fa-2311-475f-b6e1-2fb42852f912	f7e128b5-2e51-4b4d-91a7-8722b43d6e87	demo-stagehand	crew-8b9eefdc-23cb-4203-aa32-167d72df0535	pending	\N	\N	\N	2026-05-03 19:33:11.910057+00	2026-05-03 19:33:11.910057+00
cc2a4f3f-c4d3-4437-9c29-b4f7cfb939b9	f7e128b5-2e51-4b4d-91a7-8722b43d6e87	demo-av-foh	crew-a5e23c47-7e62-42e3-8865-e952dfe19c57	pending	\N	\N	\N	2026-05-03 19:33:03.547669+00	2026-05-03 19:33:11.910057+00
efe6aa20-0eca-49f5-943e-7ef8f5a5c460	f7e128b5-2e51-4b4d-91a7-8722b43d6e87	demo-sound-foh	crew-8b7ba0ef-96c7-4164-be4e-b83bf99ecbe7	pending	\N	\N	\N	2026-05-03 19:33:09.553692+00	2026-05-03 19:33:11.910057+00
57c25ec6-a8f3-44d4-aadf-0927defae259	f7e128b5-2e51-4b4d-91a7-8722b43d6e87	demo-light-rigg	crew-ea1c822b-a9c9-49d5-879c-c2078f927133	pending	\N	\N	\N	2026-05-03 19:33:10.101614+00	2026-05-03 19:33:11.910057+00
d86e103a-6ba5-4943-9d37-9ec7d34155c9	f7e128b5-2e51-4b4d-91a7-8722b43d6e87	demo-sound-monitor	crew-d7a68d1c-bb5b-42d7-88a1-91365852dba6	pending	\N	\N	\N	2026-05-03 19:33:10.910228+00	2026-05-03 19:33:11.910057+00
869525de-abe0-4c6e-b554-c3ef06dd7cf3	a44275a4-9228-4fef-b1cf-66a3241c8209	seed-3XC9QRoB	crew-62401c1c-b11f-4c61-8a0f-8d36ee08a12c	pending	\N	\N	\N	2026-04-30 19:30:38.109612+00	2026-04-30 19:30:38.109612+00
fed34974-ff2b-4aa3-b125-ed2178f999f1	02eab1e5-ffca-4314-8c22-3d2265386b49	seed-3XC9QRoB	crew-c5d55939-37b0-4e6a-91d9-5384386e9a86	pending	\N	\N	\N	2026-05-03 18:15:23.362077+00	2026-05-03 18:18:11.432873+00
7c5813b7-953b-4b86-ba03-723ae9c2fcdd	dc7b3969-7250-4287-9084-378566012249	seed-3XC9QRoB	crew-35f6fba9-c135-462a-9001-4f54672254fa	pending	\N	\N	\N	2026-05-04 19:12:19.32551+00	2026-05-04 19:12:19.32551+00
e4adf183-6ceb-4c41-9ff2-6f8f6219d200	dc7b3969-7250-4287-9084-378566012249	demo-av-foh	crew-a1a2ce0e-a7b7-4573-8e37-43d145476a6b	pending	\N	\N	\N	2026-05-04 19:12:10.963874+00	2026-05-04 19:12:19.32551+00
2b2bd0ed-8832-47d7-a141-f492d5f7cbbd	dc7b3969-7250-4287-9084-378566012249	demo-sound-foh	crew-9735bf10-819d-42d3-a3e2-b32181b7bbf8	pending	\N	\N	\N	2026-05-04 19:12:12.275168+00	2026-05-04 19:12:19.32551+00
e3ee2b52-124d-458c-9fc6-2bff66fc1fa5	dc7b3969-7250-4287-9084-378566012249	demo-light-rigg	crew-56e876d6-965d-45e9-86e2-0ba934ebeed6	pending	\N	\N	\N	2026-05-04 19:12:15.800071+00	2026-05-04 19:12:19.32551+00
5609bb87-56b7-4c49-b44f-950b1bb4833e	dc7b3969-7250-4287-9084-378566012249	demo-sound-monitor	crew-47bb47ae-decf-4b47-9c73-5841b3c103e5	pending	\N	\N	\N	2026-05-04 19:12:17.06754+00	2026-05-04 19:12:19.32551+00
3b151b14-8692-480a-8f2e-372d2b9a3da0	dc7b3969-7250-4287-9084-378566012249	demo-stagehand	crew-7e4965cd-228a-4899-a639-0744518383c0	pending	\N	\N	\N	2026-05-04 19:12:18.481016+00	2026-05-04 19:12:19.32551+00
8e2238ad-ebcc-4cc2-bc1b-ff932fcc03d1	f7e128b5-2e51-4b4d-91a7-8722b43d6e87	seed-3XC9QRoB	crew-3602f446-140a-43dd-a6df-1ce30f9b1b95	pending	\N	\N	\N	2026-05-03 17:26:41.510684+00	2026-05-03 18:51:21.925345+00
\.


--
-- Data for Name: brief_room_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.brief_room_assignments (brief_id, freelancer_user_id, room_key, locked, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: freelancer_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.freelancer_profiles (user_id, full_name, phone, primary_role, city, bio, insurance, dietary, bank_account, org_number, languages, skills, created_at, updated_at, email, allergies, work_types, consoles, certs, room_share, gender) FROM stdin;
seed-3XC9QRoB	Sidebar Tester One		Lyd FOH	Oslo						{Norsk,English}	{"Lyd FOH","DiGiCo SD","Forklift G4 (NO)"}	2026-04-30 00:40:10.816369+00	2026-04-30 00:40:10.816369+00			{}	{}	{}	either	
demo-sound-monitor	Demo Sondre Monitor	+47 412 03 001	Lyd monitor	Oslo	Monitor engineer med 8 års erfaring fra festivaler og turné. Komfortabel med store IEM-pakker og RF-planlegging.		Vegetarianer			{Norsk,English}	{"Lyd monitor","DiGiCo SD","Yamaha CL/QL","In-ear monitoring",RF-koordinering}	2026-05-03 17:53:11.704274+00	2026-05-03 18:31:09.278064+00	sondre.demo@example.no	Nøtter	{"Lyd monitor",Systemtekniker}	{"DiGiCo SD12","DiGiCo SD10","Yamaha CL5"}	{"Førerkort B","Truckførerbevis T1"}	either	
demo-light-rigg	Demo Linnea Lysrigg	+47 412 03 002	Lys Rigg	Bergen	Lysrigger og høydeoperatør basert i Bergen. Erfaring fra arenaer, klubber og utendørsfestivaler.		Spiser alt			{Norsk}	{"Lys Rigg","Truss montering",Motorstyring,CAD-tegning,Højdesertifikat}	2026-05-03 17:53:11.704274+00	2026-05-03 18:31:13.567908+00	linnea.demo@example.no		{"Lys Rigg",Rigger}	{}	{Fallsikringskurs,"Personløfter B+G","Førerkort BE"}	either	
demo-stagehand	Demo Stian Stagehand	+47 412 03 003	Stagehand	Trondheim	Pålitelig stagehand med truckbevis. Kjent ansikt på Trondheim Spektrum og Olavshallen.		Halal			{Norsk}	{Stagehand,Backline,Lasting/lossing,"Truss bygg"}	2026-05-03 17:53:11.704274+00	2026-05-03 18:31:19.114367+00	stian.demo@example.no	Skalldyr	{Stagehand,"Backline tech"}	{}	{"Førerkort BE","Truckførerbevis T1-T4"}	either	
demo-sound-foh	Demo Frida FOH	+47 412 03 004	Lyd FOH	Oslo	FOH-mikser for både turnerende artister og festivaloppdrag. Snakker norsk og engelsk.		Veganer			{Norsk,English}	{"Lyd FOH","DiGiCo Quantum","Avid S6L",Systemtuning,Smaart,"Waves SoundGrid"}	2026-05-03 17:53:11.704274+00	2026-05-03 18:31:23.883738+00	frida.demo@example.no	Laktose	{"Lyd FOH",Systemtekniker}	{"DiGiCo Quantum 7","DiGiCo Quantum 338","Avid S6L-32D"}	{"Førerkort B"}	either	
demo-av-foh	Demo Anders AV	+47 412 03 005	AV FOH	Stavanger	AV-operatør med fokus på konferanser og corporate events. Erfaren med Disguise og live-streaming.		Glutenfri			{Norsk,English}	{"AV FOH",Disguise,Resolume,"Blackmagic ATEM",PPT/Keynote-operatør,Konferanse-AV}	2026-05-03 17:53:11.704274+00	2026-05-03 18:31:28.783773+00	anders.demo@example.no	Gluten	{"AV FOH","Video operator"}	{"Disguise 4x4pro","Blackmagic ATEM 4 M/E","Resolume Arena 7"}	{"Førerkort B"}	either	
\.


--
-- Data for Name: gigs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gigs (id, freelancer_user_id, brief_id, project_name, client, venue, role, start_date, end_date, hours, rate, flat_fee, notes, status, check_in, created_at, updated_at, assigned_dates, hotel_required, check_in_date, check_out_date, hotel_dates) FROM stdin;
\.


--
-- Data for Name: project_briefs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_briefs (id, owner_user_id, project_name, client, venue, start_date, end_date, data, created_at, updated_at) FROM stdin;
brief_Ownt3zjb	user_3Cx5qiY52TcaJowheSkwll49BRQ	Hotel Slice A Test AQyv	Test Client	Test Hall	2026-04-30	2026-05-02	{}	2026-04-30 19:09:50.371331+00	2026-04-30 19:10:13.605119+00
a44275a4-9228-4fef-b1cf-66a3241c8209	user_3Cx5qiY52TcaJowheSkwll49BRQ				2026-04-27	\N	{"led": {"screens": [{"id": "led-9qg749j", "cols": 5, "name": "IMAG", "rows": 3, "brackets": [{"name": "(set bracket on inventory)", "count": 15}], "panelType": "Uniview UR Pro 0.5x1m (10.8kg)", "powerCables": 14, "totalPanels": 15, "powerLengthM": 8.4, "signalCables": 14, "signalLengthM": 18.2, "estimatedWatts": 5250, "processorPixels": 491520, "processorOutputs": 0, "processorMaxPixels": 0}], "processor": "", "screenCount": 1, "totalPanels": 15}, "sound": {"rowCount": 0, "totalQty": 0, "byCategory": [], "totalPower": 0, "totalWeight": 0}, "stage": {"stages": [], "totalArea": 0, "stageCount": 0, "totalLoadCapacityKg": 0}, "briefId": "0db639ad2eac", "project": {"date": "2026-04-27", "venue": "", "client": "", "schedule": {"show": [{"to": "2026-04-27", "from": "2026-04-27"}]}, "preparedBy": ""}, "rigging": {"systems": [{"id": "sys-1-jhiy45", "name": "LX1", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 3, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 0, "riggingRowCount": 1}], "hoistCount": 3, "systemCount": 1, "totalMotorW": 2400}, "version": 1, "lighting": {"distros": [], "universes": [], "distroCount": 0, "circuitCount": 0, "fixtureCount": 0, "totalDistroW": 0, "totalCircuitW": 0, "worstCircuitPct": 0, "totalFixtureWatts": 0, "worstDistroFeederPct": 0}, "riggPlan": {"venue": {"depthM": 12, "widthM": 20, "ceilingM": 8}, "trusses": [{"x": 10, "y": 6, "z": 7.5, "x1": 7, "x2": 13, "y1": 6, "y2": 6, "lengthM": 6, "rotation": 0, "systemId": "sys-1-jhiy45", "systemName": "LX1"}]}, "assignments": [{"name": "Sidebar Tester One", "role": "Sound", "hours": 10, "notes": "", "crewId": "crew-62401c1c-b11f-4c61-8a0f-8d36ee08a12c", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "freelancerUserId": "seed-3XC9QRoB"}], "attachments": [], "generatedAt": 1777577437998, "recipientCrewId": null}	2026-04-30 19:30:38.109612+00	2026-04-30 19:30:38.109612+00
brief_18XFoRT2	user_3Cx5qiY52TcaJowheSkwll49BRQ	Pair Test mwsT		Test Venue	2026-05-10	2026-05-15	{}	2026-04-30 19:46:07.790396+00	2026-04-30 19:46:07.790396+00
02eab1e5-ffca-4314-8c22-3d2265386b49	user_3Cx5qiY52TcaJowheSkwll49BRQ	THE QUBE	TEST	THE QUBE	2026-05-07	2026-05-07	{"led": {"screens": [{"id": "led-r9klhh9", "cols": 32, "name": "Main Center", "rows": 6, "brackets": [{"name": "(set bracket on inventory)", "count": 192}], "panelType": "Uniview UR Pro 0.5x1m (10.8kg)", "powerCables": 191, "totalPanels": 192, "powerLengthM": 114.6, "signalCables": 191, "signalLengthM": 248.3, "estimatedWatts": 67200, "processorPixels": 6291456, "processorOutputs": 0, "processorMaxPixels": 0}, {"id": "led-1rybey0", "cols": 16, "name": "IMAG-R", "rows": 9, "brackets": [{"name": "(set bracket on inventory)", "count": 144}], "panelType": "Uniview UR Pro 0.5x1m (10.8kg)", "powerCables": 143, "totalPanels": 144, "powerLengthM": 85.8, "signalCables": 143, "signalLengthM": 185.9, "estimatedWatts": 50400, "processorPixels": 4718592, "processorOutputs": 0, "processorMaxPixels": 0}, {"id": "led-vtdvy7c", "cols": 16, "name": "IMAG-L", "rows": 9, "brackets": [{"name": "(set bracket on inventory)", "count": 144}], "panelType": "Uniview UR Pro 0.5x1m (10.8kg)", "powerCables": 143, "totalPanels": 144, "powerLengthM": 85.8, "signalCables": 143, "signalLengthM": 185.9, "estimatedWatts": 50400, "processorPixels": 4718592, "processorOutputs": 0, "processorMaxPixels": 0}], "processor": "Novastar MX40", "screenCount": 3, "totalPanels": 480}, "sound": {"rowCount": 0, "totalQty": 0, "byCategory": [], "totalPower": 0, "totalWeight": 0}, "stage": {"stages": [{"id": "91917fe9-b3da-4857-a0df-28a448a5495d", "area": 160, "name": "Stage 1", "depth": 8, "width": 20, "deckCounts": {"1x1": 0, "2x1": 80, "0.5x1": 0, "0.5x2": 0}, "legHeightCm": 100, "bracingNotes": ["Diagonal bracing required (≥ 80 cm)", "Handrails required (≥ 100 cm fall height)"], "loadCapacityKg": 84000}], "totalArea": 160, "stageCount": 1, "totalLoadCapacityKg": 84000}, "briefId": "2ce70095aa80", "project": {"date": "2026-05-07", "venue": "THE QUBE", "client": "TEST", "endDate": "2026-05-07", "schedule": {"show": [{"to": "2026-05-07", "from": "2026-05-07", "toTime": "23:00", "fromTime": "12:00"}], "setup": [{"to": "2026-05-04", "from": "2026-05-04", "toTime": "21:00", "fromTime": "09:00"}, {"to": "2026-05-05", "from": "2026-05-05", "toTime": "21:00", "fromTime": "09:00"}, {"to": "2026-05-06", "from": "2026-05-06", "toTime": "21:00", "fromTime": "09:00"}], "downrig": [{"to": "2026-05-08", "from": "2026-05-08", "toTime": "20:00", "fromTime": "09:00"}], "rehearsal": [{"to": "2026-05-07", "from": "2026-05-07", "toTime": "11:00", "fromTime": "09:00"}]}, "preparedBy": "Olti"}, "rigging": {"systems": [{"id": "sys-5-trf8a3", "name": "LX1", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 2, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 1, "riggingRowCount": 1}, {"id": "sys-331-69qyrr", "name": "LX2", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 4, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 1, "riggingRowCount": 1}, {"id": "sys-354-gh1a2r", "name": "LX3", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 4, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 2, "riggingRowCount": 1}, {"id": "sys-392-bajiyv", "name": "LX4", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 4, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 2, "riggingRowCount": 1}], "hoistCount": 14, "systemCount": 4, "totalMotorW": 11200}, "version": 1, "lighting": {"distros": [{"id": "dst-3999be2b-e2a1-421a-88bf-837abe2f60dc", "name": "HOT 1", "source": "DimmerLand", "feedAmps": 32, "imbalance": 0, "feedPhases": 3, "totalWatts": 0, "feedVoltage": 400, "presetLabel": "CEE 32 A · 3ph · 6 × 16 A", "feedsTrusses": [], "worstLegAmps": 0, "imbalanceWarn": false, "feederOverload": false, "channelOverload": false, "feederUtilization": 0}, {"id": "dst-3823d76a-01fe-437d-9b00-87f31c740583", "name": "HOT 2", "source": "", "feedAmps": 32, "imbalance": 0, "feedPhases": 1, "totalWatts": 5400, "feedVoltage": 230, "presetLabel": "CEE 32 A · 1ph", "feedsTrusses": ["LX1"], "worstLegAmps": 24.7, "imbalanceWarn": false, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.77}, {"id": "dst-cb2e499c-b633-4a17-bb7f-8f832a88cba3", "name": "HOT 3", "source": "", "feedAmps": 32, "imbalance": 0.36, "feedPhases": 3, "totalWatts": 7200, "feedVoltage": 400, "presetLabel": "CEE 32 A · 3ph · 6 × 16 A", "feedsTrusses": ["LX4"], "worstLegAmps": 12.5, "imbalanceWarn": true, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.39}, {"id": "dst-c9f1af64-b82c-4d78-bc21-b87d51e5e2d1", "name": "HOT 4", "source": "", "feedAmps": 32, "imbalance": 0.36, "feedPhases": 3, "totalWatts": 7200, "feedVoltage": 400, "presetLabel": "CEE 32 A · 3ph · 6 × 16 A", "feedsTrusses": ["LX3"], "worstLegAmps": 12.5, "imbalanceWarn": true, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.39}, {"id": "dst-4fca0878-6b05-4f55-b02d-99b34f0478e3", "name": "HOT 5", "source": "", "feedAmps": 32, "imbalance": 0, "feedPhases": 3, "totalWatts": 12480, "feedVoltage": 400, "presetLabel": "CEE 32 A · 3ph · 6 × 16 A", "feedsTrusses": ["LX2"], "worstLegAmps": 19, "imbalanceWarn": false, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.59}], "universes": [1], "distroCount": 5, "circuitCount": 0, "fixtureCount": 64, "totalDistroW": 32280, "totalCircuitW": 0, "worstCircuitPct": 0, "totalFixtureWatts": 32280, "worstDistroFeederPct": 0.77}, "riggPlan": {"venue": {"depthM": 12, "widthM": 48, "ceilingM": 8}, "trusses": [{"x": 24, "y": 6, "z": 7.5, "x1": 21, "x2": 27, "y1": 6, "y2": 6, "lengthM": 6, "rotation": 0, "systemId": "sys-5-trf8a3", "systemName": "LX1"}]}, "assignments": [{"name": "Demo Anders AV", "role": "AV FOH", "hours": 14, "notes": "", "crewId": "crew-20349ecd-e146-4196-a874-9b94ba56d422", "dayRate": 0, "offTime": "23:00", "callTime": "09:00", "freelancerUserId": "demo-av-foh"}, {"name": "Demo Frida FOH", "role": "Sound", "hours": 14, "notes": "", "crewId": "crew-e712abd6-f247-4fa7-ba54-0f9402fa3a47", "dayRate": 0, "offTime": "23:00", "callTime": "09:00", "freelancerUserId": "demo-sound-foh"}, {"name": "Demo Linnea Lysrigg", "role": "Lighting", "hours": 14, "notes": "", "crewId": "crew-9aa71eb8-91be-4f23-871d-931f180ba49f", "dayRate": 0, "offTime": "23:00", "callTime": "09:00", "freelancerUserId": "demo-light-rigg"}, {"name": "Demo Sondre Monitor", "role": "Sound", "hours": 14, "notes": "", "crewId": "crew-90dc31ad-3f36-4138-a81d-b4f20c7972bd", "dayRate": 0, "offTime": "23:00", "callTime": "09:00", "freelancerUserId": "demo-sound-monitor"}, {"name": "Demo Stian Stagehand", "role": "Stage Hand", "hours": 14, "notes": "", "crewId": "crew-37ce568f-d8bc-4eed-8c60-b17bab2c0c0b", "dayRate": 0, "offTime": "23:00", "callTime": "09:00", "freelancerUserId": "demo-stagehand"}], "attachments": [], "generatedAt": 1777834811127, "recipientCrewId": null}	2026-05-03 18:03:52.204302+00	2026-05-03 19:00:11.209504+00
f7e128b5-2e51-4b4d-91a7-8722b43d6e87	user_3Cx5qiY52TcaJowheSkwll49BRQ	THE QUBE	ZZAE	THE QUBE	2026-05-06	2026-05-06	{"led": {"screens": [{"id": "led-e01ihq1", "cols": 32, "name": "Main Center", "rows": 6, "brackets": [{"name": "(set bracket on inventory)", "count": 192}], "panelType": "Uniview UR Pro 0.5x1m (10.8kg)", "powerCables": 191, "totalPanels": 192, "powerLengthM": 114.6, "signalCables": 191, "signalLengthM": 248.3, "estimatedWatts": 67200, "processorPixels": 6291456, "processorOutputs": 0, "processorMaxPixels": 0}], "processor": "Novastar MX40", "screenCount": 1, "totalPanels": 192}, "sound": {"rowCount": 0, "totalQty": 0, "byCategory": [], "totalPower": 0, "totalWeight": 0}, "stage": {"stages": [{"id": "a6314b60-bdd4-4d87-8a0d-cd6f42757ebc", "area": 120, "name": "Main Stage", "depth": 6, "width": 20, "deckCounts": {"1x1": 0, "2x1": 60, "0.5x1": 0, "0.5x2": 0}, "legHeightCm": 80, "bracingNotes": ["Diagonal bracing required (≥ 80 cm)"], "loadCapacityKg": 76560}], "totalArea": 120, "stageCount": 1, "totalLoadCapacityKg": 76560}, "briefId": "640cb072d254", "project": {"date": "2026-05-06", "venue": "THE QUBE", "client": "ZZAE", "endDate": "2026-05-06", "schedule": {"show": [{"to": "2026-05-06", "from": "2026-05-06", "fromTime": "11:00"}, {"to": "2026-05-07", "from": "2026-05-07", "toTime": "16:30", "fromTime": "10:00"}], "setup": [{"to": "2026-05-04", "from": "2026-05-04", "toTime": "21:00", "fromTime": "09:00"}, {"to": "2026-05-05", "from": "2026-05-05", "toTime": "21:00", "fromTime": "09:00"}], "downrig": [{"to": "2026-05-07", "from": "2026-05-07", "toTime": "23:00", "fromTime": "17:00"}], "rehearsal": [{"to": "2026-05-06", "from": "2026-05-06", "toTime": "10:30", "fromTime": "09:00"}]}, "preparedBy": "Olti"}, "rigging": {"systems": [{"id": "sys-53-lzho3j", "name": "LX1", "hoist": "None", "pointCount": 3, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 2, "riggingRowCount": 0}, {"id": "sys-13-y04nwg", "name": "LX2", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 3, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 1, "riggingRowCount": 1}, {"id": "sys-15-5a7pos", "name": "LX3", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 3, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 3, "riggingRowCount": 1}, {"id": "sys-17-7bvdga", "name": "LX4", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 3, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 1, "riggingRowCount": 1}, {"id": "sys-33-scpd0j", "name": "LED TRUSS", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 3, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 0, "riggingRowCount": 1}], "hoistCount": 15, "systemCount": 5, "totalMotorW": 9600}, "version": 1, "lighting": {"distros": [{"id": "dst-b96e0bc5-6399-480a-9fbe-3836b278499f", "name": "HOT 1", "source": "", "feedAmps": 16, "imbalance": 0, "feedPhases": 1, "totalWatts": 1680, "feedVoltage": 230, "presetLabel": "Schuko 16 A · 1ph", "feedsTrusses": ["LX1"], "worstLegAmps": 7.7, "imbalanceWarn": false, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.48}, {"id": "dst-b0e79213-4d4e-4b30-a35c-04ea914d3a35", "name": "HOT 2", "source": "", "feedAmps": 16, "imbalance": 0, "feedPhases": 1, "totalWatts": 1000, "feedVoltage": 230, "presetLabel": "Schuko 16 A · 1ph", "feedsTrusses": ["LX2"], "worstLegAmps": 4.6, "imbalanceWarn": false, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.29}, {"id": "dst-e499a2b5-f0a5-4204-8df3-f9f592738ab4", "name": "HOT 3", "source": "", "feedAmps": 32, "imbalance": 0.12, "feedPhases": 3, "totalWatts": 6520, "feedVoltage": 400, "presetLabel": "CEE 32 A · 3ph · 6 × 16 A", "feedsTrusses": ["LX3"], "worstLegAmps": 10.8, "imbalanceWarn": false, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.34}, {"id": "dst-69e01956-43b3-42ac-8e84-41bd55edaf8d", "name": "HOT 4", "source": "", "feedAmps": 32, "imbalance": 0, "feedPhases": 1, "totalWatts": 3000, "feedVoltage": 230, "presetLabel": "CEE 32 A · 1ph", "feedsTrusses": ["LX4"], "worstLegAmps": 13.7, "imbalanceWarn": false, "feederOverload": false, "channelOverload": false, "feederUtilization": 0.43}], "universes": [1], "distroCount": 4, "circuitCount": 0, "fixtureCount": 35, "totalDistroW": 12200, "totalCircuitW": 0, "worstCircuitPct": 0, "totalFixtureWatts": 12200, "worstDistroFeederPct": 0.48}, "riggPlan": {"venue": {"depthM": 12, "widthM": 20, "ceilingM": 8}, "trusses": [{"x": 10, "y": 2, "z": 7.5, "x1": 7, "x2": 13, "y1": 2, "y2": 2, "lengthM": 6, "rotation": 0, "systemId": "sys-53-lzho3j", "systemName": "LX1"}, {"x": 10, "y": 2.5, "z": 7.5, "x1": 7, "x2": 13, "y1": 2.5, "y2": 2.5, "lengthM": 6, "rotation": 0, "systemId": "sys-13-y04nwg", "systemName": "LX2"}, {"x": 10, "y": 3, "z": 7.5, "x1": 7, "x2": 13, "y1": 3, "y2": 3, "lengthM": 6, "rotation": 0, "systemId": "sys-15-5a7pos", "systemName": "LX3"}, {"x": 10, "y": 3.5, "z": 7.5, "x1": 7, "x2": 13, "y1": 3.5, "y2": 3.5, "lengthM": 6, "rotation": 0, "systemId": "sys-17-7bvdga", "systemName": "LX4"}, {"x": 10, "y": 8.5, "z": 7.5, "x1": 7, "x2": 13, "y1": 8.5, "y2": 8.5, "lengthM": 6, "rotation": 0, "systemId": "sys-33-scpd0j", "systemName": "LED TRUSS"}]}, "assignments": [{"name": "Demo Anders AV", "role": "AV FOH", "hours": 1.5, "notes": "", "crewId": "crew-a5e23c47-7e62-42e3-8865-e952dfe19c57", "dayRate": 0, "offTime": "10:30", "callTime": "09:00", "freelancerUserId": "demo-av-foh"}, {"name": "Demo Frida FOH", "role": "Sound", "hours": 1.5, "notes": "", "crewId": "crew-8b7ba0ef-96c7-4164-be4e-b83bf99ecbe7", "dayRate": 0, "offTime": "10:30", "callTime": "09:00", "freelancerUserId": "demo-sound-foh"}, {"name": "Demo Linnea Lysrigg", "role": "Lighting", "hours": 1.5, "notes": "", "crewId": "crew-ea1c822b-a9c9-49d5-879c-c2078f927133", "dayRate": 0, "offTime": "10:30", "callTime": "09:00", "freelancerUserId": "demo-light-rigg"}, {"name": "Demo Sondre Monitor", "role": "Sound", "hours": 1.5, "notes": "", "crewId": "crew-d7a68d1c-bb5b-42d7-88a1-91365852dba6", "dayRate": 0, "offTime": "10:30", "callTime": "09:00", "freelancerUserId": "demo-sound-monitor"}, {"name": "Demo Stian Stagehand", "role": "Stage Hand", "hours": 1.5, "notes": "", "crewId": "crew-8b9eefdc-23cb-4203-aa32-167d72df0535", "dayRate": 0, "offTime": "10:30", "callTime": "09:00", "freelancerUserId": "demo-stagehand"}], "attachments": [], "generatedAt": 1777836791796, "recipientCrewId": null}	2026-05-03 17:26:41.510684+00	2026-05-03 19:33:11.910057+00
dc7b3969-7250-4287-9084-378566012249	user_3Cx5qiY52TcaJowheSkwll49BRQ				2026-05-04	\N	{"led": {"screens": [], "processor": "", "screenCount": 0, "totalPanels": 0}, "sound": {"rowCount": 0, "totalQty": 0, "byCategory": [], "totalPower": 0, "totalWeight": 0}, "stage": {"stages": [], "totalArea": 0, "stageCount": 0, "totalLoadCapacityKg": 0}, "briefId": "fc96a24cab72", "project": {"date": "2026-05-04", "venue": "", "client": "", "schedule": {"show": [{"to": "2026-05-04", "from": "2026-05-04"}]}, "preparedBy": ""}, "rigging": {"systems": [{"id": "sys-1-kitxkt", "name": "LX1", "hoist": "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", "pointCount": 3, "ledRowCount": 0, "dynamicFactor": 1.25, "fixtureRowCount": 0, "riggingRowCount": 1}], "hoistCount": 3, "systemCount": 1, "totalMotorW": 2400}, "version": 1, "lighting": {"distros": [], "universes": [], "distroCount": 0, "circuitCount": 0, "fixtureCount": 0, "totalDistroW": 0, "totalCircuitW": 0, "worstCircuitPct": 0, "totalFixtureWatts": 0, "worstDistroFeederPct": 0}, "riggPlan": null, "assignments": [{"name": "Demo Anders AV", "role": "AV FOH", "hours": 10, "notes": "", "crewId": "crew-a1a2ce0e-a7b7-4573-8e37-43d145476a6b", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": [], "assignedDates": ["2026-05-04"], "freelancerUserId": "demo-av-foh"}, {"name": "Demo Frida FOH", "role": "Sound", "hours": 10, "notes": "", "crewId": "crew-9735bf10-819d-42d3-a3e2-b32181b7bbf8", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": [], "assignedDates": ["2026-05-04"], "freelancerUserId": "demo-sound-foh"}, {"name": "Demo Linnea Lysrigg", "role": "Lighting", "hours": 10, "notes": "", "crewId": "crew-56e876d6-965d-45e9-86e2-0ba934ebeed6", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": [], "assignedDates": ["2026-05-04"], "freelancerUserId": "demo-light-rigg"}, {"name": "Demo Sondre Monitor", "role": "Sound", "hours": 10, "notes": "", "crewId": "crew-47bb47ae-decf-4b47-9c73-5841b3c103e5", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": [], "assignedDates": ["2026-05-04"], "freelancerUserId": "demo-sound-monitor"}, {"name": "Demo Stian Stagehand", "role": "Stage Hand", "hours": 10, "notes": "", "crewId": "crew-7e4965cd-228a-4899-a639-0744518383c0", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": [], "assignedDates": ["2026-05-04"], "freelancerUserId": "demo-stagehand"}, {"name": "Sidebar Tester One", "role": "Sound", "hours": 10, "notes": "", "crewId": "crew-35f6fba9-c135-462a-9001-4f54672254fa", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": [], "assignedDates": ["2026-05-04"], "freelancerUserId": "seed-3XC9QRoB"}], "attachments": [], "generatedAt": 1777921939195, "recipientCrewId": null}	2026-05-04 19:12:10.963874+00	2026-05-04 19:12:19.32551+00
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, user_id, name, venue, client, data, created_at, updated_at) FROM stdin;
551b4960-70ec-4b22-9fcc-c80f35138adf	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-nk3u7l", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-qy7gk6", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-04", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-nk3u7l"}	2026-05-04 19:26:20.512743+00	2026-05-04 19:26:25.582859+00
63abdedc-4fb7-42f9-8a7c-4649b5b8f274	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-qu9v5w", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-31uphm", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "inspection", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "Stage: 6x4 meters, 60 cm height\\n  Setup date: 12-06-2026 at 09:00\\n  Power in the house: 1x 400V 63A\\n  Backstage area needed with 2 tables", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-04", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-qu9v5w"}	2026-05-04 19:43:26.731265+00	2026-05-04 19:43:51.747696+00
11cf279d-b9d9-45fb-84e1-d02810a55e30	user_3Cx5qiY52TcaJowheSkwll49BRQ	test	test	test	{"crew": [{"id": "crew-56e876d6-965d-45e9-86e2-0ba934ebeed6", "name": "Demo Linnea Lysrigg", "role": "Lighting", "notes": "", "phone": "+47 412 03 002", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": ["2026-05-04"], "needsHotel": true, "assignedDates": ["2026-05-04"], "requestStatus": "no-reply", "freelancerUserId": "demo-light-rigg", "briefAssignmentId": "e3ee2b52-124d-458c-9fc6-2bff66fc1fa5"}, {"id": "crew-47bb47ae-decf-4b47-9c73-5841b3c103e5", "name": "Demo Sondre Monitor", "role": "Sound", "notes": "", "phone": "+47 412 03 001", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "allergens": ["Nøtter"], "hotelDates": ["2026-05-04"], "needsHotel": true, "dietaryTags": ["vegetarian"], "assignedDates": ["2026-05-04"], "requestStatus": "no-reply", "freelancerUserId": "demo-sound-monitor", "briefAssignmentId": "5609bb87-56b7-4c49-b44f-950b1bb4833e"}, {"id": "crew-7e4965cd-228a-4899-a639-0744518383c0", "name": "Demo Stian Stagehand", "role": "Stage Hand", "notes": "", "phone": "+47 412 03 003", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "allergens": ["Skalldyr"], "hotelDates": ["2026-05-04"], "needsHotel": true, "dietaryTags": ["halal"], "assignedDates": ["2026-05-04"], "requestStatus": "no-reply", "freelancerUserId": "demo-stagehand", "briefAssignmentId": "3b151b14-8692-480a-8f2e-372d2b9a3da0"}, {"id": "crew-35f6fba9-c135-462a-9001-4f54672254fa", "name": "Sidebar Tester One", "role": "Sound", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": ["2026-05-04"], "needsHotel": true, "assignedDates": ["2026-05-04"], "requestStatus": "no-reply", "freelancerUserId": "seed-3XC9QRoB", "briefAssignmentId": "7c5813b7-953b-4b86-ba03-723ae9c2fcdd"}], "power": {"distros": [{"id": "dst-29ce139d-588e-44c5-8ca9-c5cd060bb6ed", "name": "HOT 1", "preset": "cee-32-1ph", "source": "", "channels": [{"id": "pch-9dd58806-c2f7-4a04-af4d-5f0a14758d78", "drops": [{"id": "drp-3b6475ea-f9c5-4865-ad64-9124b8a17734", "qty": 12, "trussId": "sys-1-kitxkt", "fixtureRef": "Martin MAC Aura XIP (10.0kg)"}], "index": 1, "voltage": 230, "breakerAmps": 32}], "feedAmps": 32, "feedPhases": 1, "feedVoltage": 230, "feedsTrusses": ["sys-1-kitxkt"], "channelMapping": {"L1": [1], "L2": [], "L3": []}, "defaultPowerFactor": 0.95}], "circuits": []}, "theme": "light", "venue": "test", "client": "test", "stages": [], "systems": [{"id": "sys-1-kitxkt", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 4, "fixtureRows": [{"id": "row-87-90nn5a", "qty": 12, "category": "Fixtures", "selectedIndex": 12}], "riggingRows": [{"id": "row-2-sijv2m", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "Olti", "mainView": "led", "riggPlan": {"venue": {"depthM": 12, "widthM": 48, "ceilingM": 8}, "trussById": {"sys-1-kitxkt": {"x": 24, "y": 6, "z": 7.5, "lengthM": 6, "rotation": 0}}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-9xjsoi1", "name": "Main LED", "color": "#5a8edc", "notes": "Surface 128 m² — ~512 panels @ 0.5×0.5 m. Pixel: 4096 x 2048p. 3.9 mm pixel pitch.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 6, "panelsWide": 32, "processors": [{"id": "proc_4iynccef", "model": "novastar-mx40"}], "outputIndex": null, "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc"}, {"id": "led-dndygyk", "name": "Main Bottom LED", "color": "#ef4444", "notes": "Surface 10 m² — ~40 panels @ 0.5×0.5 m. Pixel: 2560 x 256p. 3.9 mm pixel pitch.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 1, "panelsWide": 20, "outputIndex": null, "panelColorDark": "#7f1d1d", "panelColorLight": "#ef4444"}, {"id": "led-x5eoo0a", "name": "Stack LED-R", "color": "#dc4040", "notes": "Surface 22 m² — ~88 panels @ 0.5×0.5 m. Pixel: 1024 x 1408p. 3.9 mm pixel pitch. Right side stack.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 6, "panelsWide": 8, "outputIndex": null, "panelColorDark": "#3b82f6", "panelColorLight": "#dc4040"}, {"id": "led-i4qraxo", "name": "Stack LED-L", "color": "#22c55e", "notes": "Surface 22 m² — ~88 panels @ 0.5×0.5 m. Pixel: 1024 x 1408p. 3.9 mm pixel pitch. Left side stack.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 6, "panelsWide": 8, "outputIndex": null, "panelColorDark": "#14532d", "panelColorLight": "#22c55e"}, {"id": "led-fmrnq4c", "name": "IMAG LED-R", "color": "#a78bfa", "notes": "Surface 36 m² — ~144 panels @ 0.5×0.5 m. Pixel: 2048 x 1152p. 3.9 mm pixel pitch. Right IMAG screen.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 5, "panelsWide": 16, "outputIndex": null, "panelColorDark": "#4c1d95", "panelColorLight": "#a78bfa"}, {"id": "led-2wymoqm", "name": "IMAG LED-L", "color": "#fb923c", "notes": "Surface 36 m² — ~144 panels @ 0.5×0.5 m. Pixel: 2048 x 1152p. 3.9 mm pixel pitch. Left IMAG screen.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 5, "panelsWide": 16, "outputIndex": null, "panelColorDark": "#7c2d12", "panelColorLight": "#fb923c"}, {"id": "led-7ocl9hi", "name": "Triangle LED", "color": "#2dd4bf", "notes": "2 pieces. Total surface 48 m² — ~192 panels @ 0.5×0.5 m. Total Pixel: 6144 x 512p (3072 x 512p per piece). 3.9 mm pixel pitch. Triangular floor/ramp LED elements.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 2, "panelsWide": 24, "outputIndex": null, "panelColorDark": "#134e4a", "panelColorLight": "#2dd4bf"}, {"id": "led-6yw4nud", "name": "Tower 1 LED", "color": "#9ca3af", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 6, "panelsWide": 1, "outputIndex": null, "panelColorDark": "#1f2937", "panelColorLight": "#9ca3af"}, {"id": "led-a59xizv", "name": "Tower 2 LED", "color": "#5a8edc", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 6, "panelsWide": 1, "outputIndex": null, "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc"}, {"id": "led-pvf6w26", "name": "Tower 3 LED", "color": "#ef4444", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 6, "panelsWide": 1, "outputIndex": null, "panelColorDark": "#7f1d1d", "panelColorLight": "#ef4444"}, {"id": "led-exuocr7", "name": "Tower 4 LED", "color": "#dc4040", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 6, "panelsWide": 1, "outputIndex": null, "panelColorDark": "#3b82f6", "panelColorLight": "#dc4040"}], "linkedMeta": {}, "reportDate": "2026-05-04", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": "dc7b3969-7250-4287-9084-378566012249", "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-kitxkt"}	2026-05-04 19:23:26.744845+00	2026-05-07 09:22:30.036108+00
8288503b-2801-4e9b-a4c5-70fc699b6fa2	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-4fglxi", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-w7sjd3", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "inspection", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "Stage: 6x4 meters, 60 cm height\\nSetup date: 12-06-2026 at 09:00\\nPower in the house: 1x 400V 63A\\nBackstage area needed with 2 tables", "general": [{"id": "4apr0206", "field": "Backstage area", "value": "Backstage area required with 2 tables", "confidence": "high"}], "schedule": [{"id": "3l3gl8vd", "field": "Setup date", "value": "2026-06-12", "confidence": "high"}, {"id": "4y35q8fs", "field": "Setup time", "value": "09:00", "confidence": "high"}], "equipment": [{"id": "kkwy8dn0", "field": "Stage width", "value": "6.5 meters", "confidence": "high"}, {"id": "801jf0et", "field": "Stage depth", "value": "4 meters", "confidence": "high"}, {"id": "d6kxwhp1", "field": "Stage height", "value": "60 cm", "confidence": "high"}, {"id": "60lo2pmf", "field": "Backstage tables", "value": "2 tables", "confidence": "high"}, {"id": "ccns0920", "field": "", "value": "", "confidence": "medium"}], "technical": [{"id": "0c8eq5la", "field": "Power supply", "value": "1-phase, 400V, 63A", "confidence": "high"}], "extractedAt": "2026-05-04T19:46:38.840Z"}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-04", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-4fglxi"}	2026-05-04 19:46:18.433695+00	2026-05-04 19:47:02.7577+00
d719b31c-038f-4779-94fa-9d7ec319ee78	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [{"id": "crew-62401c1c-b11f-4c61-8a0f-8d36ee08a12c", "name": "Sidebar Tester One", "role": "Sound", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "needsHotel": false, "requestStatus": "no-reply", "freelancerUserId": "seed-3XC9QRoB", "briefAssignmentId": "869525de-abe0-4c6e-b554-c3ef06dd7cf3"}], "power": {"distros": [], "circuits": []}, "theme": "light", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-jhiy45", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-fl8vo2", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "led", "riggPlan": {"venue": {"depthM": 12, "widthM": 20, "ceilingM": 8}, "trussById": {"sys-1-jhiy45": {"x": 10, "y": 6, "z": 7.5, "lengthM": 6, "rotation": 0}}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-9qg749j", "name": "IMAG", "color": "#3b82f6", "notes": "", "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "panelsTall": 3, "panelsWide": 5, "outputIndex": null}], "linkedMeta": {}, "reportDate": "2026-04-27", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": "a44275a4-9228-4fef-b1cf-66a3241c8209", "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-jhiy45"}	2026-05-04 21:47:34.822239+00	2026-05-11 11:55:11.72225+00
6714267c-8e6a-4223-8b91-ac2b914b8197	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "light", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-mio7kj", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-zgr5id", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "led", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true, "viewport": {"x": 1.6313002414011635, "y": 0.9909630544825347, "zoom": 0.9944701686732164}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-xnm71pk", "name": "Main", "color": "#3b82f6", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 5, "panelsWide": 20, "outputIndex": null, "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc"}, {"id": "led-vk5p85s", "name": "DLY 5x3", "color": "#ef4444", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 3, "panelsWide": 10, "outputIndex": null, "panelColorDark": "#7f1d1d", "panelColorLight": "#ef4444"}, {"id": "led-7zgpwgn", "name": "VIP 5x3", "color": "#10b981", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 3, "panelsWide": 10, "outputIndex": null, "panelColorDark": "#3b82f6", "panelColorLight": "#dc4040"}], "linkedMeta": {}, "reportDate": "2026-05-11", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": "novastar-mx40", "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-mio7kj"}	2026-05-11 16:55:32.979614+00	2026-05-11 17:00:37.028832+00
a4e246ea-4330-4e61-b4d5-d39a06971be8	user_3Cx5qiY52TcaJowheSkwll49BRQ	THe Qube / ZZAE26	THe Qube / ZZAE26	Berg Hansen	{"crew": [{"id": "crew-c1d925ea-7504-437b-8323-c0624e1748ed", "name": "Ingrid Lund", "role": "Video / LED", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "needsHotel": false, "requestStatus": "too_late", "freelancerUserId": "user_demo_ingrid_lund", "briefAssignmentId": "2a5197a7-77d6-4ec8-af67-f32a06678b97"}, {"id": "crew-ad5a20e7-d76b-4329-a570-81b302e20275", "name": "Jonas Hauge", "role": "Rigging", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "needsHotel": false, "requestStatus": "too_late", "freelancerUserId": "user_demo_jonas_hauge", "briefAssignmentId": "c946ea06-4569-4cf9-9191-2b213edb92b8"}, {"id": "crew-2c81526e-f191-4c12-a1f1-7579669ef901", "name": "Mari Solstad", "role": "System Tech", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "needsHotel": false, "requestStatus": "too_late", "freelancerUserId": "user_demo_mari_solstad", "briefAssignmentId": "6a7f09a7-d82d-473f-9bd4-317dc07d06fa"}, {"id": "crew-0237c200-1d1b-4f92-9bae-696e81ac09f1", "name": "Olav Berg", "role": "Sound", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "needsHotel": false, "requestStatus": "too_late", "freelancerUserId": "user_demo_olav_berg", "briefAssignmentId": "05ce07b9-979a-41e4-adca-df055d4e97be"}, {"id": "crew-2f6c71eb-6e9f-44f5-889f-bfe82c0ed916", "name": "Sidebar Tester One", "role": "Sound", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "needsHotel": false, "requestStatus": "too_late", "freelancerUserId": "seed-3XC9QRoB", "briefAssignmentId": "d08cc778-0ed8-454b-abdf-7c16f6164ddd"}, {"id": "crew-09a78c0f-58ca-4a4c-b01c-7c363984d7e9", "name": "Olti (You)", "role": "Project Manager", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "needsHotel": false, "requestStatus": "accepted", "freelancerUserId": "user_3Cx5qiY52TcaJowheSkwll49BRQ", "briefAssignmentId": "927dee15-ffee-427b-9f86-b33fa2c6757a"}], "power": {"distros": [{"id": "dst-31f60742-8b36-44f5-87f4-b420f5a71a57", "name": "HOT 1", "preset": "cee-32-3ph-6x16", "source": "", "channels": [{"id": "pch-e546e43f-bec7-4924-941a-9ad2c6604926", "drops": [{"id": "drp-cdf71500-06d9-42ab-b25a-69ca4707b79e", "qty": 3, "trussId": "sys-21-7cs1ds", "fixtureRef": "Clay Paky Mythos 2 (32.0kg)"}], "index": 1, "voltage": 230, "breakerAmps": 16}, {"id": "pch-d67712e5-54f6-44f3-8dbc-88e48566034c", "drops": [{"id": "drp-345143ef-3f31-4afa-beaa-b769ffd7fe05", "qty": 3, "trussId": "sys-21-7cs1ds", "fixtureRef": "Clay Paky Mythos 2 (32.0kg)"}], "index": 2, "voltage": 230, "breakerAmps": 16}, {"id": "pch-ebf0cc97-f2d1-4a2c-ba51-85bc8b89ca22", "drops": [{"id": "drp-161dbdf1-dabe-46bc-ab55-3cdc6fd6d1cf", "qty": 2, "trussId": "sys-21-7cs1ds", "fixtureRef": "Clay Paky Mythos 2 (32.0kg)"}], "index": 3, "voltage": 230, "breakerAmps": 16}, {"id": "pch-343477bb-58d3-442a-bbf9-09949b4bf160", "drops": [{"id": "drp-36f57325-ee28-46db-8a01-621657ec6c8d", "qty": 4, "trussId": "sys-21-7cs1ds", "fixtureRef": "Martin MAC Aura XIP (10.0kg)"}], "index": 4, "voltage": 230, "breakerAmps": 16}, {"id": "pch-e5df15cd-b261-4682-9af4-c85ebfed060d", "drops": [], "index": 5, "voltage": 230, "breakerAmps": 16}, {"id": "pch-5d5a8197-84b6-4b3a-9d5a-ae093ed4cedf", "drops": [{"id": "drp-e31bf764-0227-4be1-9984-4913d684ef43", "qty": 8, "trussId": "sys-21-7cs1ds", "fixtureRef": "Martin MAC Aura XIP (10.0kg)"}], "index": 6, "voltage": 230, "breakerAmps": 16}], "feedAmps": 32, "feedPhases": 3, "feedVoltage": 400, "feedsTrusses": ["sys-21-7cs1ds"], "channelMapping": {"L1": [1, 4], "L2": [2, 5], "L3": [3, 6]}, "defaultPowerFactor": 0.95}, {"id": "dst-da16dcf1-cd45-416d-8a19-0fac37addec5", "name": "HOT 2", "preset": "cee-32-3ph-6x16", "source": "", "channels": [{"id": "pch-8a5616a3-464a-4ec4-a75b-c9d433a7b7d9", "drops": [{"id": "drp-f8a68104-c773-4718-87f1-532608b20484", "qty": 2, "trussId": "sys-9-ooq1sf", "fixtureRef": "Martin MAC Viper XIP (37.8kg)"}], "index": 1, "voltage": 230, "breakerAmps": 16}, {"id": "pch-d10ce76a-b0d4-4d85-84a9-ea598fe2dc1c", "drops": [{"id": "drp-4cbd3108-b5e9-4205-8bfe-f01c3e9c067c", "qty": 2, "trussId": "sys-9-ooq1sf", "fixtureRef": "Martin MAC Viper XIP (37.8kg)"}], "index": 2, "voltage": 230, "breakerAmps": 16}, {"id": "pch-bbc41933-7619-46e8-a6dc-2b75441abf6a", "drops": [{"id": "drp-1fe0a80b-99f1-4848-92b6-2f1c619d288d", "qty": 2, "trussId": "sys-9-ooq1sf", "fixtureRef": "Martin MAC Viper XIP (37.8kg)"}], "index": 3, "voltage": 230, "breakerAmps": 16}, {"id": "pch-235ad7cc-1b88-44fe-a0fc-e2dabbeabb93", "drops": [{"id": "drp-79ca2e82-fdd5-444e-8bf5-74454990a14f", "qty": 2, "trussId": "sys-9-ooq1sf", "fixtureRef": "Martin MAC Viper XIP (37.8kg)"}], "index": 4, "voltage": 230, "breakerAmps": 16}, {"id": "pch-26edaabb-b198-479f-95e1-cc2ff752ad4f", "drops": [{"id": "drp-ae41c95c-f683-4668-a4b5-7db8b27a8533", "qty": 2, "trussId": "sys-9-ooq1sf", "fixtureRef": "Martin MAC Viper XIP (37.8kg)"}], "index": 5, "voltage": 230, "breakerAmps": 16}, {"id": "pch-0cb23680-5809-475a-bad5-fe4734d2dc8e", "drops": [{"id": "drp-11bc059f-093b-4091-9d5a-047d2a572970", "qty": 2, "trussId": "sys-9-ooq1sf", "fixtureRef": "Martin MAC Viper XIP (37.8kg)"}], "index": 6, "voltage": 230, "breakerAmps": 16}], "feedAmps": 32, "feedPhases": 3, "feedVoltage": 400, "feedsTrusses": ["sys-9-ooq1sf"], "channelMapping": {"L1": [1, 4], "L2": [2, 5], "L3": [3, 6]}, "defaultPowerFactor": 0.95}, {"id": "dst-b24a1a32-74b3-48c1-99ed-1a49a8a139a1", "name": "HOT 3", "preset": "cee-32-1ph", "source": "", "channels": [{"id": "pch-c9bd13bd-0b36-4746-aa44-79bade4fadaa", "drops": [{"id": "drp-93e93adc-f036-4ec8-bc33-a8f6cc3d59a2", "qty": 16, "trussId": "sys-15-pq0z06", "fixtureRef": "Martin MAC One (5.4kg)"}], "index": 1, "voltage": 230, "breakerAmps": 32}], "feedAmps": 32, "feedPhases": 1, "feedVoltage": 230, "feedsTrusses": ["sys-15-pq0z06"], "channelMapping": {"L1": [1], "L2": [], "L3": []}, "defaultPowerFactor": 0.95}], "circuits": []}, "theme": "light", "venue": "THe Qube / ZZAE26", "client": "Berg Hansen", "stages": [{"id": "5142a4c3-112c-4d93-bea1-ce7bd76d7262", "name": "Stage 1", "depth": 3, "notes": "", "rails": {"back": false, "left": false, "front": false, "right": false}, "width": 14, "legMode": "shared", "editMode": "auto", "buildOrder": "rightToLeft", "customRails": [], "legHeightCm": 60, "connectorSide": "N", "manualPlacements": [], "connectorOverrides": {}}], "systems": [{"id": "sys-11-1lwim3", "name": "LX1", "ledRows": [], "hoistIndex": -1, "pointCount": 4, "fixtureRows": [], "riggingRows": [{"id": "row-18-ct9llv", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}, {"id": "sys-9-ooq1sf", "name": "LX2", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [{"id": "row-220-8fdk4s", "qty": 12, "category": "Fixtures", "selectedIndex": 15}], "riggingRows": [{"id": "row-10-vpghy5", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}, {"id": "sys-15-pq0z06", "name": "LX3", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [{"id": "row-203-os089l", "qty": 16, "category": "Fixtures", "selectedIndex": 14}], "riggingRows": [{"id": "row-16-d5k154", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}, {"id": "sys-21-7cs1ds", "name": "LX4", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [{"id": "row-27-b64kox", "qty": 8, "category": "Fixtures", "selectedIndex": 0}, {"id": "row-32-hap7nm", "qty": 12, "category": "Fixtures", "selectedIndex": 12}], "riggingRows": [{"id": "row-22-x2mjj2", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "Olti", "mainView": "led", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [{"x": -3488, "y": -704, "id": "lsn-c7ae6d71-2bf9-40e3-ba25-cb7dfc6dfedd", "kind": "screen", "label": "Screen 1", "screenRefId": "led-t4d8r3v"}, {"x": -3328, "y": -704, "id": "lsn-253cd50e-292c-4aa5-a4db-e9d7145d41c9", "kind": "processor", "label": "Processor 1", "isBackup": true, "processorModel": "novastar-mx30"}], "indoor": true, "viewport": {"x": 7751.560420984117, "y": 1539.7029895834994, "zoom": 2}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-t4d8r3v", "name": "Main Center", "color": "#3b82f6", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 3, "panelsWide": 10, "processors": [{"id": "proc_c2lcvvlo", "model": "novastar-mx30"}], "outputIndex": null, "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc"}], "linkedMeta": {}, "reportDate": "2026-05-01", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": "f0540a5a-ffd6-4e06-a0bb-8f91a91b67f4", "extraSchedule": {"setup": [{"to": "2026-04-30", "from": "2026-04-30", "toTime": "20:00", "fromTime": "09:00"}], "rehearsal": [{"to": "", "from": "", "toTime": "23:30", "fromTime": "10:00"}]}, "ledLinkedMeta": {}, "reportEndDate": "2026-05-08", "activeSystemId": "sys-11-1lwim3"}	2026-05-05 07:04:58.078603+00	2026-05-12 07:20:57.749217+00
b858508d-8a59-44c0-8344-39897698e056	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [{"id": "cac1a2c5-24ba-4d91-a460-af351ed2723e", "name": "Stage 1", "depth": 2, "notes": "", "rails": {"back": false, "left": false, "front": false, "right": false}, "width": 4, "legMode": "shared", "editMode": "auto", "buildOrder": "leftToRight", "customRails": [], "legHeightCm": 40, "manualPlacements": []}], "systems": [{"id": "sys-1-ybka15", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-28bf1h", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "stage", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-08", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-ybka15"}	2026-05-08 06:50:15.731669+00	2026-05-08 07:01:56.877407+00
b3a7ec05-f157-4031-ae1c-5f1adbc3b8d9	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-7meko7", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-ayf3q8", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-08", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-7meko7"}	2026-05-08 07:57:24.541835+00	2026-05-08 07:57:24.541835+00
856f814c-8fa6-4649-b341-13b4b8273a83	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [{"id": "a725c29b-dbe7-40f8-8f16-b04029863cfe", "name": "Stage 1", "depth": 4, "notes": "", "rails": {"back": false, "left": false, "front": false, "right": false}, "width": 6, "legMode": "shared", "editMode": "auto", "buildOrder": "rightToLeft", "customRails": [], "legHeightCm": 60, "connectorSide": "N", "manualPlacements": [], "connectorOverrides": {}}], "systems": [{"id": "sys-1-9wxz7a", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-g4e57o", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-sgrk8e7", "name": "Main Center", "color": "#3b82f6", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m (10.8kg)", "nameScale": 1, "panelsTall": 4, "panelsWide": 16, "processors": [{"id": "proc_x5o8uwb8", "model": "novastar-mx30"}], "outputIndex": null, "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc"}], "linkedMeta": {}, "reportDate": "2026-05-08", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-9wxz7a"}	2026-05-08 11:11:55.905922+00	2026-05-08 15:36:06.807448+00
65aaa935-ac87-4cc1-8627-2ad796526ef8	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [{"id": "d39bf60a-dc5d-4298-97d1-a0c01c930d78", "name": "Stage 1", "depth": 4, "notes": "", "rails": {"back": false, "left": false, "front": false, "right": false}, "width": 6, "legMode": "shared", "editMode": "auto", "buildOrder": "rightToLeft", "customRails": [], "legHeightCm": 60, "connectorSide": "N", "manualPlacements": [], "connectorOverrides": {}}], "systems": [{"id": "sys-1-ixguyd", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-iil2cf", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "stage", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-08", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-ixguyd"}	2026-05-08 08:06:28.952531+00	2026-05-08 09:07:28.194357+00
4b5922ae-45b8-4a6b-98c6-13acf71c6a4a	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [{"id": "d39bf60a-dc5d-4298-97d1-a0c01c930d78", "name": "Stage 1", "depth": 4, "notes": "", "rails": {"back": false, "left": false, "front": false, "right": false}, "width": 6, "legMode": "shared", "editMode": "auto", "buildOrder": "rightToLeft", "customRails": [], "legHeightCm": 60, "connectorSide": "N", "manualPlacements": [], "connectorOverrides": {}}], "systems": [{"id": "sys-1-ixguyd", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-iil2cf", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "stage", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-08", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-ixguyd"}	2026-05-08 09:08:04.185655+00	2026-05-08 09:08:04.185655+00
45cb88f1-7b54-484d-b6ea-fd3e0acac17e	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [{"id": "d39bf60a-dc5d-4298-97d1-a0c01c930d78", "name": "Stage 1", "depth": 4, "notes": "", "rails": {"back": false, "left": false, "front": false, "right": false}, "width": 6, "legMode": "shared", "editMode": "auto", "buildOrder": "rightToLeft", "customRails": [], "legHeightCm": 60, "connectorSide": "N", "manualPlacements": [], "connectorOverrides": {}}], "systems": [{"id": "sys-1-ixguyd", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-iil2cf", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "stage", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-08", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-ixguyd"}	2026-05-08 10:39:49.29564+00	2026-05-08 10:44:10.95559+00
e66d8a8f-88f9-41ee-94aa-980399ea2a2d	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "light", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-rsvw7j", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-071wn6", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "led", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true, "viewport": {"x": -87.99999999999994, "y": -268.45066918438016, "zoom": 2}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-laa0684", "name": "Screen 1", "color": "#3b82f6", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m + cable (12.575kg)", "nameScale": 1, "panelsTall": 4, "panelsWide": 8, "outputIndex": null, "autoFitBeams": true, "panelMarkers": [], "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc"}], "linkedMeta": {}, "reportDate": "2026-05-15", "soundItems": [], "ledSettings": {"uiMode": "basic", "showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "mainsVoltage": 230, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "redundancyMode": "none", "showCabinetIds": false, "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true, "showDataFlowPath": false, "autoTopologyOnAdd": false, "defaultPowerFactor": 0.95, "defaultVoltageRegion": "EU-230", "defaultBrightnessNits": 5000, "defaultPsuOverheadPct": 25}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-rsvw7j"}	2026-05-15 20:23:14.691941+00	2026-05-16 21:20:47.042715+00
009445c5-197e-4b4d-87ca-64b1cfb96cb6	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [{"id": "crew-f1a21835-853d-4dbe-b4ba-40d514c0cde2", "name": "", "role": "Rigging", "notes": "", "dayRate": 0, "offTime": "18:00", "callTime": "08:00", "hotelDates": ["2026-05-10"], "needsHotel": true, "assignedDates": ["2026-05-10"]}], "power": {"distros": [], "circuits": []}, "theme": "dark", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-cx741t", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-ze66ir", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "rigging", "riggPlan": {"venue": null, "trussById": {}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-10", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-cx741t"}	2026-05-10 12:15:02.045273+00	2026-05-10 12:17:21.707604+00
bffde3c1-9986-4cab-8b1a-a599fb2cb0d1	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-g3swdq", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-uxcvbv", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-15", "soundItems": [], "ledSettings": {"showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-g3swdq"}	2026-05-15 17:17:39.159747+00	2026-05-15 17:17:39.159747+00
4ff3c673-81ba-4b4d-abe9-d04c24814e85	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-ps4uo1", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-o6w5g9", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-17", "soundItems": [], "ledSettings": {"uiMode": "basic", "showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "mainsVoltage": 230, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "redundancyMode": "none", "showCabinetIds": false, "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true, "showDataFlowPath": false, "autoTopologyOnAdd": false, "defaultPowerFactor": 0.95, "defaultVoltageRegion": "EU-230", "defaultBrightnessNits": 5000, "defaultPsuOverheadPct": 25}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-ps4uo1"}	2026-05-17 08:35:42.218116+00	2026-05-17 10:30:30.376359+00
018b3670-def1-4f99-b4e2-7f3d128e56eb	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-tddenq", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-0knlq9", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-15", "soundItems": [], "ledSettings": {"uiMode": "basic", "showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "redundancyMode": "none", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true, "autoTopologyOnAdd": false, "defaultPowerFactor": 0.95, "defaultVoltageRegion": "EU-230", "defaultBrightnessNits": 5000, "defaultPsuOverheadPct": 25}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-tddenq"}	2026-05-15 17:57:11.325959+00	2026-05-15 17:58:23.592117+00
f08aa9f9-b083-4ef1-af2e-2aba1b8c2940	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "light", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-tvbard", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-e0mynt", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "led", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true, "viewport": {"x": -402.9735337484251, "y": -341.8892402890822, "zoom": 2}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-9oegzlr", "name": "Screen 1", "color": "#3b82f6", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m + cable (12.575kg)", "nameScale": 1, "panelsTall": 3, "panelsWide": 11, "outputIndex": null, "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc", "processorPortAssignments": [{"cells": [0, 1, 2, 3, 4, 5, 6, 7, 8], "portIndex": 1, "chainStart": 0, "processorId": "local-led-9oegzlr", "chainPattern": "serpentine-row"}, {"cells": [9, 10, 21, 20, 19, 18, 17, 16, 15], "portIndex": 2, "chainStart": 9, "processorId": "local-led-9oegzlr", "chainPattern": "serpentine-row"}, {"cells": [14, 13, 12, 11, 22, 23, 24, 25, 26], "portIndex": 3, "chainStart": 14, "processorId": "local-led-9oegzlr", "chainPattern": "serpentine-row"}, {"cells": [27, 28, 29, 30, 31, 32], "portIndex": 4, "chainStart": 27, "processorId": "local-led-9oegzlr", "chainPattern": "serpentine-row"}]}], "linkedMeta": {}, "reportDate": "2026-05-15", "soundItems": [], "ledSettings": {"uiMode": "basic", "showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "redundancyMode": "none", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true, "autoTopologyOnAdd": false, "defaultPowerFactor": 0.95, "defaultVoltageRegion": "EU-230", "defaultBrightnessNits": 5000, "defaultPsuOverheadPct": 25}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-tvbard"}	2026-05-15 16:57:27.196495+00	2026-05-15 17:51:57.723727+00
83464b53-9a13-40c1-b107-a825258489f8	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "light", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-6h07bg", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-von77v", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true, "viewport": {"x": 240.12996291699375, "y": 167.20431596305667, "zoom": 0.8316220983749022}}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [{"id": "led-oqo4sgz", "name": "Screen 1", "color": "#3b82f6", "notes": "", "markers": [], "panelKey": "Uniview UR Pro 0.5x1m + cable (12.575kg)", "nameScale": 1, "panelsTall": 4, "panelsWide": 11, "processors": [{"id": "proc_895opwpd", "model": "novastar-mx30"}], "outputIndex": null, "panelMarkers": [{"id": "pm_k7apii6k", "col": 10, "row": 0, "kind": "power", "index": 1}, {"id": "pm_at8zjoxi", "col": 10, "row": 1, "kind": "power", "index": 2}, {"id": "pm_g2lcoqsu", "col": 10, "row": 2, "kind": "power", "index": 3}, {"id": "pm_4aj65oyk", "col": 10, "row": 3, "kind": "power", "index": 4}, {"id": "pm_5o52irxo", "col": 0, "row": 0, "kind": "signal", "index": 1}, {"id": "pm_x6q7is4v", "col": 0, "row": 1, "kind": "signal", "index": 2}, {"id": "pm_0pr71e6y", "col": 0, "row": 2, "kind": "signal", "index": 3}, {"id": "pm_7hqp95ky", "col": 0, "row": 3, "kind": "signal", "index": 4}], "panelColorDark": "#1f3b8a", "panelColorLight": "#5a8edc", "processorPortAssignments": []}], "linkedMeta": {}, "reportDate": "2026-05-15", "soundItems": [], "ledSettings": {"uiMode": "basic", "showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "redundancyMode": "none", "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true, "autoTopologyOnAdd": false, "defaultPowerFactor": 0.95, "defaultVoltageRegion": "EU-230", "defaultBrightnessNits": 5000, "defaultPsuOverheadPct": 25}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-6h07bg"}	2026-05-15 20:36:06.42738+00	2026-05-16 10:22:39.802946+00
6f576d99-dfdd-4839-a2e0-1a14f8553c19	user_3Cx5qiY52TcaJowheSkwll49BRQ				{"crew": [], "power": {"distros": [], "circuits": []}, "theme": "system", "venue": "", "client": "", "stages": [], "systems": [{"id": "sys-1-m6on5q", "name": "LX1", "ledRows": [], "hoistIndex": 0, "pointCount": 3, "fixtureRows": [], "riggingRows": [{"id": "row-2-ad2k9x", "qty": 4, "category": "Truss", "selectedIndex": 0}], "dynamicFactor": 1.25}], "engineer": "", "mainView": "oversikt", "riggPlan": {"venue": null, "trussById": {}}, "ledSystem": {"edges": [], "nodes": [], "indoor": true}, "inspection": {"notes": "", "general": [], "schedule": [], "equipment": [], "technical": []}, "ledScreens": [], "linkedMeta": {}, "reportDate": "2026-05-17", "soundItems": [], "ledSettings": {"uiMode": "basic", "showLogo": true, "wirePath": "linear", "portLimit": 650000, "outputMode": "per-screen", "showArrows": true, "showLabels": true, "processorId": null, "showInfoBar": true, "mainsVoltage": 230, "panelPattern": "checker", "panelColorDark": "#1f3b8a", "redundancyMode": "none", "showCabinetIds": false, "showScreenName": true, "panelColorLight": "#5a8edc", "showTestPattern": true, "showDataFlowPath": false, "autoTopologyOnAdd": false, "defaultPowerFactor": 0.95, "defaultVoltageRegion": "EU-230", "defaultBrightnessNits": 5000, "defaultPsuOverheadPct": 25}, "showFixtures": [], "activeBriefId": null, "extraSchedule": {}, "ledLinkedMeta": {}, "reportEndDate": "", "activeSystemId": "sys-1-m6on5q"}	2026-05-17 10:52:46.507379+00	2026-05-17 12:24:48.595382+00
\.


--
-- Data for Name: venue_memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.venue_memory (id, user_id, venue_name, venue_key, data, created_at, updated_at) FROM stdin;
1	user_3Cx5qiY52TcaJowheSkwll49BRQ	test	test	{"savedAt": "2026-05-05T10:52:35.005Z", "lastCorrected": {"sound": [], "venue": {"depthM": null, "widthM": 47.88, "ceilingM": 8}, "stages": [], "summary": "LED screen layout drawing (page 4 of 5) for Zinzino Annual Event 2026 at X-Meeting Point, showing front and top views of a large multi-zone LED video system comprising a central 16×8 m main screen, bottom strip, left/right IMAG and stack panels, four vertical tower columns, and two triangular floor LED elements — all at 3.9 mm pixel pitch. Total declared pixel footprint: 12800 × 2816p.", "trusses": [], "lighting": [], "ledScreens": [{"bbox": {"x": 0.36, "y": 0.08, "width": 0.26, "height": 0.22}, "name": "Main LED", "notes": "Surface 128 m² — ~512 panels @ 0.5×0.5 m. Pixel: 4096 x 2048p. 3.9 mm pixel pitch.", "widthM": 16, "heightM": 8, "confidence": 0.95, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.36, "y": 0.3, "width": 0.26, "height": 0.03}, "name": "Main Bottom LED", "notes": "Surface 10 m² — ~40 panels @ 0.5×0.5 m. Pixel: 2560 x 256p. 3.9 mm pixel pitch.", "widthM": 10, "heightM": 1, "confidence": 0.95, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.27, "y": 0.1, "width": 0.08, "height": 0.22}, "name": "Stack LED-R", "notes": "Surface 22 m² — ~88 panels @ 0.5×0.5 m. Pixel: 1024 x 1408p. 3.9 mm pixel pitch. Right side stack.", "widthM": 4, "heightM": 5.5, "confidence": 0.95, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.63, "y": 0.1, "width": 0.08, "height": 0.22}, "name": "Stack LED-L", "notes": "Surface 22 m² — ~88 panels @ 0.5×0.5 m. Pixel: 1024 x 1408p. 3.9 mm pixel pitch. Left side stack.", "widthM": 4, "heightM": 5.5, "confidence": 0.95, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.06, "y": 0.1, "width": 0.18, "height": 0.2}, "name": "IMAG LED-R", "notes": "Surface 36 m² — ~144 panels @ 0.5×0.5 m. Pixel: 2048 x 1152p. 3.9 mm pixel pitch. Right IMAG screen.", "widthM": 8, "heightM": 4.5, "confidence": 0.95, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.74, "y": 0.1, "width": 0.18, "height": 0.2}, "name": "IMAG LED-L", "notes": "Surface 36 m² — ~144 panels @ 0.5×0.5 m. Pixel: 2048 x 1152p. 3.9 mm pixel pitch. Left IMAG screen.", "widthM": 8, "heightM": 4.5, "confidence": 0.95, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.28, "y": 0.32, "width": 0.42, "height": 0.12}, "name": "Triangle LED", "notes": "2 pieces. Total surface 48 m² — ~192 panels @ 0.5×0.5 m. Total Pixel: 6144 x 512p (3072 x 512p per piece). 3.9 mm pixel pitch. Triangular floor/ramp LED elements.", "widthM": 12, "heightM": 2, "confidence": 0.9, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.22, "y": 0.1, "width": 0.02, "height": 0.22}, "name": "Tower 1 LED", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "widthM": 0.5, "heightM": 5.5, "confidence": 0.92, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.25, "y": 0.1, "width": 0.02, "height": 0.22}, "name": "Tower 2 LED", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "widthM": 0.5, "heightM": 5.5, "confidence": 0.92, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.71, "y": 0.1, "width": 0.02, "height": 0.22}, "name": "Tower 3 LED", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "widthM": 0.5, "heightM": 5.5, "confidence": 0.92, "panelsTall": null, "panelsWide": null}, {"bbox": {"x": 0.74, "y": 0.1, "width": 0.02, "height": 0.22}, "name": "Tower 4 LED", "notes": "Surface 2.75 m² — ~11 panels @ 0.5×0.5 m. Pixel: 128 x 1408p. 3.9 mm pixel pitch. Vertical tower column.", "widthM": 0.5, "heightM": 5.5, "confidence": 0.92, "panelsTall": null, "panelsWide": null}]}}	2026-05-05 10:52:33.261803+00	2026-05-05 10:52:35.144447+00
\.


--
-- Name: venue_memory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.venue_memory_id_seq', 2, true);


--
-- Name: brief_assignments brief_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_assignments
    ADD CONSTRAINT brief_assignments_pkey PRIMARY KEY (id);


--
-- Name: brief_room_assignments brief_room_assignments_brief_id_freelancer_user_id_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_room_assignments
    ADD CONSTRAINT brief_room_assignments_brief_id_freelancer_user_id_pk PRIMARY KEY (brief_id, freelancer_user_id);


--
-- Name: freelancer_profiles freelancer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.freelancer_profiles
    ADD CONSTRAINT freelancer_profiles_pkey PRIMARY KEY (user_id);


--
-- Name: gigs gigs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gigs
    ADD CONSTRAINT gigs_pkey PRIMARY KEY (id);


--
-- Name: project_briefs project_briefs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_briefs
    ADD CONSTRAINT project_briefs_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: venue_memory venue_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.venue_memory
    ADD CONSTRAINT venue_memory_pkey PRIMARY KEY (id);


--
-- Name: brief_assignments_brief_freelancer_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX brief_assignments_brief_freelancer_unique ON public.brief_assignments USING btree (brief_id, freelancer_user_id);


--
-- Name: brief_assignments_brief_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brief_assignments_brief_idx ON public.brief_assignments USING btree (brief_id);


--
-- Name: brief_assignments_freelancer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX brief_assignments_freelancer_idx ON public.brief_assignments USING btree (freelancer_user_id);


--
-- Name: gigs_brief_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gigs_brief_idx ON public.gigs USING btree (brief_id);


--
-- Name: gigs_freelancer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gigs_freelancer_idx ON public.gigs USING btree (freelancer_user_id);


--
-- Name: project_briefs_owner_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX project_briefs_owner_idx ON public.project_briefs USING btree (owner_user_id);


--
-- Name: projects_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_user_id_idx ON public.projects USING btree (user_id);


--
-- Name: venue_memory_user_venue_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX venue_memory_user_venue_key ON public.venue_memory USING btree (user_id, venue_key);


--
-- Name: brief_assignments brief_assignments_brief_id_project_briefs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_assignments
    ADD CONSTRAINT brief_assignments_brief_id_project_briefs_id_fk FOREIGN KEY (brief_id) REFERENCES public.project_briefs(id) ON DELETE CASCADE;


--
-- Name: brief_room_assignments brief_room_assignments_brief_id_project_briefs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.brief_room_assignments
    ADD CONSTRAINT brief_room_assignments_brief_id_project_briefs_id_fk FOREIGN KEY (brief_id) REFERENCES public.project_briefs(id) ON DELETE CASCADE;


--
-- Name: gigs gigs_brief_id_project_briefs_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gigs
    ADD CONSTRAINT gigs_brief_id_project_briefs_id_fk FOREIGN KEY (brief_id) REFERENCES public.project_briefs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict rbHzkvWaRJhHbJKN3mr29YobYrZeDwfEpg43rM9DZaYy0yZ2BMNFBPkm6psW31F

