import { useCallback, useMemo, useState, type ReactNode } from "react";
import { MasterCrewSheet } from "./MasterCrewSheet";
import { AdequacyPanel } from "./AdequacyPanel";
import {
  computeCrewTotals,
  formatCrewDayRate,
  type CrewMember,
} from "../lib/crew";

type Props = {
  crew: CrewMember[];
  onAdd: () => void;
  onUpdate: (id: string, patch: Partial<CrewMember>) => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
  /** Optional roster sidebar (e.g. <AvailableCrewSidebar/>). Rendered
   *  to the right of the master sheet on wide screens and stacked
   *  below on narrow ones. Kept as a slot so this view stays unaware
   *  of the freelancer-portal data layer. */
  directorySidebar?: ReactNode;
  /** Producer's active brief id from App.tsx. Threaded through to
   *  MasterCrewSheet so it can pull portal roster data. When null
   *  the sheet still renders the local CrewMember[] as a pure call
   *  sheet — useful day-1 before any brief is pushed. */
  activeBriefId?: string | null;
  /** Async token resolver from Clerk's `useAuth`. Only required when
   *  `activeBriefId` is set (then MasterCrewSheet uses it for the
   *  owner-only roster endpoint). */
  getToken?: () => Promise<string | null>;
  /** Project-scope numbers for the adequacy meter, derived in App.tsx
   *  from the rigging / LED / lighting / stage tabs. Optional — when
   *  missing the panel is hidden. */
  adequacyMetrics?: {
    hoistPoints: number;
    ledArea: number;
    stageArea: number;
    fixtureCount: number;
  };
};

const fmtNum = (n: number, d = 1) =>
  n.toLocaleString("en-US", { maximumFractionDigits: d });

/** Crew & Logistics view — one master sheet, one optional adequacy
 *  panel, one optional crew directory sidebar. The previous version
 *  stacked four sections (per-dept dashboard, RosterTable, AdequacyPanel,
 *  inline call sheet) which producers reported as confusing — they
 *  couldn't tell which one was the source of truth and felt they had
 *  to re-enter the same name in three places. This view replaces all
 *  four with a single MasterCrewSheet that shows everyone × everything,
 *  keeping the AdequacyPanel as a sidekick at the bottom (still
 *  useful, but no longer competing for the producer's attention). */
export function CrewReportView({
  crew,
  onAdd,
  onUpdate,
  onRemove,
  onDuplicate,
  directorySidebar,
  activeBriefId,
  getToken,
  adequacyMetrics,
}: Props) {
  const totals = useMemo(() => computeCrewTotals(crew), [crew]);
  // Headcount source for the adequacy meter: the merged roster the
  // master sheet is actually displaying (gig + local), bubbled up
  // from MasterCrewSheet via onMergedRolesChange. Falls back to the
  // local crew[] until the first roster fetch lands so the meter
  // still works on day-1 planning before any portal brief is
  // pushed. This fixes the architect-flagged inconsistency where
  // the panel could say "short by 2 riggers" while the visible
  // table showed enough people (because they were gig-only and not
  // mirrored into local rows).
  const localRoles = useMemo(() => crew.map((m) => m.role), [crew]);
  const [mergedRoles, setMergedRoles] = useState<ReadonlyArray<string> | null>(
    null,
  );
  const handleMergedRolesChange = useCallback(
    (roles: ReadonlyArray<string>) => setMergedRoles(roles),
    [],
  );
  const rosterRoles = mergedRoles ?? localRoles;

  // Default getToken so MasterCrewSheet's signature stays simple
  // (always defined). When the parent didn't pass one we fall back
  // to a no-op resolver — the sheet's fetch loop is already gated
  // on activeBriefId so the unauthenticated path is never reached.
  const tokenResolver =
    getToken ?? (async () => null);

  return (
    <div
      className={
        directorySidebar
          ? "led-report led-report-with-sidebar"
          : "led-report"
      }
    >
      <header className="led-report-header">
        <div>
          <h2>Crew &amp; Logistics</h2>
          <p className="led-report-sub">
            One sheet for the whole production: who's confirmed, what
            days they work, where they sleep, what they eat, and how to
            reach them. Print or save as PDF for the runner / hotel /
            catering handoff.
          </p>
        </div>
        <div className="led-report-meta">
          <span className="badge">
            <strong>{totals.count}</strong> crew
          </span>
          <span className="badge">
            <strong>{fmtNum(totals.totalHours, 1)}</strong> person-hours
          </span>
          <span className="badge">
            <strong>{formatCrewDayRate(totals.totalCost)}</strong> total
          </span>
        </div>
      </header>

      {/* Two-column layout: master sheet on the left, freelancer
          directory on the right. The grid collapses to a single column
          below the breakpoint defined in index.css so the sidebar
          stacks gracefully on iPad / phone. */}
      <div className="crew-layout">
        <div className="crew-layout-main">
          <MasterCrewSheet
            briefId={activeBriefId ?? null}
            getToken={tokenResolver}
            localCrew={crew}
            onAdd={onAdd}
            onUpdate={onUpdate}
            onRemove={onRemove}
            onDuplicate={onDuplicate}
            onMergedRolesChange={handleMergedRolesChange}
          />
          {/* Adequacy panel — kept as a sidekick BELOW the master
              sheet so it doesn't compete for attention. Still surfaces
              "you have 5 riggers, suggested 6–8" warnings, just no
              longer the first thing the producer sees. Hidden when
              the parent didn't pass derived metrics (e.g. on a fresh
              brief with no rigging/LED/stage data yet). */}
          {adequacyMetrics ? (
            <AdequacyPanel
              derived={adequacyMetrics}
              rosterRoles={rosterRoles}
            />
          ) : null}
        </div>
        {directorySidebar ? (
          <div className="crew-layout-aside">{directorySidebar}</div>
        ) : null}
      </div>
    </div>
  );
}
