import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { NumberField } from "./NumberField";
import {
  CUSTOM_PANEL_KEY,
  LED_PANEL_COLOR_PRESETS,
  LED_SCREEN_COLORS,
  NAME_SCALE_DEFAULT,
  NAME_SCALE_MAX,
  NAME_SCALE_MIN,
  PILL_CHAR_W_RATIO,
  PILL_PAD_X_RATIO,
  PILL_PAD_Y_RATIO,
  clampNameScale,
  type LedPanel,
  type LedPanelKey,
  type LedPanelPattern,
  type LedScreen,
  type LedScreenMarker,
  type LedSettings,
  type LedTotals,
  type LedCustomPanel,
  colLabel,
  computeScreenMetrics,
  panelCellColor,
  cellArrowDirection,
  type CellArrowDir,
  resolveScreenPanel,
  outputsForScreen,
  newMarkerId,
  nextMarkerIndex,
  // Shape / cable / processor — new in this build
  cellIndex,
  disabledCellSet,
  isCellDisabled,
  enabledPanelCount,
  computeShapeTemplate,
  computeScreenCableBOM,
  computeScreenProcessorCapacity,
  newPanelMarkerId,
  nextPanelMarkerIndex,
  LED_SHAPE_TEMPLATE_OPTIONS,
  NOVASTAR_PROCESSOR_CATALOG,
  NOVASTAR_PROCESSOR_OPTIONS,
  newProcessorId,
  SIGNAL_CABLE_LENGTH_M,
  POWER_TRUE1_CABLE_LENGTH_M,
  type LedShapeTemplate,
  type LedPanelMarker,
  type LedScreenProcessor,
  type ScreenProcessorCapacity,
  type NovastarProcessorModel,
} from "../lib/led";
import {
  LED_PROCESSORS,
  findProcessor,
  validateAgainstProcessor,
  type ProcessorCheckResult,
} from "../lib/ledProcessors";

type Props = {
  screens: LedScreen[];
  panels: LedPanel[];
  settings: LedSettings;
  totals: LedTotals;
  linkedCount: number;
  standaloneCount: number;
  /** Currently-selected screen id, or null for "no selection". Drives
   *  the highlight ring on the canvas and the row highlight in the
   *  table; also lets the producer click a screen on the visual to jump
   *  to its row. */
  selectedScreenId: string | null;
  onSelectScreen: (id: string | null) => void;
  onAddScreen: () => void;
  onUpdateScreen: (id: string, patch: Partial<LedScreen>) => void;
  onUpdateCustomPanel: (id: string, patch: Partial<LedCustomPanel>) => void;
  onRemoveScreen: (id: string) => void;
  onDuplicateScreen: (id: string) => void;
  onUpdateSettings: (patch: Partial<LedSettings>) => void;
  onExportScreen: (id: string) => void | Promise<void>;
  /** Clear every per-screen `posX`/`posY` so the canvas reverts to the
   *  default left-to-right auto-flow layout. */
  onResetScreenPositions: () => void;
  onJumpToRigging: () => void;
};

const PIXEL_FMT = new Intl.NumberFormat("en-US");
const fmt = (n: number, d = 1) =>
  n.toLocaleString("en-US", { maximumFractionDigits: d });

/** Which screen the user is currently in cell-edit mode on, and what
 *  the click action should be. `null` = passive (clicks select).
 *  Hoisted to the report root so arming a mode on row 1 cancels a
 *  stale mode on row 3, and so the canvas can read it to switch its
 *  cursor.
 *
 *  - `power` / `signal` → click on a CELL drops an anchored
 *    `LedPanelMarker` on that (col, row).
 *  - `shape`            → click on a CELL toggles its index in
 *    `disabledCells` (freeform shape edit).
 *
 *  The legacy free-coord `LedScreenMarker` rendering still works
 *  (drag/delete remain functional) but new clicks now produce the
 *  cell-anchored markers the user actually wants. */
export type PlaceModeKind = "power" | "signal" | "shape";
export type PlaceMode = {
  screenId: string;
  kind: PlaceModeKind;
} | null;

export function LedScreenReportView(props: Props) {
  const {
    screens,
    panels,
    settings,
    totals,
    linkedCount,
    standaloneCount,
    selectedScreenId,
    onSelectScreen,
    onAddScreen,
    onUpdateScreen,
    onUpdateCustomPanel,
    onRemoveScreen,
    onDuplicateScreen,
    onUpdateSettings,
    onExportScreen,
    onResetScreenPositions,
    onJumpToRigging,
  } = props;

  /** Whether any standalone screen has been manually positioned — drives
   *  the "Reset positions" button's enabled state above the canvas. */
  const anyPositioned = useMemo(
    () => screens.some((s) => s.posX !== undefined || s.posY !== undefined),
    [screens],
  );

  const [placeMode, setPlaceMode] = useState<PlaceMode>(null);

  /** Toggle the click-mode for a screen: `+P`, `+S`, or "Shape" arm
   *  cell-edit mode; clicking the same button twice (or arming a
   *  different button) cancels / replaces. Also called automatically
   *  whenever the user clicks the screen body so there's no orphaned
   *  armed state left after dropping a marker. */
  const togglePlaceMode = useCallback(
    (screenId: string, kind: PlaceModeKind) => {
      setPlaceMode((prev) =>
        prev && prev.screenId === screenId && prev.kind === kind
          ? null
          : { screenId, kind },
      );
    },
    [],
  );

  /** Drop a new cell-anchored marker on the (col, row) the producer
   *  clicked. Replaces any existing marker on the same cell+kind so
   *  re-clicking a cell re-uses the index instead of stacking. We do
   *  NOT auto-clear placeMode — the producer can rapid-fire several
   *  cells in a row without re-arming. */
  const addPanelMarker = useCallback(
    (
      screenId: string,
      kind: LedPanelMarker["kind"],
      col: number,
      row: number,
    ) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const list = screen.panelMarkers ?? [];
      // Replace if there's already a same-kind marker on this cell
      // (toggle-style; second click on same cell = remove).
      const existing = list.find(
        (mk) => mk.kind === kind && mk.col === col && mk.row === row,
      );
      if (existing) {
        onUpdateScreen(screenId, {
          panelMarkers: list.filter((mk) => mk.id !== existing.id),
        });
        return;
      }
      const next: LedPanelMarker = {
        id: newPanelMarkerId(),
        kind,
        index: nextPanelMarkerIndex(list, kind),
        col,
        row,
      };
      onUpdateScreen(screenId, { panelMarkers: [...list, next] });
    },
    [screens, onUpdateScreen],
  );

  const removePanelMarker = useCallback(
    (screenId: string, markerId: string) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const next = (screen.panelMarkers ?? []).filter(
        (m) => m.id !== markerId,
      );
      onUpdateScreen(screenId, { panelMarkers: next });
    },
    [screens, onUpdateScreen],
  );

  /** Toggle a single cell's ON/OFF state (freeform shape edit). When
   *  Shape mode is armed and the producer clicks a cell, we flip its
   *  index in `disabledCells`. */
  const toggleCell = useCallback(
    (screenId: string, col: number, row: number) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const idx = cellIndex(col, row, screen.panelsWide);
      const current = screen.disabledCells ?? [];
      const set = new Set(current);
      if (set.has(idx)) set.delete(idx);
      else set.add(idx);
      onUpdateScreen(screenId, {
        disabledCells: Array.from(set).sort((a, b) => a - b),
        // Hand-toggling a cell diverges from any preset template, so
        // we clear the saved template name; the brief falls back to
        // the generic "Custom shape" label as expected.
        shapeTemplate: undefined,
      });
    },
    [screens, onUpdateScreen],
  );

  /** Apply a preset shape template (L, U, T, +, stairs, ribbon,
   *  columns, rectangle). Overwrites any current `disabledCells` so
   *  the producer gets a clean shape every time. */
  const applyShapeTemplate = useCallback(
    (screenId: string, template: LedShapeTemplate) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      onUpdateScreen(screenId, {
        disabledCells: computeShapeTemplate(
          template,
          screen.panelsWide,
          screen.panelsTall,
        ),
        // Remember the producer's template choice so the brief can
        // label it (e.g. "L-shape" instead of generic "Custom shape").
        // Direct cell toggles below clear this back to undefined.
        shapeTemplate: template === "rectangle" ? undefined : template,
      });
    },
    [screens, onUpdateScreen],
  );

  /** Build by physical dimensions: round target W/H to whole panels.
   *  Optionally clears `disabledCells` at the same time so a re-build
   *  doesn't leave a stale L-shape lying around at the wrong size. */
  const applyBuildBySize = useCallback(
    (
      screenId: string,
      targetWidthM: number,
      targetHeightM: number,
      clearShape: boolean,
    ) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const panel = resolveScreenPanel(screen, panels);
      if (panel.physicalWidth <= 0 || panel.physicalHeight <= 0) return;
      const panelsWide = Math.max(
        1,
        Math.round(targetWidthM / panel.physicalWidth),
      );
      const panelsTall = Math.max(
        1,
        Math.round(targetHeightM / panel.physicalHeight),
      );
      onUpdateScreen(screenId, {
        panelsWide,
        panelsTall,
        ...(clearShape ? { disabledCells: [] } : {}),
      });
    },
    [screens, panels, onUpdateScreen],
  );

  const addProcessor = useCallback(
    (screenId: string, model: NovastarProcessorModel) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const list = screen.processors ?? [];
      const next: LedScreenProcessor = { id: newProcessorId(), model };
      onUpdateScreen(screenId, { processors: [...list, next] });
    },
    [screens, onUpdateScreen],
  );

  const removeProcessor = useCallback(
    (screenId: string, processorId: string) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      onUpdateScreen(screenId, {
        processors: (screen.processors ?? []).filter(
          (p) => p.id !== processorId,
        ),
      });
    },
    [screens, onUpdateScreen],
  );

  /** Drag-move the LEGACY free-coord markers (LedScreenMarker). Panel
   *  markers are anchored to a cell so they aren't draggable. */
  const moveMarker = useCallback(
    (screenId: string, markerId: string, x: number, y: number) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const next = (screen.markers ?? []).map((m) =>
        m.id === markerId
          ? { ...m, x: Math.min(1, Math.max(0, x)), y: Math.min(1, Math.max(0, y)) }
          : m,
      );
      onUpdateScreen(screenId, { markers: next });
    },
    [screens, onUpdateScreen],
  );

  /** Remove a LEGACY free-coord marker (alt-click / right-click). */
  const removeMarker = useCallback(
    (screenId: string, markerId: string) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const next = (screen.markers ?? []).filter((m) => m.id !== markerId);
      onUpdateScreen(screenId, { markers: next });
    },
    [screens, onUpdateScreen],
  );

  /** Wipe both legacy free-coord markers AND new cell-anchored panel
   *  markers in one go. The Clear button counts both kinds so the
   *  producer can't be left wondering "why is there still a P1?" after
   *  a clean. */
  const clearMarkers = useCallback(
    (screenId: string) => {
      const screen = screens.find((s) => s.id === screenId);
      if (!screen) return;
      const total =
        (screen.markers ?? []).length + (screen.panelMarkers ?? []).length;
      if (total === 0) return;
      if (
        !window.confirm(
          `Remove all power & signal markers from "${screen.name || "(unnamed)"}"?`,
        )
      ) {
        return;
      }
      onUpdateScreen(screenId, { markers: [], panelMarkers: [] });
    },
    [screens, onUpdateScreen],
  );

  return (
    <div className="led-report">
      <header className="led-report-header">
        <div>
          <h2>LED Screen Report</h2>
          <p className="led-report-sub">
            Pixel map generator for LED video systems. Define your screens,
            assign processor outputs, and review the visual layout.
          </p>
        </div>
        <div className="led-report-meta">
          <span className="badge">
            {linkedCount} linked · {standaloneCount} manual
          </span>
          <button className="btn btn-soft" onClick={onJumpToRigging}>
            ↗ Rigging Report
          </button>
        </div>
      </header>

      <LedDashboard totals={totals} settings={settings} />

      <ProcessorBanner
        totals={totals}
        settings={settings}
        screens={screens}
        panels={panels}
      />

      <ExportOptions
        settings={settings}
        onUpdateSettings={onUpdateSettings}
      />

      <section className="led-card">
        <div className="led-card-head">
          <h3>Screens</h3>
          <div className="led-controls">
            <button className="btn btn-primary" onClick={onAddScreen}>
              + Add Screen
            </button>
          </div>
        </div>

        {screens.length === 0 ? (
          <div className="led-empty">
            No screens yet. Add one with the button above, or add an LED row
            on the Rigging Report and it will appear here automatically.
          </div>
        ) : (
          <div className="led-table-wrap">
            <table className="led-table">
              <thead>
                <tr>
                  <th>Source</th>
                  <th>Name</th>
                  <th>Panel</th>
                  <th>Wide</th>
                  <th>Tall</th>
                  <th>Shape</th>
                  <th>Resolution</th>
                  <th>Size (m)</th>
                  <th>Output</th>
                  <th>Color</th>
                  <th>Notes</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {screens.map((s) => (
                  <ScreenRow
                    key={s.id}
                    screen={s}
                    panels={panels}
                    placeMode={placeMode}
                    isSelected={selectedScreenId === s.id}
                    onSelect={() => onSelectScreen(s.id)}
                    onUpdate={(patch) => onUpdateScreen(s.id, patch)}
                    onUpdateCustomPanel={(patch) =>
                      onUpdateCustomPanel(s.id, patch)
                    }
                    onRemove={() => onRemoveScreen(s.id)}
                    onDuplicate={() => onDuplicateScreen(s.id)}
                    onExport={() => onExportScreen(s.id)}
                    onTogglePlaceMode={(kind) => togglePlaceMode(s.id, kind)}
                    onClearMarkers={() => clearMarkers(s.id)}
                    onApplyShapeTemplate={(t) => applyShapeTemplate(s.id, t)}
                    onApplyBuildBySize={(w, h, clear) =>
                      applyBuildBySize(s.id, w, h, clear)
                    }
                    onAddProcessor={(model) => addProcessor(s.id, model)}
                    onRemoveProcessor={(pid) => removeProcessor(s.id, pid)}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {screens.length > 0 && (
        <section className="led-card">
          <div className="led-card-head">
            <h3>Pixel Map</h3>
            <span className="led-hint">
              Each cell is one panel. Columns are letters (A, B, C…), rows are
              numbers (1, 2, 3…). Click a screen to select it, drag the ⠿
              handle to reposition.
            </span>
            <div className="led-controls">
              {/* "Reset positions" returns the canvas to the default
                  left-to-right auto-flow. Disabled when nothing has been
                  dragged so the button doesn't feel like a noop. */}
              <button
                className="btn btn-soft btn-sm"
                type="button"
                onClick={onResetScreenPositions}
                disabled={!anyPositioned}
                title={
                  anyPositioned
                    ? "Clear every dragged position and return to auto-flow"
                    : "Nothing to reset — no screens have been dragged"
                }
              >
                Reset positions
              </button>
            </div>
          </div>
          <PixelMapCanvas
            screens={screens}
            panels={panels}
            settings={settings}
            placeMode={placeMode}
            selectedScreenId={selectedScreenId}
            onSelectScreen={onSelectScreen}
            onUpdateScreen={onUpdateScreen}
            onMoveMarker={moveMarker}
            onRemoveMarker={removeMarker}
            onAddPanelMarker={addPanelMarker}
            onRemovePanelMarker={removePanelMarker}
            onToggleCell={toggleCell}
          />
        </section>
      )}

      {screens.length > 0 && (
        <CableBracketBomCard screens={screens} panels={panels} />
      )}
    </div>
  );
}

function ProcessorBanner({
  totals,
  settings,
  screens,
  panels,
}: {
  totals: LedTotals;
  settings: LedSettings;
  screens: LedScreen[];
  panels: LedPanel[];
}) {
  const proc = findProcessor(settings.processorId);
  if (!proc) return null;
  if (totals.screens === 0) return null;

  // Recompute outputs at the PROCESSOR's per-port limit (e.g. 650 000
  // pixels for the Novastar MX series), so the comparison stays honest
  // even when the user's `portLimit` field is set to something else.
  const outputsAtProcLimit = screens.reduce(
    (sum, s) =>
      sum + outputsForScreen(s, settings, panels, proc.maxPixelsPerOutput),
    0,
  );

  const result: ProcessorCheckResult = validateAgainstProcessor(proc, {
    totalPixels: totals.pixels,
    outputsNeeded: outputsAtProcLimit,
    largestWidthPx: totals.largestWidthPx,
    largestHeightPx: totals.largestHeightPx,
    largestScreenPixels: totals.largestScreenPixels,
  });

  const utilizationPct = Math.min(999, Math.round(result.utilization * 100));
  const outputsPct = Math.min(999, Math.round(result.outputsUtilization * 100));

  return (
    <section
      className={`led-proc-banner is-${result.level}`}
      aria-live="polite"
    >
      <div className="led-proc-head">
        <div className="led-proc-title">
          <span className="led-proc-dot" aria-hidden />
          <span>
            <strong>{proc.name}</strong>
            <span className="led-proc-blurb"> — {proc.blurb}</span>
          </span>
        </div>
        <div className="led-proc-status">
          {result.level === "ok" && "Fits comfortably"}
          {result.level === "warn" && "Fits — near limits"}
          {result.level === "fail" && "Does NOT fit"}
        </div>
      </div>
      <div className="led-proc-meters">
        <Meter
          label="Pixels"
          used={result.totalPixels}
          cap={proc.totalPixels}
          pct={utilizationPct}
          fmt={(n) => PIXEL_FMT.format(n)}
        />
        <Meter
          label="Outputs"
          used={result.outputsNeeded}
          cap={proc.outputs}
          pct={outputsPct}
          fmt={(n) => `${n}`}
        />
        <div className="led-proc-bound">
          <div className="led-proc-bound-label">Largest screen</div>
          <div className="led-proc-bound-value">
            {totals.largestWidthPx.toLocaleString()} ×{" "}
            {totals.largestHeightPx.toLocaleString()} px
          </div>
          <div className="led-proc-bound-sub">
            Max canvas: {proc.maxWidthPx.toLocaleString()} ×{" "}
            {proc.maxHeightPx.toLocaleString()} px
          </div>
        </div>
      </div>
      {result.issues.length > 0 && (
        <ul className="led-proc-issues">
          {result.issues.map((iss, i) => (
            <li key={i} className={`led-proc-issue is-${iss.level}`}>
              {iss.message}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function Meter({
  label,
  used,
  cap,
  pct,
  fmt,
}: {
  label: string;
  used: number;
  cap: number;
  pct: number;
  fmt: (n: number) => string;
}) {
  const overcap = used > cap;
  return (
    <div className="led-proc-meter">
      <div className="led-proc-meter-row">
        <span className="led-proc-meter-label">{label}</span>
        <span className="led-proc-meter-value">
          {fmt(used)} / {fmt(cap)} ({pct}%)
        </span>
      </div>
      <div className="led-proc-meter-track">
        <div
          className={`led-proc-meter-fill ${overcap ? "is-over" : pct > 90 ? "is-warn" : "is-ok"}`}
          style={{ width: `${Math.min(100, pct)}%` }}
        />
      </div>
    </div>
  );
}

function LedDashboard({
  totals,
  settings,
}: {
  totals: LedTotals;
  settings: LedSettings;
}) {
  return (
    <div className="led-dashboard">
      <Stat label="Screens" value={fmt(totals.screens, 0)} />
      <Stat label="Panels" value={fmt(totals.panels, 0)} />
      <Stat label="Total pixels" value={PIXEL_FMT.format(totals.pixels)} />
      <Stat label="Area" value={`${fmt(totals.areaM2, 1)} m²`} />
      <Stat label="Weight" value={`${fmt(totals.weightKg, 1)} kg`} />
      <Stat label="Power" value={`${fmt(totals.powerW / 1000, 2)} kW`} />
      <Stat
        label="Outputs needed"
        value={fmt(totals.portsNeeded, 0)}
        sub={`@ ${PIXEL_FMT.format(settings.portLimit)} px/output`}
      />
    </div>
  );
}

function Stat({
  label,
  value,
  sub,
}: {
  label: string;
  value: string;
  sub?: string;
}) {
  return (
    <div className="led-stat">
      <div className="led-stat-label">{label}</div>
      <div className="led-stat-value">{value}</div>
      {sub && <div className="led-stat-sub">{sub}</div>}
    </div>
  );
}

function ScreenRow({
  screen,
  panels,
  placeMode,
  isSelected,
  onSelect,
  onUpdate,
  onUpdateCustomPanel,
  onRemove,
  onDuplicate,
  onExport,
  onTogglePlaceMode,
  onClearMarkers,
  onApplyShapeTemplate,
  onApplyBuildBySize,
  onAddProcessor,
  onRemoveProcessor,
}: {
  screen: LedScreen;
  panels: LedPanel[];
  placeMode: PlaceMode;
  isSelected: boolean;
  onSelect: () => void;
  onUpdate: (patch: Partial<LedScreen>) => void;
  onUpdateCustomPanel: (patch: Partial<LedCustomPanel>) => void;
  onRemove: () => void;
  onDuplicate: () => void;
  onExport: () => void | Promise<void>;
  onTogglePlaceMode: (kind: PlaceModeKind) => void;
  onClearMarkers: () => void;
  onApplyShapeTemplate: (template: LedShapeTemplate) => void;
  onApplyBuildBySize: (
    targetWidthM: number,
    targetHeightM: number,
    clearShape: boolean,
  ) => void;
  onAddProcessor: (model: NovastarProcessorModel) => void;
  onRemoveProcessor: (processorId: string) => void;
}) {
  const panel = resolveScreenPanel(screen, panels);
  const m = computeScreenMetrics(screen, panels);
  const isCustom = screen.panelKey === CUSTOM_PANEL_KEY;
  const nameScale = clampNameScale(screen.nameScale);
  const markers = screen.markers ?? [];
  const panelMarkers = screen.panelMarkers ?? [];
  // Counts for the row's +P/+S badges include BOTH legacy free-coord
  // markers and the new cell-anchored ones, so the producer always
  // sees an accurate total no matter which kind exists.
  const powerCount =
    markers.filter((mk) => mk.kind === "power").length +
    panelMarkers.filter((mk) => mk.kind === "power").length;
  const signalCount =
    markers.filter((mk) => mk.kind === "signal").length +
    panelMarkers.filter((mk) => mk.kind === "signal").length;
  const totalMarkerCount = markers.length + panelMarkers.length;
  const armed: PlaceModeKind | null =
    placeMode && placeMode.screenId === screen.id ? placeMode.kind : null;
  const [shapeOpen, setShapeOpen] = useState(false);
  // Build-by-size form state. Pre-fill with the screen's current
  // physical width/height so the producer can tweak rather than
  // re-type from scratch on every open.
  const currentWidthM = screen.panelsWide * panel.physicalWidth;
  const currentHeightM = screen.panelsTall * panel.physicalHeight;
  const [targetW, setTargetW] = useState<string>(currentWidthM.toFixed(2));
  const [targetH, setTargetH] = useState<string>(currentHeightM.toFixed(2));
  const [clearShapeOnApply, setClearShapeOnApply] = useState(true);
  // Sync the target inputs whenever the parent screen's panel choice
  // or panel count changes outside the popover (e.g. user typed in
  // Wide/Tall directly).
  useEffect(() => {
    if (!shapeOpen) {
      setTargetW(currentWidthM.toFixed(2));
      setTargetH(currentHeightM.toFixed(2));
    }
  }, [shapeOpen, currentWidthM, currentHeightM]);
  const disabledCount = (screen.disabledCells ?? []).length;
  const processors = screen.processors ?? [];
  const cap = computeScreenProcessorCapacity(processors);
  // Required outputs at the conservative per-output pixel cap from the
  // attached processors (e.g. 650 000 px/output for Novastar MX series).
  // We check this in addition to the pixel-cap so a screen that fits in
  // total pixels but needs more than the available daisy-chain outputs
  // (e.g. 1× MX30 = 4 outputs but the wall needs 8) still triggers the
  // warning.
  const requiredOutputs =
    processors.length > 0 && cap.worstPixelsPerOutput > 0
      ? Math.ceil(m.pixels / cap.worstPixelsPerOutput)
      : 0;
  const processorUnder =
    processors.length > 0 &&
    ((cap.maxPixels > 0 && m.pixels > cap.maxPixels) ||
      (cap.outputs > 0 && requiredOutputs > cap.outputs));

  /** Compose the row class so we can layer "linked" and "selected"
   *  styling without repeating the conditional. */
  const rowClass = [
    screen.linked ? "led-row-linked" : "",
    isSelected ? "led-row-selected" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <>
      <tr
        className={rowClass}
        onClick={onSelect}
        title={
          isSelected
            ? "Selected — also highlighted on the pixel-map canvas below"
            : "Click to select on the pixel-map canvas"
        }
      >
        <td>
          {screen.linked ? (
            <span className="badge badge-linked" title="From rigging report">
              Linked
            </span>
          ) : (
            <span className="badge badge-manual">Manual</span>
          )}
        </td>
        <td>
          <input
            className="led-input led-input-name"
            type="text"
            value={screen.name}
            onChange={(e) => onUpdate({ name: e.target.value })}
            placeholder="e.g. Main, IMAG, Side L…"
            title="This name appears as the centered pill on the pixel map and on the exported PNG."
          />
          {/* Pill-size slider — sits directly under the name input so the
              relationship is obvious. The number on the right doubles as
              a "reset to 1×" button when the user wants the default. */}
          <div className="led-pill-scale" title="Resize the name pill on the visual / PNG export">
            <span className="led-pill-scale-label">Pill size</span>
            <input
              className="led-pill-scale-range"
              type="range"
              min={NAME_SCALE_MIN}
              max={NAME_SCALE_MAX}
              step={0.1}
              value={nameScale}
              onChange={(e) =>
                onUpdate({ nameScale: Number(e.target.value) })
              }
              aria-label={`Name pill size for ${screen.name || "screen"}`}
            />
            <button
              type="button"
              className="led-pill-scale-value"
              onClick={() => onUpdate({ nameScale: NAME_SCALE_DEFAULT })}
              title="Reset to 1×"
            >
              {nameScale.toFixed(1)}×
            </button>
          </div>
        </td>
        <td>
          <select
            className="led-input"
            value={screen.panelKey}
            onChange={(e) =>
              onUpdate({ panelKey: e.target.value as LedPanelKey })
            }
          >
            {/* If the stored key isn't in the current library (e.g. an
                inventory item was renamed), surface it as a placeholder
                so the user can see it before re-picking. */}
            {!panels.some((p) => p.key === screen.panelKey) && (
              <option value={screen.panelKey}>
                {screen.panelKey} (missing)
              </option>
            )}
            {panels.map((p) => (
              <option key={p.key} value={p.key}>
                {p.name}
              </option>
            ))}
          </select>
        </td>
        <td>
          <NumberField
            className="led-input led-input-num"
            min={1}
            value={screen.panelsWide}
            transform={(n) => Math.max(1, Math.round(n || 1))}
            emptyValue={1}
            onCommit={(panelsWide) => onUpdate({ panelsWide })}
          />
        </td>
        <td>
          <NumberField
            className="led-input led-input-num"
            min={1}
            value={screen.panelsTall}
            transform={(n) => Math.max(1, Math.round(n || 1))}
            emptyValue={1}
            onCommit={(panelsTall) => onUpdate({ panelsTall })}
          />
        </td>
        {/* Shape cell — opens a popover with build-by-size + template
            chips, and arms a "Shape" cell-toggle mode for freeform
            on/off cabinets. The "Shape…" button is rendered next to
            the small "Edit" toggle so the producer can do template
            work and free-toggle from one place. */}
        <td className="led-shape-cell">
          <div className="led-shape-row">
            <button
              type="button"
              className={`btn btn-sm ${shapeOpen ? "btn-primary" : "btn-soft"}`}
              onClick={(e) => {
                e.stopPropagation();
                setShapeOpen((v) => !v);
              }}
              title="Open shape templates and build-by-size controls"
            >
              Shape…
            </button>
            <button
              type="button"
              className={`btn btn-sm ${armed === "shape" ? "is-armed btn-primary" : "btn-soft"}`}
              onClick={(e) => {
                e.stopPropagation();
                onTogglePlaceMode("shape");
              }}
              title={
                armed === "shape"
                  ? "Cancel — click here to stop toggling cells"
                  : "Click cells on the visual below to toggle them ON/OFF"
              }
            >
              {armed === "shape" ? "Click cells…" : "Edit"}
            </button>
          </div>
          {disabledCount > 0 && (
            <div className="led-sub" title="Cabinets currently OFF">
              −{disabledCount} off
            </div>
          )}
          {shapeOpen && (
            <ShapePopover
              currentWidthM={currentWidthM}
              currentHeightM={currentHeightM}
              targetW={targetW}
              targetH={targetH}
              setTargetW={setTargetW}
              setTargetH={setTargetH}
              clearShapeOnApply={clearShapeOnApply}
              setClearShapeOnApply={setClearShapeOnApply}
              onApplyBuildBySize={() => {
                const w = Number(targetW);
                const h = Number(targetH);
                if (Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0) {
                  onApplyBuildBySize(w, h, clearShapeOnApply);
                }
              }}
              onApplyTemplate={(t) => onApplyShapeTemplate(t)}
              onClose={() => setShapeOpen(false)}
            />
          )}
        </td>
        <td className="led-num">
          {PIXEL_FMT.format(m.pixelsX)} × {PIXEL_FMT.format(m.pixelsY)}
          <div className="led-sub">
            {PIXEL_FMT.format(m.pixels)} px · {m.panels} panels
          </div>
        </td>
        <td className="led-num">
          {fmt(m.widthM, 2)} × {fmt(m.heightM, 2)}
          <div className="led-sub">{fmt(m.areaM2, 2)} m²</div>
        </td>
        <td>
          <input
            className="led-input led-input-num"
            type="number"
            min={1}
            placeholder="—"
            value={screen.outputIndex ?? ""}
            onChange={(e) => {
              const v = e.target.value;
              onUpdate({
                outputIndex:
                  v === "" ? null : Math.max(1, Number(v) || 1),
              });
            }}
          />
        </td>
        <td>
          {/* Top row — original badge-color swatches. Drives the small
              circle that shows the screen's processor-output number on
              the canvas. Kept for backwards compatibility with screens
              created before per-screen panel presets existed. */}
          <div className="led-color-picker">
            {LED_SCREEN_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                className={`led-color-swatch ${screen.color === c ? "is-active" : ""}`}
                style={{ background: c }}
                onClick={(e) => {
                  // Stop the row-level click handler from firing (which
                  // would also select the screen — fine, but leave the
                  // intent unambiguous).
                  e.stopPropagation();
                  onUpdate({ color: c });
                }}
                aria-label={`Color ${c}`}
              />
            ))}
          </div>
          {/* Bottom row — dual-color panel-grid presets. Picking one
              overrides the global ledSettings panel colours for THIS
              screen only, which is what makes a 3-screen import look
              visually distinct on the canvas. The "Auto" chip clears
              the override and falls back to the global setting. */}
          <div className="led-preset-picker" aria-label="Panel grid preset">
            <button
              type="button"
              className={`led-preset-chip is-auto ${
                screen.panelColorDark === undefined &&
                screen.panelColorLight === undefined
                  ? "is-active"
                  : ""
              }`}
              onClick={(e) => {
                e.stopPropagation();
                onUpdate({
                  panelColorDark: undefined,
                  panelColorLight: undefined,
                });
              }}
              title="Use the global panel colours from Export options"
            >
              Auto
            </button>
            {LED_PANEL_COLOR_PRESETS.map((p) => {
              const active =
                (screen.panelColorDark ?? "").toLowerCase() ===
                  p.dark.toLowerCase() &&
                (screen.panelColorLight ?? "").toLowerCase() ===
                  p.light.toLowerCase();
              return (
                <button
                  key={p.label}
                  type="button"
                  className={`led-preset-chip ${active ? "is-active" : ""}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onUpdate({
                      panelColorDark: p.dark,
                      panelColorLight: p.light,
                      // Mirror the badge color to the preset's light
                      // value too — keeps the table swatches and the
                      // visual in sync after a one-click change.
                      color: p.light,
                    });
                  }}
                  title={`${p.label} preset`}
                  style={{
                    background: `linear-gradient(135deg, ${p.dark} 0%, ${p.dark} 50%, ${p.light} 50%, ${p.light} 100%)`,
                  }}
                  aria-label={`${p.label} preset`}
                />
              );
            })}
          </div>
        </td>
        <td>
          <input
            className="led-input"
            type="text"
            value={screen.notes}
            onChange={(e) => onUpdate({ notes: e.target.value })}
            placeholder="Position, notes…"
          />
        </td>
        <td className="led-actions">
          {/* Cable-marker toolbar — visible per row so the producer can
              annotate one screen without disturbing markers on others.
              `armed` highlights whichever button is currently in
              placement mode; clicking it again cancels. */}
          <div
            className="led-marker-toolbar"
            role="group"
            aria-label={`Power and signal markers for ${screen.name || "screen"}`}
          >
            <button
              type="button"
              className={`btn btn-sm led-marker-btn led-marker-btn-power ${armed === "power" ? "is-armed" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                onTogglePlaceMode("power");
              }}
              title={
                armed === "power"
                  ? "Cancel — click here to stop placing power markers"
                  : "Click, then click a CABINET on the visual to mark its power feed (P1, P2…). Click the same cabinet again to remove."
              }
            >
              {armed === "power" ? "Click cell…" : `+P${powerCount > 0 ? ` (${powerCount})` : ""}`}
            </button>
            <button
              type="button"
              className={`btn btn-sm led-marker-btn led-marker-btn-signal ${armed === "signal" ? "is-armed" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                onTogglePlaceMode("signal");
              }}
              title={
                armed === "signal"
                  ? "Cancel — click here to stop placing signal markers"
                  : "Click, then click a CABINET on the visual to mark its signal feed (S1, S2…). Click the same cabinet again to remove."
              }
            >
              {armed === "signal" ? "Click cell…" : `+S${signalCount > 0 ? ` (${signalCount})` : ""}`}
            </button>
            <button
              type="button"
              className="btn btn-soft btn-sm"
              onClick={(e) => {
                e.stopPropagation();
                onClearMarkers();
              }}
              disabled={totalMarkerCount === 0}
              title="Remove every power & signal marker on this screen"
            >
              Clear
            </button>
          </div>
          <button
            className="btn btn-primary btn-sm"
            onClick={() => onExport()}
            title="Export PNG pixel map"
          >
            PNG
          </button>
          <button
            className="btn btn-soft btn-sm"
            onClick={onDuplicate}
            title="Duplicate this screen"
          >
            Copy
          </button>
          {!screen.linked && (
            <button
              className="btn btn-danger btn-sm"
              onClick={() => {
                if (
                  window.confirm(
                    `Delete screen "${screen.name || "(unnamed)"}"? This can't be undone.`,
                  )
                ) {
                  onRemove();
                }
              }}
              title="Delete this screen"
            >
              Delete
            </button>
          )}
        </td>
      </tr>
      {/* Per-screen processors strip — sits directly under the main
          row so the producer can attach 1× MX40 + 1× MX30 to one
          screen without leaving the table. Capacity is computed live
          and a red badge appears if the screen exceeds the attached
          processors' combined pixel cap. */}
      <tr className="led-row-procs">
        <td colSpan={12}>
          <ProcessorsStrip
            processors={processors}
            requiredPixels={m.pixels}
            cap={cap}
            isUnder={processorUnder}
            onAdd={onAddProcessor}
            onRemove={onRemoveProcessor}
          />
        </td>
      </tr>
      {isCustom && (
        <tr className="led-row-custom">
          <td colSpan={12}>
            <div className="led-custom-panel">
              <strong>Custom panel:</strong>
              <label>
                Pixels W
                <NumberField
                  min={1}
                  value={panel.pixelWidth}
                  transform={(n) => Math.max(1, Math.round(n || 1))}
                  emptyValue={1}
                  onCommit={(pixelWidth) =>
                    onUpdateCustomPanel({ pixelWidth })
                  }
                />
              </label>
              <label>
                Pixels H
                <NumberField
                  min={1}
                  value={panel.pixelHeight}
                  transform={(n) => Math.max(1, Math.round(n || 1))}
                  emptyValue={1}
                  onCommit={(pixelHeight) =>
                    onUpdateCustomPanel({ pixelHeight })
                  }
                />
              </label>
              <label>
                Width (m)
                <NumberField
                  min={0.01}
                  step={0.01}
                  value={panel.physicalWidth}
                  transform={(n) => Math.max(0.01, n || 0.5)}
                  emptyValue={0.5}
                  onCommit={(physicalWidth) =>
                    onUpdateCustomPanel({ physicalWidth })
                  }
                />
              </label>
              <label>
                Height (m)
                <NumberField
                  min={0.01}
                  step={0.01}
                  value={panel.physicalHeight}
                  transform={(n) => Math.max(0.01, n || 0.5)}
                  emptyValue={0.5}
                  onCommit={(physicalHeight) =>
                    onUpdateCustomPanel({ physicalHeight })
                  }
                />
              </label>
              <label>
                Weight (kg)
                <NumberField
                  min={0}
                  step={0.1}
                  value={panel.weight}
                  transform={(n) => Math.max(0, n || 0)}
                  emptyValue={0}
                  onCommit={(weight) =>
                    onUpdateCustomPanel({ weight })
                  }
                />
              </label>
              <label>
                Power (W)
                <NumberField
                  min={0}
                  step={1}
                  value={panel.power}
                  transform={(n) => Math.max(0, n || 0)}
                  emptyValue={0}
                  onCommit={(power) =>
                    onUpdateCustomPanel({ power })
                  }
                />
              </label>
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

function PixelMapCanvas({
  screens,
  panels,
  settings,
  placeMode,
  selectedScreenId,
  onSelectScreen,
  onUpdateScreen,
  onMoveMarker,
  onRemoveMarker,
  onAddPanelMarker,
  onRemovePanelMarker,
  onToggleCell,
}: {
  screens: LedScreen[];
  panels: LedPanel[];
  settings: LedSettings;
  placeMode: PlaceMode;
  selectedScreenId: string | null;
  onSelectScreen: (id: string | null) => void;
  onUpdateScreen: (id: string, patch: Partial<LedScreen>) => void;
  onMoveMarker: (screenId: string, markerId: string, x: number, y: number) => void;
  onRemoveMarker: (screenId: string, markerId: string) => void;
  onAddPanelMarker: (
    screenId: string,
    kind: LedPanelMarker["kind"],
    col: number,
    row: number,
  ) => void;
  onRemovePanelMarker: (screenId: string, markerId: string) => void;
  onToggleCell: (screenId: string, col: number, row: number) => void;
}) {
  /** Outer SVG ref — used by the drag handler to translate client-pixel
   *  pointer movement into the SVG's user-space units (which is what
   *  `posX`/`posY` are stored in). */
  const svgRef = useRef<SVGSVGElement | null>(null);

  const layout = useMemo(() => {
    const SCALE = 70; // px per meter
    const GAP = 30; // px gap between screens
    const TOP = 60; // px reserved for output badge above each screen
    const PAD = 20;

    let cursorX = PAD;
    let maxBottom = 0;
    let minLeft = PAD;
    let minTop = TOP + PAD;

    // First pass — auto-flow positions every screen left-to-right, but
    // skips the flow advance for screens that carry an explicit
    // posX/posY override. Those screens are placed at their stored
    // coordinates and contribute to the canvas bounds rather than the
    // cursor, so dragging one out of the row doesn't leave a gap in
    // the auto-flow row.
    const items = screens.map((s) => {
      const panel = resolveScreenPanel(s, panels);
      const screenWidthPx = s.panelsWide * panel.physicalWidth * SCALE;
      const screenHeightPx = s.panelsTall * panel.physicalHeight * SCALE;
      const cellW = panel.physicalWidth * SCALE;
      const cellH = panel.physicalHeight * SCALE;

      let x: number;
      let y: number;
      const positioned = s.posX !== undefined || s.posY !== undefined;
      if (positioned) {
        x = s.posX ?? cursorX;
        y = s.posY ?? TOP + PAD;
      } else {
        x = cursorX;
        y = TOP + PAD;
        cursorX += screenWidthPx + GAP;
      }

      maxBottom = Math.max(maxBottom, y + screenHeightPx);
      minLeft = Math.min(minLeft, x);
      minTop = Math.min(minTop, y);

      return {
        screen: s,
        panel,
        x,
        y,
        width: screenWidthPx,
        height: screenHeightPx,
        cellW,
        cellH,
        positioned,
      } as SvgItem;
    });

    const rightEdge = Math.max(
      cursorX - GAP + PAD,
      ...items.map((it) => it.x + it.width + PAD),
      400,
    );
    // Allow negative posX/posY to grow the viewBox to the left/top so
    // the user can drag a screen anywhere without it disappearing
    // off-canvas.
    const minX = Math.min(0, minLeft - PAD);
    // Reserve TOP above the topmost element so the output badge / drag
    // handle for that screen still has room.
    const minY = Math.min(0, minTop - TOP);
    const totalWidth = Math.max(rightEdge - minX, 400);
    const totalHeight = Math.max(maxBottom + PAD - minY, 200);

    return { items, totalWidth, totalHeight, minX, minY };
  }, [screens, panels]);

  /** Drag state lives in a ref to avoid re-installing the window
   *  pointermove listener on every move (which would otherwise cause
   *  the listener to drop the rapid stream of move events generated
   *  during a fast drag). The `dragId` state below is only used for
   *  the visual "is dragging" halo and updates exactly twice per drag
   *  (start + end), keeping React renders cheap. */
  const dragRef = useRef<{
    screenId: string;
    pointerId: number;
    offsetX: number;
    offsetY: number;
  } | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);

  // Latest layout is also captured in a ref so the window pointermove
  // listener (installed once) can map client coords to SVG user-space
  // using the freshest viewBox values without needing to re-attach.
  const layoutRef = useRef(layout);
  useEffect(() => {
    layoutRef.current = layout;
  }, [layout]);

  // onUpdateScreen also goes through a ref so the install-once
  // listener always calls the freshest patcher, even after parent
  // re-renders.
  const onUpdateScreenRef = useRef(onUpdateScreen);
  useEffect(() => {
    onUpdateScreenRef.current = onUpdateScreen;
  }, [onUpdateScreen]);

  /** Map a client-pixel pointer position to the SVG's user-space
   *  coordinate system using the latest layout. */
  const clientToSvg = useCallback(
    (clientX: number, clientY: number): { x: number; y: number } | null => {
      const svg = svgRef.current;
      if (!svg) return null;
      const rect = svg.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return null;
      const lay = layoutRef.current;
      const userX =
        ((clientX - rect.left) / rect.width) * lay.totalWidth + lay.minX;
      const userY =
        ((clientY - rect.top) / rect.height) * lay.totalHeight + lay.minY;
      return { x: userX, y: userY };
    },
    [],
  );

  /** Install pointermove / pointerup listeners exactly once for the
   *  lifetime of this canvas. They no-op when there is no active drag,
   *  so they're effectively free when idle. */
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      const d = dragRef.current;
      if (!d) return;
      const pt = clientToSvg(e.clientX, e.clientY);
      if (!pt) return;
      onUpdateScreenRef.current(d.screenId, {
        posX: pt.x - d.offsetX,
        posY: pt.y - d.offsetY,
      });
    };
    const onUp = () => {
      if (dragRef.current) {
        dragRef.current = null;
        setDragId(null);
      }
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
  }, [clientToSvg]);

  const handleHandlePointerDown = useCallback(
    (
      screenId: string,
      itemX: number,
      itemY: number,
      e: React.PointerEvent,
    ) => {
      // Defense-in-depth — ScreenSvg already hides the handle for
      // linked screens, but a guard here ensures the drag never
      // starts even if the handle is somehow still reachable
      // (browser quirks, future regressions, etc.). Linked screens
      // don't store posX/posY on the LED tab, so dragging would be
      // a no-op with confusing visual feedback.
      if (screenId.startsWith("led-linked-")) return;
      e.stopPropagation();
      e.preventDefault();
      const pt = clientToSvg(e.clientX, e.clientY);
      if (!pt) return;
      onSelectScreen(screenId);
      dragRef.current = {
        screenId,
        pointerId: e.pointerId,
        offsetX: pt.x - itemX,
        offsetY: pt.y - itemY,
      };
      setDragId(screenId);
    },
    [clientToSvg, onSelectScreen],
  );

  return (
    <div className="led-canvas-wrap">
      <svg
        ref={svgRef}
        className="led-canvas"
        viewBox={`${layout.minX} ${layout.minY} ${layout.totalWidth} ${layout.totalHeight}`}
        preserveAspectRatio="xMidYMid meet"
        role="img"
        aria-label="Pixel map of LED screens"
        onClick={(e) => {
          // Click on empty canvas = clear selection. Children stop
          // propagation when the user clicks a screen, so this only
          // fires on the SVG background itself.
          if (e.target === e.currentTarget) onSelectScreen(null);
        }}
      >
        {layout.items.map((item) => (
          <ScreenSvg
            key={item.screen.id}
            item={item}
            panels={panels}
            settings={settings}
            placeMode={placeMode}
            isSelected={selectedScreenId === item.screen.id}
            isDragging={dragId === item.screen.id}
            onSelect={() => onSelectScreen(item.screen.id)}
            onHandlePointerDown={(e) =>
              handleHandlePointerDown(item.screen.id, item.x, item.y, e)
            }
            onMoveMarker={onMoveMarker}
            onRemoveMarker={onRemoveMarker}
            onAddPanelMarker={onAddPanelMarker}
            onRemovePanelMarker={onRemovePanelMarker}
            onToggleCell={onToggleCell}
          />
        ))}
      </svg>
    </div>
  );
}

type SvgItem = {
  screen: LedScreen;
  panel: LedPanel;
  x: number;
  y: number;
  width: number;
  height: number;
  cellW: number;
  cellH: number;
  /** True when the screen has an explicit posX/posY override and is
   *  rendered outside the auto-flow row. Currently informational —
   *  reserved for future styling decisions (e.g. a "manually placed"
   *  hint badge). */
  positioned: boolean;
};

function ScreenSvg({
  item,
  panels,
  settings,
  placeMode,
  isSelected,
  isDragging,
  onSelect,
  onHandlePointerDown,
  onMoveMarker,
  onRemoveMarker,
  onAddPanelMarker,
  onRemovePanelMarker,
  onToggleCell,
}: {
  item: SvgItem;
  panels: LedPanel[];
  settings: LedSettings;
  placeMode: PlaceMode;
  isSelected: boolean;
  isDragging: boolean;
  onSelect: () => void;
  onHandlePointerDown: (e: React.PointerEvent) => void;
  onMoveMarker: (screenId: string, markerId: string, x: number, y: number) => void;
  onRemoveMarker: (screenId: string, markerId: string) => void;
  onAddPanelMarker: (
    screenId: string,
    kind: LedPanelMarker["kind"],
    col: number,
    row: number,
  ) => void;
  onRemovePanelMarker: (screenId: string, markerId: string) => void;
  onToggleCell: (screenId: string, col: number, row: number) => void;
}) {
  const { screen, x, y, width, height, cellW, cellH } = item;
  /** Per-screen panel colours override the global ledSettings ones when
   *  present (set via the per-row preset picker, the PDF importer, or
   *  the Add-Screen action). Falls back per field so a screen can
   *  override only one of the two and inherit the other. */
  const screenColorDark = screen.panelColorDark ?? settings.panelColorDark;
  const screenColorLight = screen.panelColorLight ?? settings.panelColorLight;
  const armed: PlaceModeKind | null =
    placeMode && placeMode.screenId === screen.id ? placeMode.kind : null;
  /** The transparent overlay rect's client bounding box is the source
   *  of truth for "where on the screen did the user click?" — using it
   *  also handles the SVG's `preserveAspectRatio` scaling correctly,
   *  whereas a viewBox-based math conversion would need extra work. */
  const overlayRectRef = useRef<SVGRectElement | null>(null);
  const [draggingMarkerId, setDraggingMarkerId] = useState<string | null>(
    null,
  );

  const screenId = screen.id;
  const markers = screen.markers ?? [];
  const panelMarkers = screen.panelMarkers ?? [];

  /** Convert a pointer event into normalised coords inside the screen
   *  rect. Returns null if the overlay isn't mounted yet (e.g. during
   *  the initial render between effects). */
  const eventToNorm = useCallback(
    (e: { clientX: number; clientY: number }): { x: number; y: number } | null => {
      const rect = overlayRectRef.current?.getBoundingClientRect();
      if (!rect || rect.width <= 0 || rect.height <= 0) return null;
      return {
        x: (e.clientX - rect.left) / rect.width,
        y: (e.clientY - rect.top) / rect.height,
      };
    },
    [],
  );

  /** Translate a pointer event into the (col, row) of the cell it hit.
   *  Returns null when the overlay isn't mounted or the click missed
   *  the screen. Clamps so an off-by-one pixel near the edge still
   *  registers on the boundary cell instead of returning out-of-range. */
  const eventToCell = useCallback(
    (e: { clientX: number; clientY: number }): { col: number; row: number } | null => {
      const norm = eventToNorm(e);
      if (!norm) return null;
      const col = Math.min(
        screen.panelsWide - 1,
        Math.max(0, Math.floor(norm.x * screen.panelsWide)),
      );
      const row = Math.min(
        screen.panelsTall - 1,
        Math.max(0, Math.floor(norm.y * screen.panelsTall)),
      );
      return { col, row };
    },
    [eventToNorm, screen.panelsWide, screen.panelsTall],
  );

  const handleOverlayClick = useCallback(
    (e: React.MouseEvent<SVGRectElement>) => {
      if (!armed) return;
      const cell = eventToCell(e);
      if (!cell) return;
      if (armed === "shape") {
        onToggleCell(screenId, cell.col, cell.row);
      } else {
        // power / signal — drop a cell-anchored marker. The parent
        // handler swaps "second click on same cell" for a remove, so
        // the producer can both place and clear without disarming.
        onAddPanelMarker(screenId, armed, cell.col, cell.row);
      }
    },
    [armed, eventToCell, onAddPanelMarker, onToggleCell, screenId],
  );

  /** Marker pointer-down: alt or right-button = delete, otherwise begin
   *  drag with pointer capture so the move keeps tracking even if the
   *  cursor leaves the SVG (matches iPad-friendly drag conventions). */
  const handleMarkerPointerDown = useCallback(
    (markerId: string) =>
      (e: React.PointerEvent<SVGGElement>) => {
        e.stopPropagation();
        if (e.altKey || e.button === 2) {
          e.preventDefault();
          onRemoveMarker(screenId, markerId);
          return;
        }
        setDraggingMarkerId(markerId);
        try {
          e.currentTarget.setPointerCapture(e.pointerId);
        } catch {
          // Some browsers throw on capture for non-primary pointers; the
          // drag still works via window-fallback movements, so swallow.
        }
      },
    [onRemoveMarker, screenId],
  );

  const handleMarkerPointerMove = useCallback(
    (markerId: string) =>
      (e: React.PointerEvent<SVGGElement>) => {
        if (draggingMarkerId !== markerId) return;
        const norm = eventToNorm(e);
        if (!norm) return;
        onMoveMarker(screenId, markerId, norm.x, norm.y);
      },
    [draggingMarkerId, eventToNorm, onMoveMarker, screenId],
  );

  const handleMarkerPointerUp = useCallback(
    () => setDraggingMarkerId(null),
    [],
  );

  /** Window-level fallback: if `setPointerCapture` was rejected (rare on
   *  some pointer types) or capture is silently lost, the per-marker
   *  pointermove won't fire once the cursor leaves the marker dot. We
   *  therefore mirror move/up at the window while a drag is active so
   *  the marker keeps tracking and always releases. */
  useEffect(() => {
    if (!draggingMarkerId) return;
    const onMove = (e: PointerEvent) => {
      const norm = eventToNorm(e);
      if (!norm) return;
      onMoveMarker(screenId, draggingMarkerId, norm.x, norm.y);
    };
    const onUp = () => setDraggingMarkerId(null);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
  }, [draggingMarkerId, eventToNorm, onMoveMarker, screenId]);

  const handleMarkerContextMenu = useCallback(
    (markerId: string) => (e: React.MouseEvent) => {
      // Right-click = delete, never the browser context menu.
      e.preventDefault();
      e.stopPropagation();
      onRemoveMarker(screenId, markerId);
    },
    [onRemoveMarker, screenId],
  );

  const cells: React.ReactNode[] = [];
  const minDim = Math.min(cellW, cellH);
  const labelFont = Math.max(7, Math.min(14, minDim * 0.32));
  const showLabelsHere = settings.showLabels && minDim >= 14;
  // Arrows need a bit of room — skip on tiny cells where they'd be a
  // smudge. Labels (top-left) and arrows (bottom-right or center) sit
  // in different parts of the cell, so they don't collide visually.
  const showArrowsHere = settings.showArrows && minDim >= 12;
  const arrowSize = Math.max(6, minDim * 0.32);
  const arrowStroke = Math.max(1.2, arrowSize * 0.16);

  // Build the disabled-cells lookup ONCE per render (cheap — Set of
  // ints) and reuse for the cell, label, arrow, and panel-marker
  // passes so they all agree on which cabinets are actually present.
  const offCells = disabledCellSet(screen);
  for (let row = 0; row < screen.panelsTall; row++) {
    for (let col = 0; col < screen.panelsWide; col++) {
      const cx = x + col * cellW;
      const cy = y + row * cellH;
      const isOff = isCellDisabled(offCells, col, row, screen.panelsWide);
      if (isOff) {
        // Render the void as a hatched / muted cell so the producer
        // (and the crew) can still see "no cabinet here" but won't
        // mistake it for a panel they need to rig. The fill is the
        // canvas backdrop; a dashed outline + diagonal hint marks it.
        cells.push(
          <g key={`${col}-${row}`}>
            <rect
              x={cx}
              y={cy}
              width={cellW}
              height={cellH}
              fill="#e5e7eb"
              fillOpacity={0.35}
              stroke="#94a3b8"
              strokeOpacity={0.7}
              strokeWidth={1}
              strokeDasharray="3 3"
            />
            <line
              x1={cx}
              y1={cy}
              x2={cx + cellW}
              y2={cy + cellH}
              stroke="#94a3b8"
              strokeOpacity={0.5}
              strokeWidth={1}
            />
          </g>,
        );
        continue;
      }
      const cellFill = panelCellColor(
        col,
        row,
        settings.panelPattern,
        screenColorDark,
        screenColorLight,
      );
      let arrowDir: CellArrowDir = null;
      if (showArrowsHere) {
        arrowDir = cellArrowDirection(
          col,
          row,
          screen.panelsWide,
          screen.panelsTall,
          settings.wirePath,
        );
        // Suppress arrows that would point INTO a disabled neighbour;
        // otherwise the data-flow visual reads as "wire into a void".
        if (arrowDir) {
          const nx =
            arrowDir === "right"
              ? col + 1
              : arrowDir === "left"
                ? col - 1
                : col;
          const ny =
            arrowDir === "down"
              ? row + 1
              : arrowDir === "up"
                ? row - 1
                : row;
          if (
            nx < 0 ||
            nx >= screen.panelsWide ||
            ny < 0 ||
            ny >= screen.panelsTall ||
            isCellDisabled(offCells, nx, ny, screen.panelsWide)
          ) {
            arrowDir = null;
          }
        }
      }
      cells.push(
        <g key={`${col}-${row}`}>
          <rect
            x={cx}
            y={cy}
            width={cellW}
            height={cellH}
            fill={cellFill}
            stroke="#0f172a"
            strokeOpacity={0.5}
            strokeWidth={1}
          />
          {showLabelsHere && (
            // Top-left corner so labels never overlap the centred
            // data-flow arrows. Mirrors the PNG export.
            <text
              x={cx + Math.max(2, cellW * 0.06)}
              y={cy + Math.max(2, cellH * 0.06) + labelFont * 0.85}
              fontSize={labelFont}
              fill="#0f172a"
              fontFamily="ui-monospace, SFMono-Regular, Menlo, monospace"
              fontWeight={600}
            >
              {colLabel(col)}
              {row + 1}
            </text>
          )}
          {arrowDir && (
            <CellArrow
              cx={cx + cellW / 2}
              cy={cy + cellH / 2}
              size={arrowSize}
              stroke={arrowStroke}
              dir={arrowDir}
            />
          )}
        </g>,
      );
    }
  }

  // Numbered output badges centered above each pair of columns — only
  // shown in column-serpentine mode (which is the typical way large
  // processors slice a wall: one output per 2 columns).
  const colPairBadges: React.ReactNode[] = [];
  if (settings.wirePath === "column-serpentine") {
    const pairs = Math.ceil(screen.panelsWide / 2);
    const startIndex = screen.outputIndex ?? 1;
    const badgeR = Math.max(10, Math.min(20, cellW * 0.35));
    for (let p = 0; p < pairs; p++) {
      const col0 = p * 2;
      const col1 = Math.min(col0 + 1, screen.panelsWide - 1);
      const cxBadge =
        x + ((col0 + col1 + 1) * cellW) / 2;
      const cyBadge = y - badgeR - 6;
      colPairBadges.push(
        <g key={`pair-${p}`}>
          <circle
            cx={cxBadge}
            cy={cyBadge}
            r={badgeR}
            fill="#ffffff"
            stroke="#0f172a"
            strokeWidth={2}
          />
          <text
            x={cxBadge}
            y={cyBadge}
            fontSize={Math.max(11, badgeR * 0.95)}
            fontWeight={700}
            fill="#0f172a"
            textAnchor="middle"
            dominantBaseline="central"
          >
            {startIndex + p}
          </text>
        </g>,
      );
    }
  }

  const m = computeScreenMetrics(screen, panels);
  const titleY = y - 36;
  const subY = y - 18;

  return (
    <g>
      {/* Per-column-pair output badges (column-serpentine wiring only) */}
      {colPairBadges}
      {/* Single per-screen output badge — hidden when the column-pair
          badges are taking over the strip above the screen. */}
      {screen.outputIndex != null &&
        settings.wirePath !== "column-serpentine" && (
          <g>
            <circle
              cx={x + width / 2}
              cy={y - 26}
              r={18}
              fill={screen.color}
              stroke="#0f172a"
              strokeWidth={2}
            />
            <text
              x={x + width / 2}
              y={y - 26}
              fontSize={16}
              fontWeight={700}
              fill="#fff"
              textAnchor="middle"
              dominantBaseline="central"
            >
              {screen.outputIndex}
            </text>
          </g>
        )}
      {/* Drag handle ⠿ — sits to the left of the title. Pointer-down
          on this group starts a screen drag (not a marker placement)
          and the cursor signals affordance.

          Hidden for linked screens: their position is derived from the
          rigging report (not stored on the LED tab), so dragging would
          have no effect and only confuse the user. The corresponding
          row in the table also stays inert for movement. */}
      {!screen.linked && (() => {
        const handleY = (screen.outputIndex != null ? titleY : y - 18) - 11;
        const handleX = x;
        return (
          <g
            transform={`translate(${handleX}, ${handleY})`}
            onPointerDown={onHandlePointerDown}
            style={{
              cursor: isDragging ? "grabbing" : "grab",
              touchAction: "none",
            }}
          >
            <rect
              x={-2}
              y={-2}
              width={18}
              height={18}
              rx={4}
              ry={4}
              fill="#ffffff"
              stroke="#0f172a"
              strokeOpacity={0.4}
              strokeWidth={1}
            />
            <text
              x={7}
              y={11}
              fontSize={14}
              fontWeight={700}
              fill="#0f172a"
              textAnchor="middle"
              dominantBaseline="central"
              fontFamily="system-ui, -apple-system, Segoe UI, Roboto, sans-serif"
              pointerEvents="none"
            >
              ⠿
            </text>
            <title>Drag to reposition this screen on the canvas</title>
          </g>
        );
      })()}
      {/* Screen title — clickable to select on the canvas */}
      <text
        x={x + 22}
        y={screen.outputIndex != null ? titleY : y - 18}
        fontSize={13}
        fontWeight={600}
        fill="currentColor"
        style={{ cursor: "pointer" }}
        onClick={(e) => {
          e.stopPropagation();
          onSelect();
        }}
      >
        {screen.name}
      </text>
      {screen.outputIndex != null && (
        <text
          x={x}
          y={subY}
          fontSize={11}
          fill="currentColor"
          opacity={0.7}
        >
          {screen.panelsWide}×{screen.panelsTall} · {m.pixelsX}×{m.pixelsY}px
        </text>
      )}
      {screen.outputIndex == null && (
        <text x={x} y={y - 4} fontSize={11} fill="currentColor" opacity={0.7}>
          {screen.panelsWide}×{screen.panelsTall} · {m.pixelsX}×{m.pixelsY}px
        </text>
      )}
      {/* Panel cells */}
      {cells}
      {/* Outline — also acts as the click-to-select target. We let the
          click bubble to the SVG only when we explicitly stop it from
          here on a real selection click; the empty-canvas SVG handler
          uses `e.target === e.currentTarget` to decide what to do. */}
      <rect
        x={x}
        y={y}
        width={width}
        height={height}
        // `transparent` (vs. `none`) keeps the outline visually empty
        // but makes the whole interior hit-testable, so the producer
        // can click anywhere on the screen — not just the 2px stroke —
        // to select it. The armed-mode marker overlay is drawn after
        // this rect, so it still wins clicks during marker placement.
        fill="transparent"
        stroke="#0f172a"
        strokeWidth={2}
        style={{ cursor: armed ? "crosshair" : "pointer" }}
        onClick={(e) => {
          // Marker-arm mode is handled by the dedicated overlay rect
          // above; this outline only triggers selection when no marker
          // placement is in flight.
          if (armed) return;
          e.stopPropagation();
          onSelect();
        }}
      />
      {/* Selection / drag halo — drawn last so it sits on top of cells
          and the outline. The pointerEvents=none keeps it from eating
          clicks meant for the outline / overlay underneath. */}
      {(isSelected || isDragging) && (
        <rect
          x={x - 4}
          y={y - 4}
          width={width + 8}
          height={height + 8}
          fill="none"
          stroke={isDragging ? "#f59e0b" : "#2563eb"}
          strokeWidth={3}
          strokeDasharray={isDragging ? "6 4" : undefined}
          pointerEvents="none"
        />
      )}
      {/* Click-target overlay for marker placement. Sits above cells but
          below the markers themselves so a click on an existing marker
          is captured by the marker (drag/delete) and a click anywhere
          else lands on this overlay. `pointerEvents` is toggled so the
          overlay is invisible to clicks unless the row is currently
          armed (+P or +S pressed) — keeps the visual passive by default. */}
      <rect
        ref={overlayRectRef}
        x={x}
        y={y}
        width={width}
        height={height}
        fill="transparent"
        pointerEvents={armed ? "all" : "none"}
        style={armed ? { cursor: "crosshair" } : undefined}
        onClick={handleOverlayClick}
      />
      {/* Centered "Main"/"IMAG" name pill — matches the PNG export so the
          user can preview what they'll get. Hidden if the user disabled
          the pill in Export options, or if there is no name. */}
      {settings.showScreenName && screen.name.trim().length > 0 && (() => {
        const name = screen.name;
        // Same shape as ledExport.ts: a built-in clamp times the
        // user-tunable per-screen scale. The clamp ceiling rises with
        // scale so 2× actually looks 2× bigger instead of capping at 36.
        const baseFont = Math.max(
          14,
          Math.min(36, Math.min(width, height) * 0.08),
        );
        const scale = clampNameScale(screen.nameScale);
        const pillFont = baseFont * scale;
        // Pill geometry uses the shared PILL_*_RATIO constants so the
        // live preview and the exported PNG always agree on the shape
        // (the base font is different by design — see led.ts).
        const padX = pillFont * PILL_PAD_X_RATIO;
        const padY = pillFont * PILL_PAD_Y_RATIO;
        const textW = name.length * pillFont * PILL_CHAR_W_RATIO;
        const pillW = textW + padX * 2;
        const pillH = pillFont + padY * 2;
        const cx = x + width / 2;
        const cy = y + height / 2;
        return (
          <g pointerEvents="none">
            <rect
              x={cx - pillW / 2}
              y={cy - pillH / 2}
              width={pillW}
              height={pillH}
              rx={pillH / 2}
              ry={pillH / 2}
              fill="#ffffff"
              stroke="#0f172a"
              strokeWidth={2}
              opacity={0.95}
            />
            <text
              x={cx}
              y={cy}
              fontSize={pillFont}
              fontWeight={700}
              fill="#0f172a"
              textAnchor="middle"
              dominantBaseline="central"
              fontFamily="system-ui, -apple-system, Segoe UI, Roboto, sans-serif"
            >
              {name}
            </text>
          </g>
        );
      })()}
      {/* Producer-drawn power / signal markers. Rendered last so they
          sit on top of the cells, outline, click overlay, and pill —
          matches the PNG export's z-order. */}
      {markers.length > 0 && (() => {
        const markerR = Math.max(8, Math.min(width, height) * 0.04);
        return markers.map((mk) => {
          const cx = x + Math.min(1, Math.max(0, mk.x)) * width;
          const cy = y + Math.min(1, Math.max(0, mk.y)) * height;
          const fill = mk.kind === "power" ? "#dc2626" : "#2563eb";
          const isDragging = draggingMarkerId === mk.id;
          const fontSize = markerR * 1.05;
          const label = `${mk.kind === "power" ? "P" : "S"}${mk.index}`;
          return (
            <g
              key={mk.id}
              onPointerDown={handleMarkerPointerDown(mk.id)}
              onPointerMove={handleMarkerPointerMove(mk.id)}
              onPointerUp={handleMarkerPointerUp}
              onPointerCancel={handleMarkerPointerUp}
              onContextMenu={handleMarkerContextMenu(mk.id)}
              style={{
                cursor: isDragging ? "grabbing" : "grab",
                touchAction: "none",
              }}
            >
              {/* Drop-shadow disc — keeps the marker visible on bright
                  cabinets and white test patterns. */}
              <circle
                cx={cx + markerR * 0.06}
                cy={cy + markerR * 0.06}
                r={markerR}
                fill="#000"
                fillOpacity={0.35}
                pointerEvents="none"
              />
              <circle
                cx={cx}
                cy={cy}
                r={markerR}
                fill={fill}
                stroke="#ffffff"
                strokeWidth={Math.max(1.5, markerR * 0.14)}
              />
              <text
                x={cx}
                y={cy}
                fontSize={fontSize}
                fontWeight={700}
                fill="#ffffff"
                textAnchor="middle"
                dominantBaseline="central"
                fontFamily="system-ui, -apple-system, Segoe UI, Roboto, sans-serif"
                pointerEvents="none"
              >
                {label}
              </text>
              {/* Hover/touch hint — reveals what the marker means and
                  how to remove it without cluttering the always-on
                  visual. */}
              <title>
                {mk.kind === "power" ? "Power" : "Signal"} drop {mk.index} —
                drag to move, alt-click or right-click to delete
              </title>
            </g>
          );
        });
      })()}
      {/* Cell-anchored panel markers (T004). Drawn as a rounded badge
          tucked into the top-left corner of the chosen cell so the
          producer can tell at a glance "this panel takes a power feed"
          or "data lands at this panel". Click to remove. */}
      {panelMarkers.length > 0 && (() => {
        const badgeSide = Math.max(10, Math.min(cellW, cellH) * 0.42);
        return panelMarkers.map((mk) => {
          if (
            mk.col < 0 ||
            mk.col >= screen.panelsWide ||
            mk.row < 0 ||
            mk.row >= screen.panelsTall
          ) {
            return null;
          }
          const cellX = x + mk.col * cellW;
          const cellY = y + mk.row * cellH;
          // Inset 6% from the top-left so the badge doesn't fight the
          // cell's stroke. Clamp the inset to a sane minimum for tiny
          // cells.
          const inset = Math.max(2, Math.min(cellW, cellH) * 0.06);
          const bx = cellX + inset;
          const by = cellY + inset;
          const fill = mk.kind === "power" ? "#dc2626" : "#2563eb";
          const fontSize = badgeSide * 0.55;
          const label = `${mk.kind === "power" ? "P" : "S"}${mk.index}`;
          return (
            <g
              key={mk.id}
              style={{ cursor: "pointer" }}
              onClick={(e) => {
                e.stopPropagation();
                onRemovePanelMarker(screenId, mk.id);
              }}
            >
              <rect
                x={bx + badgeSide * 0.06}
                y={by + badgeSide * 0.06}
                width={badgeSide}
                height={badgeSide}
                rx={badgeSide * 0.18}
                ry={badgeSide * 0.18}
                fill="#000"
                fillOpacity={0.35}
                pointerEvents="none"
              />
              <rect
                x={bx}
                y={by}
                width={badgeSide}
                height={badgeSide}
                rx={badgeSide * 0.18}
                ry={badgeSide * 0.18}
                fill={fill}
                stroke="#ffffff"
                strokeWidth={Math.max(1.5, badgeSide * 0.1)}
              />
              <text
                x={bx + badgeSide / 2}
                y={by + badgeSide / 2}
                fontSize={fontSize}
                fontWeight={700}
                fill="#ffffff"
                textAnchor="middle"
                dominantBaseline="central"
                fontFamily="system-ui, -apple-system, Segoe UI, Roboto, sans-serif"
                pointerEvents="none"
              >
                {label}
              </text>
              <title>
                {mk.kind === "power" ? "Power" : "Signal"} feed at panel
                {" "}r{mk.row + 1}c{mk.col + 1} — click to remove
              </title>
            </g>
          );
        });
      })()}
    </g>
  );
}

/** Small popover anchored to the row's "Shape…" button. Producer types
 *  the target physical width/height (m) and presses Apply to resize the
 *  panel grid by panel pitch, OR clicks a template chip (L/U/T/+/...)
 *  to fill the screen's `disabledCells` for that shape. The "Reset
 *  panel ON/OFF" checkbox controls whether the build-by-size action
 *  also wipes the current cell pattern (so producers don't accidentally
 *  blow away a hand-edited shape when they re-target the size). */
function ShapePopover({
  currentWidthM,
  currentHeightM,
  targetW,
  targetH,
  setTargetW,
  setTargetH,
  clearShapeOnApply,
  setClearShapeOnApply,
  onApplyBuildBySize,
  onApplyTemplate,
  onClose,
}: {
  currentWidthM: number;
  currentHeightM: number;
  targetW: string;
  targetH: string;
  setTargetW: (v: string) => void;
  setTargetH: (v: string) => void;
  clearShapeOnApply: boolean;
  setClearShapeOnApply: (v: boolean) => void;
  onApplyBuildBySize: () => void;
  onApplyTemplate: (template: LedShapeTemplate) => void;
  onClose: () => void;
}) {
  return (
    <div
      className="led-shape-popover"
      role="dialog"
      aria-label="Build by size & shape templates"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="led-shape-popover-head">
        <strong>Build by size</strong>
        <button
          type="button"
          className="btn btn-ghost btn-xs"
          onClick={onClose}
          title="Close"
        >
          ×
        </button>
      </div>
      <div className="led-shape-popover-body">
        <div className="led-shape-current">
          Current: {currentWidthM.toFixed(2)} × {currentHeightM.toFixed(2)} m
        </div>
        <div className="led-shape-build-grid">
          <label>
            Target W (m)
            <input
              className="led-input led-input-num"
              type="number"
              min={0.1}
              step={0.1}
              value={targetW}
              onChange={(e) => setTargetW(e.target.value)}
            />
          </label>
          <label>
            Target H (m)
            <input
              className="led-input led-input-num"
              type="number"
              min={0.1}
              step={0.1}
              value={targetH}
              onChange={(e) => setTargetH(e.target.value)}
            />
          </label>
        </div>
        <label className="led-shape-checkbox">
          <input
            type="checkbox"
            checked={clearShapeOnApply}
            onChange={(e) => setClearShapeOnApply(e.target.checked)}
          />
          Reset panel ON/OFF on apply
        </label>
        <div className="led-shape-actions">
          <button
            type="button"
            className="btn btn-primary btn-sm"
            onClick={() => {
              onApplyBuildBySize();
              onClose();
            }}
          >
            Apply size
          </button>
        </div>
      </div>
      <div className="led-shape-popover-divider" />
      <div className="led-shape-popover-body">
        <strong>Shape templates</strong>
        <div className="led-shape-chips">
          {LED_SHAPE_TEMPLATE_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              type="button"
              className="btn btn-ghost btn-xs led-shape-chip"
              title={opt.description}
              onClick={() => {
                onApplyTemplate(opt.value);
              }}
            >
              {opt.label}
            </button>
          ))}
        </div>
        <div className="led-shape-hint">
          Click a chip to fill the cabinet ON/OFF pattern. Use{" "}
          <em>Edit</em> on the row to toggle individual cabinets.
        </div>
      </div>
    </div>
  );
}

/** Per-screen processors strip. Renders an "Add processor" picker plus
 *  a chip per attached processor (with × to remove), and a small
 *  capacity readout — outputs / max pixels combined, vs the screen's
 *  required pixel count. Producer sees a red "Under capacity" pill if
 *  the screen exceeds the attached processors' combined cap. */
function ProcessorsStrip({
  processors,
  requiredPixels,
  cap,
  isUnder,
  onAdd,
  onRemove,
}: {
  processors: LedScreenProcessor[];
  requiredPixels: number;
  cap: ScreenProcessorCapacity;
  isUnder: boolean;
  onAdd: (model: NovastarProcessorModel) => void;
  onRemove: (processorId: string) => void;
}) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const hasAny = processors.length > 0;
  return (
    <div className="led-procs-strip">
      <div className="led-procs-strip-label">Processors:</div>
      <div className="led-procs-strip-chips">
        {processors.map((p) => {
          const spec = NOVASTAR_PROCESSOR_CATALOG[p.model];
          return (
            <span key={p.id} className="led-procs-chip" title={spec?.name}>
              <strong>{spec?.name ?? p.model}</strong>
              <button
                type="button"
                className="led-procs-chip-x"
                onClick={(e) => {
                  e.stopPropagation();
                  onRemove(p.id);
                }}
                aria-label={`Remove ${spec?.name ?? p.model}`}
                title="Remove"
              >
                ×
              </button>
            </span>
          );
        })}
        <div className="led-procs-add">
          <button
            type="button"
            className="btn btn-ghost btn-xs"
            onClick={(e) => {
              e.stopPropagation();
              setPickerOpen((v) => !v);
            }}
            title="Attach a Novastar processor to this screen"
          >
            + Add
          </button>
          {pickerOpen && (
            <div
              className="led-procs-picker"
              onClick={(e) => e.stopPropagation()}
            >
              {NOVASTAR_PROCESSOR_OPTIONS.map((opt) => (
                <button
                  key={opt.model}
                  type="button"
                  className="led-procs-picker-item"
                  onClick={() => {
                    onAdd(opt.model);
                    setPickerOpen(false);
                  }}
                  title={NOVASTAR_PROCESSOR_CATALOG[opt.model].name}
                >
                  {opt.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      {hasAny && (
        <div
          className={`led-procs-cap ${isUnder ? "is-under" : ""}`}
          title="Combined Ethernet outputs and pixel cap across attached processors vs this screen's pixel count"
        >
          {cap.outputs} outputs · {PIXEL_FMT.format(cap.maxPixels)} px cap
          {" vs "}
          {PIXEL_FMT.format(requiredPixels)} px needed
          {isUnder && (
            <span className="led-procs-under-pill">Under capacity</span>
          )}
        </div>
      )}
    </div>
  );
}

/** Cable & bracket bill-of-materials card. Lists per-screen the signal
 *  and TrueOne power jumper count + total length, plus the bracket name
 *  × cabinet count. A totals row at the bottom sums every screen so the
 *  producer can pull-list cables and brackets in one glance. */
function CableBracketBomCard({
  screens,
  panels,
}: {
  screens: LedScreen[];
  panels: LedPanel[];
}) {
  const rows = screens.map((s) => {
    const bom = computeScreenCableBOM(s, panels);
    return { screen: s, bom };
  });
  const totalSignalCables = rows.reduce(
    (sum, r) => sum + r.bom.signalCables,
    0,
  );
  const totalSignalLengthM = rows.reduce(
    (sum, r) => sum + r.bom.signalLengthM,
    0,
  );
  const totalPowerCables = rows.reduce(
    (sum, r) => sum + r.bom.powerCables,
    0,
  );
  const totalPowerLengthM = rows.reduce(
    (sum, r) => sum + r.bom.powerLengthM,
    0,
  );
  // Aggregate brackets by name across all screens so the producer sees
  // "ProBracket × 18" once instead of one entry per screen.
  const bracketTotals = new Map<string, number>();
  for (const r of rows) {
    for (const b of r.bom.brackets) {
      bracketTotals.set(b.name, (bracketTotals.get(b.name) ?? 0) + b.count);
    }
  }
  const totalBrackets = Array.from(bracketTotals.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => a.name.localeCompare(b.name));
  return (
    <section className="led-bom-card">
      <header className="led-bom-head">
        <h3>Cable &amp; bracket BOM</h3>
        <span className="led-bom-sub">
          Cabinet-to-cabinet jumpers only — signal {SIGNAL_CABLE_LENGTH_M.toFixed(2)} m,
          TrueOne power {POWER_TRUE1_CABLE_LENGTH_M.toFixed(2)} m
        </span>
      </header>
      <div className="led-bom-table-wrap">
        <table className="led-table led-bom-table">
          <thead>
            <tr>
              <th>Screen</th>
              <th className="led-num">Signal</th>
              <th className="led-num">Power (TrueOne)</th>
              <th>Brackets</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ screen, bom }) => (
              <tr key={screen.id}>
                <td>{screen.name || "(unnamed)"}</td>
                <td className="led-num">
                  {bom.signalCables} ×{" "}
                  <span className="led-sub">
                    {bom.signalLengthM.toFixed(2)} m
                  </span>
                </td>
                <td className="led-num">
                  {bom.powerCables} ×{" "}
                  <span className="led-sub">
                    {bom.powerLengthM.toFixed(2)} m
                  </span>
                </td>
                <td>
                  {bom.brackets.length === 0 ? (
                    <span className="led-sub">—</span>
                  ) : (
                    bom.brackets.map((b) => (
                      <span
                        key={b.name}
                        className={`led-bom-bracket ${
                          bom.bracketsUnset ? "is-unset" : ""
                        }`}
                      >
                        {b.name} × {b.count}
                      </span>
                    ))
                  )}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td>
                <strong>Totals</strong>
              </td>
              <td className="led-num">
                <strong>{totalSignalCables}</strong>{" "}
                <span className="led-sub">
                  ({totalSignalLengthM.toFixed(2)} m)
                </span>
              </td>
              <td className="led-num">
                <strong>{totalPowerCables}</strong>{" "}
                <span className="led-sub">
                  ({totalPowerLengthM.toFixed(2)} m)
                </span>
              </td>
              <td>
                {totalBrackets.length === 0 ? (
                  <span className="led-sub">—</span>
                ) : (
                  totalBrackets.map((b) => (
                    <span key={b.name} className="led-bom-bracket">
                      <strong>{b.name}</strong> × {b.count}
                    </span>
                  ))
                )}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </section>
  );
}

/** Single arrow centered at (cx, cy), drawn as a stroke + filled arrowhead.
 *  Direction-agnostic so the same component handles up / down / left /
 *  right for the per-cell data-flow indicators. */
function CellArrow({
  cx,
  cy,
  size,
  stroke,
  dir,
}: {
  cx: number;
  cy: number;
  size: number;
  stroke: number;
  dir: Exclude<CellArrowDir, null>;
}) {
  // Compute the line endpoints and the polygon for the arrowhead.
  const half = size / 2;
  const head = size * 0.55;
  let x1 = cx;
  let y1 = cy;
  let x2 = cx;
  let y2 = cy;
  let p1x = 0;
  let p1y = 0;
  let p2x = 0;
  let p2y = 0;
  if (dir === "right") {
    x1 = cx - half;
    x2 = cx + half;
    y1 = y2 = cy;
    p1x = x2 - head;
    p1y = cy - head * 0.6;
    p2x = x2 - head;
    p2y = cy + head * 0.6;
  } else if (dir === "left") {
    x1 = cx + half;
    x2 = cx - half;
    y1 = y2 = cy;
    p1x = x2 + head;
    p1y = cy - head * 0.6;
    p2x = x2 + head;
    p2y = cy + head * 0.6;
  } else if (dir === "down") {
    y1 = cy - half;
    y2 = cy + half;
    x1 = x2 = cx;
    p1x = cx - head * 0.6;
    p1y = y2 - head;
    p2x = cx + head * 0.6;
    p2y = y2 - head;
  } else {
    // up
    y1 = cy + half;
    y2 = cy - half;
    x1 = x2 = cx;
    p1x = cx - head * 0.6;
    p1y = y2 + head;
    p2x = cx + head * 0.6;
    p2y = y2 + head;
  }
  return (
    <g pointerEvents="none">
      <line
        x1={x1}
        y1={y1}
        x2={x2}
        y2={y2}
        stroke="#0a0a0a"
        strokeOpacity={0.9}
        strokeWidth={stroke}
        strokeLinecap="round"
      />
      <polygon
        points={`${x2},${y2} ${p1x},${p1y} ${p2x},${p2y}`}
        fill="#0a0a0a"
        fillOpacity={0.9}
      />
    </g>
  );
}

function ExportOptions({
  settings,
  onUpdateSettings,
}: {
  settings: LedSettings;
  onUpdateSettings: (patch: Partial<LedSettings>) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <section className={`led-card led-export-card ${open ? "is-open" : ""}`}>
      <button
        type="button"
        className="led-export-header"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <span className="led-export-header-main">
          <span className="led-export-header-icon" aria-hidden="true">
            ⚙
          </span>
          <span className="led-export-header-text">
            <span className="led-export-header-title">
              Export options (PNG)
            </span>
            <span className="led-export-header-sub">
              Controls what the per-screen <strong>PNG</strong> button renders.
              The on-screen pixel map uses these too where applicable.
            </span>
          </span>
        </span>
        <span className="led-export-header-chevron" aria-hidden="true">
          {open ? "▾" : "▸"}
        </span>
      </button>

      {open && (
        <div className="led-export-body">
          {/* ── Group 1: Output & wiring ───────────────────────────── */}
          <div className="led-export-group">
            <div className="led-export-group-head">
              <span className="led-export-group-title">Output &amp; wiring</span>
              <span className="led-export-group-hint">
                How the wall is sliced across processor outputs.
              </span>
            </div>
            <div className="led-export-fields">
              <label className="led-field">
                <span className="led-field-label">Output mode</span>
                <select
                  className="led-input"
                  value={settings.outputMode}
                  onChange={(e) =>
                    onUpdateSettings({
                      outputMode: e.target.value as LedSettings["outputMode"],
                    })
                  }
                >
                  <option value="per-screen">One per screen</option>
                  <option value="per-row">One per panel row</option>
                </select>
              </label>

              <label className="led-field">
                <span className="led-field-label">Pixels per output</span>
                <NumberField
                  className="led-input"
                  min={1000}
                  step={1000}
                  disabled={settings.outputMode !== "per-screen"}
                  value={settings.portLimit}
                  transform={(n) => Math.max(1000, n || 1000)}
                  emptyValue={1000}
                  onCommit={(portLimit) =>
                    onUpdateSettings({ portLimit })
                  }
                />
              </label>

              <label className="led-field">
                <span className="led-field-label">Wire path</span>
                <select
                  className="led-input"
                  value={settings.wirePath}
                  onChange={(e) =>
                    onUpdateSettings({
                      wirePath: e.target.value as LedSettings["wirePath"],
                    })
                  }
                >
                  <option value="linear">Linear (rows L→R)</option>
                  <option value="serpentine">
                    Serpentine (alternates rows)
                  </option>
                  <option value="column-serpentine">
                    Snake by column (down/up)
                  </option>
                </select>
              </label>

              <label className="led-field">
                <span className="led-field-label">Processor</span>
                <select
                  className="led-input"
                  value={settings.processorId ?? ""}
                  onChange={(e) =>
                    onUpdateSettings({
                      processorId:
                        e.target.value === "" ? null : e.target.value,
                    })
                  }
                >
                  <option value="">— None / generic —</option>
                  {LED_PROCESSORS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </label>
            </div>
          </div>

          {/* ── Group 2: Visual overlays ───────────────────────────── */}
          <div className="led-export-group">
            <div className="led-export-group-head">
              <span className="led-export-group-title">Visual overlays</span>
              <span className="led-export-group-hint">
                Toggle the helper graphics drawn on top of every cabinet.
              </span>
            </div>
            <div className="led-export-toggles">
              {(
                [
                  ["showLabels", "Panel labels (A1, B1…)"],
                  ["showArrows", "Data-flow arrows"],
                  ["showTestPattern", "Alignment circle + corner X"],
                  ["showScreenName", "Screen name pill"],
                  ["showInfoBar", "Bottom info bar"],
                  ["showLogo", "EHS logo"],
                ] as const
              ).map(([key, label]) => {
                const checked = Boolean(settings[key]);
                return (
                  <label
                    key={key}
                    className={`led-toggle-card ${checked ? "is-on" : ""}`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(e) =>
                        onUpdateSettings({
                          [key]: e.target.checked,
                        } as Partial<LedSettings>)
                      }
                    />
                    <span className="led-toggle-card-text">{label}</span>
                    <span
                      className="led-toggle-card-pill"
                      aria-hidden="true"
                    >
                      {checked ? "On" : "Off"}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* ── Group 3: Look &amp; feel ───────────────────────────── */}
          <div className="led-export-group">
            <div className="led-export-group-head">
              <span className="led-export-group-title">Look &amp; feel</span>
              <span className="led-export-group-hint">
                Cabinet pattern and the alternating tint used on the map.
              </span>
            </div>

            <div className="led-export-look">
              <label className="led-field">
                <span className="led-field-label">Panel pattern</span>
                <select
                  className="led-input"
                  value={settings.panelPattern}
                  onChange={(e) =>
                    onUpdateSettings({
                      panelPattern: e.target.value as LedPanelPattern,
                    })
                  }
                >
                  <option value="checker">
                    Checkerboard (every panel visible)
                  </option>
                  <option value="columns">Vertical stripes (columns)</option>
                </select>
              </label>

              <div className="led-field">
                <span className="led-field-label">Panel colors</span>
                <div className="led-color-pair-row">
                  <label className="led-color-input">
                    <input
                      type="color"
                      value={settings.panelColorDark}
                      onChange={(e) =>
                        onUpdateSettings({ panelColorDark: e.target.value })
                      }
                      aria-label="Dark panel color"
                    />
                    <span>Dark</span>
                  </label>
                  <label className="led-color-input">
                    <input
                      type="color"
                      value={settings.panelColorLight}
                      onChange={(e) =>
                        onUpdateSettings({ panelColorLight: e.target.value })
                      }
                      aria-label="Light panel color"
                    />
                    <span>Light</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="led-export-presets">
              <span className="led-export-presets-label">Presets</span>
              <div className="led-color-presets">
                {LED_PANEL_COLOR_PRESETS.map((p) => {
                  const isActive =
                    settings.panelColorDark.toLowerCase() ===
                      p.dark.toLowerCase() &&
                    settings.panelColorLight.toLowerCase() ===
                      p.light.toLowerCase();
                  return (
                    <button
                      key={p.label}
                      type="button"
                      className={`led-color-preset ${isActive ? "is-active" : ""}`}
                      title={`Use ${p.label} preset`}
                      onClick={() =>
                        onUpdateSettings({
                          panelColorDark: p.dark,
                          panelColorLight: p.light,
                        })
                      }
                    >
                      <span
                        className="led-color-preset-half"
                        style={{ background: p.dark }}
                      />
                      <span
                        className="led-color-preset-half"
                        style={{ background: p.light }}
                      />
                      <span className="led-color-preset-label">{p.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
