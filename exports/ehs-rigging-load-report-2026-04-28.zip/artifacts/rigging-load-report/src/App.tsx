import { useEffect, useMemo, useRef, useState } from "react";
import { useClerk, useUser } from "@clerk/react";
import { Link } from "wouter";
import "./index.css";
import ehsLogo from "./assets/ehs-logo.png";
import {
  CUSTOM_LED_PANEL,
  CUSTOM_PANEL_KEY,
  DEFAULT_LED_SETTINGS,
  LED_SCREEN_COLORS,
  buildLedPanels,
  computeLedTotals,
  defaultLinkedLedMeta,
  defaultPanelKeyOf,
  findPanelKeyForInventoryName,
  getLedPanel,
  resolveScreenPanel,
  migrateLedPanelKey,
  newLedScreen,
  normalizeLedSettings,
  type LedCustomPanel,
  type LedLinkedMeta,
  type LedScreen,
  type LedSettings,
} from "./lib/led";
import { findProcessor } from "./lib/ledProcessors";
import { NumberField } from "./components/NumberField";
import { ShareBriefModal } from "./components/ShareBriefModal";
import type { BuildBriefInput } from "./lib/projectBrief";
import { exportScreenAsPng, getLogoDataUrl } from "./lib/ledExport";
import { LedScreenReportView } from "./components/LedScreenReportView";
import {
  computeStage,
  type Stage,
  makeDefaultStage,
  normalizeStage,
} from "./lib/stage";
import { exportStageReport } from "./lib/stageExport";
import { StageReportView } from "./components/StageReportView";
import {
  makeCrewMember,
  normalizeCrewMember,
  type CrewMember,
} from "./lib/crew";
import { CrewReportView } from "./components/CrewReportView";
import {
  makeSoundItem,
  normalizeSoundItem,
  type SoundItem,
} from "./lib/sound";
import { SoundReportView } from "./components/SoundReportView";
import { EquipmentPicker } from "./components/EquipmentPicker";
import type { LibraryItem } from "./lib/equipmentLibrary";
import {
  emptyFloorPlanLibrary,
  loadFloorPlanLibrary,
  saveFloorPlanLibrary,
  type FloorPlan,
  type FloorPlanLibrary,
} from "./lib/floorPlan";
import {
  defaultPowerPlan,
  makePowerCircuit,
  makePowerItem,
  normalizePowerPlan,
  type PowerCircuit,
  type PowerItem,
  type PowerPhase,
  type PowerPlan,
} from "./lib/power";
import { PowerPlanView } from "./components/PowerPlanView";
import {
  clampTrussToVenue,
  DEFAULT_RIGG_PLAN,
  makeDefaultVenue,
  normalizeRiggPlan,
  type RiggPlan,
  type RiggPlanTruss,
  type RiggPlanVenue,
} from "./lib/riggPlan";
import {
  RiggPlanView,
  type RiggPlanSystemInfo,
} from "./components/RiggPlanView";
import { emptyApplySummary } from "./lib/drawingAnalysis";
import type {
  ApplySelection,
  ApplySummary,
  ExtractedItems,
} from "./lib/drawingAnalysis";

type DmxMode = {
  name: string;
  channels: number;
};

type InventoryItem = {
  name: string;
  weight: number;
  wattage: number;
  area: number;
  /** Optional list of factory DMX modes for this fixture. Sourced from
   *  manufacturer documentation. The first entry is treated as the default
   *  when the fixture is first linked into the Lighting Plan. */
  dmxModes?: DmxMode[];
  /** LED panel pixel/physical dimensions. When all four are set, this
   *  inventory item appears as a panel option on the LED Screen Report. */
  pixelWidth?: number;
  pixelHeight?: number;
  physicalWidth?: number;
  physicalHeight?: number;
};

type Category = "Truss" | "Fixtures" | "LED Screen";

const inventory: Record<Category, InventoryItem[]> = {
  Truss: [
    { name: "Eurotruss FD34 - 3.0m (18.1kg)", weight: 18.1, wattage: 0, area: 0 },
    { name: "Eurotruss FD34 - 2.0m (12.5kg)", weight: 12.5, wattage: 0, area: 0 },
    { name: "Eurotruss FD34 - 1.0m (6.9kg)", weight: 6.9, wattage: 0, area: 0 },
    { name: "Eurotruss FD34 - 0.5m (4.5kg)", weight: 4.5, wattage: 0, area: 0 },
    { name: "Eurotruss FD34 - 0.25m (3.2kg)", weight: 3.2, wattage: 0, area: 0 },
    { name: "Eurotruss HD34 - 3.0m (21.4kg)", weight: 21.4, wattage: 0, area: 0 },
    { name: "Eurotruss HD34 - 2.0m (14.7kg)", weight: 14.7, wattage: 0, area: 0 },
    { name: "Eurotruss HD34 - 1.0m (8.1kg)", weight: 8.1, wattage: 0, area: 0 },
    { name: "Eurotruss HD34 - 0.5m (5.1kg)", weight: 5.1, wattage: 0, area: 0 },
    { name: "Eurotruss HD34 - 0.25m (3.8kg)", weight: 3.8, wattage: 0, area: 0 },
    { name: "Eurotruss FD32 - 4.0m (15.5kg)", weight: 15.5, wattage: 0, area: 0 },
    { name: "Eurotruss FD32 - 3.0m (11.8kg)", weight: 11.8, wattage: 0, area: 0 },
    { name: "Eurotruss FD32 - 2.0m (8.3kg)", weight: 8.3, wattage: 0, area: 0 },
    { name: "Eurotruss FD32 - 1.0m (4.7kg)", weight: 4.7, wattage: 0, area: 0 },
    { name: "Eurotruss FD32 - 0.5m (3.1kg)", weight: 3.1, wattage: 0, area: 0 },
  ],
  Fixtures: [
    {
      name: "Clay Paky Mythos 2 (32.0kg)",
      weight: 32.0,
      wattage: 800,
      area: 0,
      dmxModes: [
        { name: "Standard", channels: 30 },
        { name: "Vector / Extended", channels: 34 },
      ],
    },
    {
      name: "Elation DTW Blinder 350 IP (11.0kg)",
      weight: 11.0,
      wattage: 310,
      area: 0,
      dmxModes: [
        { name: "1 Channel", channels: 1 },
        { name: "2 Channel", channels: 2 },
        { name: "4 Channel", channels: 4 },
        { name: "Full / 9 Channel", channels: 9 },
      ],
    },
    { name: "Martin PowerPort 1500", weight: 0, wattage: 1100, area: 0 },
    {
      name: "MDG ATMe Haze",
      weight: 0,
      wattage: 715,
      area: 0,
      dmxModes: [{ name: "Standard", channels: 3 }],
    },
    {
      name: "Stage Fan / AF-1",
      weight: 0,
      wattage: 120,
      area: 0,
      dmxModes: [{ name: "Speed", channels: 1 }],
    },
    {
      name: "Astera Titan Tube (1.35kg)",
      weight: 1.35,
      wattage: 72,
      area: 0,
      dmxModes: [
        { name: "Single 5ch", channels: 5 },
        { name: "Single 8ch", channels: 8 },
        { name: "Single 11ch", channels: 11 },
        { name: "Pixel 16 (28ch)", channels: 28 },
      ],
    },
    {
      name: "Astera AX2 1m PixelBar (7.4kg)",
      weight: 7.4,
      wattage: 80,
      area: 0,
      dmxModes: [
        { name: "Single 5ch", channels: 5 },
        { name: "Single 8ch", channels: 8 },
        { name: "Single 11ch", channels: 11 },
        { name: "Pixel 16 (28ch)", channels: 28 },
      ],
    },
    {
      name: "Astera AX5 TriplePAR (3.4kg)",
      weight: 3.4,
      wattage: 45,
      area: 0,
      dmxModes: [
        { name: "Single 5ch", channels: 5 },
        { name: "Single 8ch", channels: 8 },
        { name: "Single 11ch", channels: 11 },
        { name: "Pixel 3 (15ch)", channels: 15 },
      ],
    },
    {
      name: "Astera AX9 PowerPar (5.66kg)",
      weight: 5.66,
      wattage: 110,
      area: 0,
      dmxModes: [
        { name: "Single 5ch", channels: 5 },
        { name: "Single 8ch", channels: 8 },
        { name: "Single 11ch", channels: 11 },
      ],
    },
    {
      name: "Astera Pixel Brick (1.12kg)",
      weight: 1.12,
      wattage: 20,
      area: 0,
      dmxModes: [
        { name: "Single 5ch", channels: 5 },
        { name: "Single 8ch", channels: 8 },
        { name: "Single 11ch", channels: 11 },
      ],
    },
    {
      name: "Martin MAC Aura (6.6kg)",
      weight: 6.6,
      wattage: 260,
      area: 0,
      dmxModes: [
        { name: "Standard", channels: 14 },
        { name: "Extended", channels: 25 },
      ],
    },
    {
      name: "Martin MAC Aura XB (7.5kg)",
      weight: 7.5,
      wattage: 260,
      area: 0,
      dmxModes: [
        { name: "Standard", channels: 14 },
        { name: "Extended", channels: 25 },
      ],
    },
    {
      name: "Martin MAC Aura XIP (10.0kg)",
      weight: 10.0,
      wattage: 340,
      area: 0,
      dmxModes: [
        { name: "Compact", channels: 20 },
        { name: "Basic", channels: 36 },
        { name: "Extended", channels: 57 },
        { name: "Ludicrous", channels: 93 },
        { name: "XB Standard", channels: 14 },
        { name: "XB Extended", channels: 25 },
      ],
    },
    {
      name: "Martin MAC Aura PXL (15.6kg)",
      weight: 15.6,
      wattage: 560,
      area: 0,
      dmxModes: [
        { name: "Compact", channels: 17 },
        { name: "Basic", channels: 32 },
        { name: "Extended", channels: 89 },
        { name: "Ludicrous", channels: 512 },
      ],
    },
    {
      name: "Martin MAC One (5.4kg)",
      weight: 5.4,
      wattage: 160,
      area: 0,
      dmxModes: [
        { name: "Compact", channels: 20 },
        { name: "Basic", channels: 36 },
        { name: "Ludicrous", channels: 108 },
        { name: "Compact Direct", channels: 20 },
      ],
    },
    {
      name: "Martin MAC Viper XIP (37.8kg)",
      weight: 37.8,
      wattage: 1040,
      area: 0,
      dmxModes: [
        { name: "Basic", channels: 54 },
        { name: "Extended", channels: 64 },
        { name: "Ludicrous", channels: 70 },
      ],
    },
    {
      name: "Martin MAC Viper AirFX (36.7kg)",
      weight: 36.7,
      wattage: 1225,
      area: 0,
      dmxModes: [
        { name: "Basic", channels: 20 },
        { name: "Extended", channels: 28 },
      ],
    },
    {
      name: "SnowARC Pro Quad 40 mkII (10.5kg)",
      weight: 10.5,
      wattage: 390,
      area: 0,
      dmxModes: [
        { name: "Snow only (1ch)", channels: 1 },
        { name: "Snow + RGBW (6ch)", channels: 6 },
      ],
    },
    {
      name: "DTS NICK NRG 1201 (12.9kg)",
      weight: 12.9,
      wattage: 340,
      area: 0,
      dmxModes: [{ name: "Standard", channels: 20 }],
    },
    {
      name: "Elation Pulse Panel FX (14.4kg)",
      weight: 14.4,
      wattage: 900,
      area: 0,
      dmxModes: [
        { name: "8 Channel", channels: 8 },
        { name: "16 Channel", channels: 16 },
        { name: "29 Channel", channels: 29 },
        { name: "52 Channel", channels: 52 },
        { name: "62 Channel", channels: 62 },
        { name: "65 Channel", channels: 65 },
      ],
    },
    {
      name: "Chauvet Color STRIKE M (13.1kg)",
      weight: 13.1,
      wattage: 740,
      area: 0,
      dmxModes: [
        { name: "8 Channel", channels: 8 },
        { name: "11 Channel", channels: 11 },
        { name: "13 Channel", channels: 13 },
        { name: "24 Channel", channels: 24 },
        { name: "30 Channel", channels: 30 },
        { name: "47 Channel", channels: 47 },
        { name: "74 Channel", channels: 74 },
        { name: "97 Channel", channels: 97 },
      ],
    },
    {
      name: "Martin RUSH MH 7 Hybrid (25.0kg)",
      weight: 25.0,
      wattage: 450,
      area: 0,
      dmxModes: [{ name: "Standard", channels: 21 }],
    },
  ],
  "LED Screen": [
    {
      // Uniview UR Pro 3.9 — 500 × 1000 mm cabinet, mounted in PORTRAIT
      // (0.5 m wide × 1.0 m tall). Manufacturer cabinet weight 10.8 kg,
      // max draw 350 W per cabinet.
      name: "Uniview UR Pro 0.5x1m (10.8kg)",
      weight: 10.8,
      wattage: 350,
      area: 0.5,
      pixelWidth: 128,
      pixelHeight: 256,
      physicalWidth: 0.5,
      physicalHeight: 1.0,
    },
    {
      // Uniview UR Pro 3.9 — square 500 × 500 mm cabinet, 7.2 kg, 175 W max.
      name: "Uniview UR Pro 0.5x0.5m (7.2kg)",
      weight: 7.2,
      wattage: 175,
      area: 0.25,
      pixelWidth: 128,
      pixelHeight: 128,
      physicalWidth: 0.5,
      physicalHeight: 0.5,
    },
    { name: "Molton 6x4m (7.2kg)", weight: 7.2, wattage: 0, area: 0 },
    { name: "Molton 9x6m (16.2kg)", weight: 16.2, wattage: 0, area: 0 },
    { name: "Molton 9x9m (24.3kg)", weight: 24.3, wattage: 0, area: 0 },
  ],
};

const distributionFactors: Record<number, number[]> = {
  2: [0.5, 0.5],
  3: [0.19, 0.62, 0.19],
  4: [0.13, 0.37, 0.37, 0.13],
  5: [0.1, 0.28, 0.24, 0.28, 0.1],
  6: [0.08, 0.23, 0.19, 0.19, 0.23, 0.08],
  7: [0.07, 0.19, 0.15, 0.18, 0.15, 0.19, 0.07],
  8: [0.06, 0.16, 0.14, 0.14, 0.14, 0.14, 0.16, 0.06],
};

type Hoist = {
  label: string;
  weight: number;
  watt: number;
  swl: number;
};

const hoistModels: Hoist[] = [
  { label: "EXE Rise D8+ 500kg (38.5kg | 0.8kW)", weight: 38.5, watt: 800, swl: 500 },
  { label: "EXE Rise D8+ 1000kg (69.6kg | 1.1kW)", weight: 69.6, watt: 1100, swl: 1000 },
];

/** Sentinel returned by `getHoist` when a system has no motor selected
 *  (`hoistIndex < 0`). All-zero weights/wattage/SWL means the motor
 *  contribution drops out of every calculation cleanly. UI code must
 *  treat `swl === 0` as "no SWL constraint" and skip overload checks
 *  rather than reporting a divide-by-zero or false-positive overload. */
const NO_HOIST: Hoist = { label: "None", weight: 0, watt: 0, swl: 0 };

/** Resolve a system's `hoistIndex` to a concrete `Hoist`. Returns the
 *  `NO_HOIST` sentinel when the user picked "None" in the Motor Type
 *  dropdown (`idx < 0`); otherwise returns the indexed model, falling
 *  back to the first hoist if the index is out of range so legacy /
 *  corrupt persisted data still renders something usable. */
function getHoist(idx: number): Hoist {
  if (idx < 0) return NO_HOIST;
  return hoistModels[idx] ?? hoistModels[0];
}

type Row = {
  id: string;
  category: Category | "Custom";
  selectedIndex: number;
  qty: number;
  custom?: InventoryItem;
};

type System = {
  id: string;
  name: string;
  pointCount: number;
  dynamicFactor: number;
  hoistIndex: number;
  riggingRows: Row[];
  fixtureRows: Row[];
  ledRows: Row[];
};

let idCounter = 0;
const newId = (prefix = "id") =>
  `${prefix}-${++idCounter}-${Math.random().toString(36).slice(2, 8)}`;

function makeRow(category: Category, qty = 1): Row {
  return { id: newId("row"), category, selectedIndex: 0, qty };
}

function makeCustomRow(targetCategory: Category, item: InventoryItem): Row {
  return {
    id: newId("row"),
    category: targetCategory,
    selectedIndex: -1,
    qty: 1,
    custom: item,
  };
}

function makeSystem(name: string): System {
  return {
    id: newId("sys"),
    name,
    pointCount: 3,
    dynamicFactor: 1.25,
    hoistIndex: 0,
    riggingRows: [makeRow("Truss", 4)],
    fixtureRows: [],
    ledRows: [],
  };
}

/** Create a system with no rows and no motor selected — used by the
 *  top-level Reset button so the user lands on a truly empty Rigging
 *  Report and isn't surprised to see a default truss row or a motor
 *  pre-picked. */
function makeEmptySystem(name: string): System {
  return {
    id: newId("sys"),
    name,
    pointCount: 3,
    dynamicFactor: 1.25,
    hoistIndex: -1,
    riggingRows: [],
    fixtureRows: [],
    ledRows: [],
  };
}

function getRowItem(row: Row): InventoryItem | undefined {
  if (row.custom) return row.custom;
  if (row.category === "Custom") return undefined;
  return inventory[row.category as Category][row.selectedIndex];
}

/** Strip "(weight)" parens, lowercase, and collapse non-alphanumerics
 *  to single spaces. Used so the analyser's "Clay Paky Mythos 2" can
 *  match the inventory's "Clay Paky Mythos 2 (32.0kg)". */
function normalizeFixtureName(s: string): string {
  return s
    .toLowerCase()
    .replace(/\([^)]*\)/g, " ")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

/** Look up an analyser-extracted fixture name in `inventory.Fixtures`.
 *  Returns the matching index (≥ 0) or `-1` if no confident match.
 *
 *  Strategy: normalize both names, then prefer a direct substring
 *  match (either side) before falling back to a token-overlap score
 *  that requires ≥ 2 shared tokens AND ≥ 60 % of the inventory item's
 *  tokens to be present. The thresholds are intentionally conservative
 *  to avoid linking the wrong model on the Rigging Report — when in
 *  doubt we leave it as a Custom row carrying the analyser's data. */
function matchInventoryFixture(name: string): number {
  const target = normalizeFixtureName(name);
  if (!target) return -1;
  const targetTokens = target.split(/\s+/).filter((t) => t.length >= 2);
  if (targetTokens.length === 0) return -1;

  let bestIdx = -1;
  let bestScore = 0;
  inventory.Fixtures.forEach((item, idx) => {
    const itemNorm = normalizeFixtureName(item.name);
    if (!itemNorm) return;
    const itemTokens = itemNorm.split(/\s+/).filter((t) => t.length >= 2);
    if (itemTokens.length === 0) return;

    // Direct substring either way → strong match, BUT only when the
    // shorter side is specific enough to be unambiguous. We require
    // the analyser-extracted name to carry at least 2 meaningful
    // tokens AND the shorter side to be ≥ 6 characters; this stops
    // a single-token OCR fragment like "mac" from binding to the
    // first inventory item that happens to contain it.
    if (itemNorm.includes(target) || target.includes(itemNorm)) {
      const minLen = Math.min(itemNorm.length, target.length);
      if (targetTokens.length >= 2 && minLen >= 6) {
        const score = 100 + minLen;
        if (score > bestScore) {
          bestScore = score;
          bestIdx = idx;
        }
      }
      return;
    }

    // Token overlap — must share at least 2 tokens AND cover the
    // majority of the inventory item to count.
    const overlap = targetTokens.filter((t) =>
      itemTokens.includes(t),
    ).length;
    if (overlap >= 2 && overlap >= itemTokens.length * 0.6) {
      const score = overlap * 10;
      if (score > bestScore) {
        bestScore = score;
        bestIdx = idx;
      }
    }
  });

  return bestIdx;
}

const STORAGE_KEY_V2 = "ehs-rigging-report-v2";
const STORAGE_KEY_V1 = "ehs-rigging-report-v1";

type MainView =
  | "rigging"
  | "lighting"
  | "led"
  | "stage"
  | "crew"
  | "sound"
  | "riggPlan";

type ShowFixture = {
  id: string;
  name: string;
  qty: number;
  weight: number;
  watts: number;
  dmxChannels: number;
  beamAngle: number;
  systemId: string;
  position: number;
  circuit: string;
  universe: number;
  startAddress: number;
  notes: string;
  /** When true, base info (name/qty/weight/watts/systemId) comes from a
   *  rigging fixtureRow and is read-only on the lighting plan. */
  linked?: boolean;
  /** For linked rows, the source rigging Row id used for meta lookup. */
  sourceRowId?: string;
  /** Selected DMX mode index from the inventory item's dmxModes list, or
   *  null when the user has chosen "Custom..." and is entering channels
   *  manually. Only set on linked rows whose inventory item provides modes. */
  dmxModeIndex?: number | null;
  /** Available DMX modes for the underlying inventory item (linked rows). */
  availableDmxModes?: DmxMode[];
};

/** Lighting-plan-only fields layered on top of a rigging fixture row. */
type LinkedMeta = {
  dmxChannels: number;
  /** Selected mode index, or null if user picked "Custom..." (use stored
   *  dmxChannels). Index 0 is the default for items that have dmxModes. */
  dmxModeIndex?: number | null;
  beamAngle: number;
  position: number;
  circuit: string;
  universe: number;
  startAddress: number;
  notes: string;
};

function defaultLinkedMeta(): LinkedMeta {
  return {
    dmxChannels: 0,
    dmxModeIndex: 0,
    beamAngle: 0,
    position: 0,
    circuit: "",
    universe: 1,
    startAddress: 1,
    notes: "",
  };
}

function makeShowFixture(): ShowFixture {
  return {
    id: newId("fx"),
    name: "",
    qty: 1,
    weight: 0,
    watts: 0,
    dmxChannels: 0,
    beamAngle: 0,
    systemId: "",
    position: 0,
    circuit: "",
    universe: 1,
    startAddress: 1,
    notes: "",
  };
}

/** Phases of a production run. The "show" phase is implicitly stored in
 *  `reportDate`/`reportEndDate` for backwards compatibility — the other
 *  three live in `extraSchedule`. */
export type SchedulePhaseKey = "setup" | "rehearsal" | "show" | "downrig";

/** A single phase's date range plus optional time-of-day range.
 *  Empty strings mean "not set". `fromTime` / `toTime` are HH:MM
 *  24h strings (matching the value of <input type="time">). */
export type SchedulePhase = {
  from: string;
  to: string;
  fromTime?: string;
  toTime?: string;
};

/** All schedule phases keyed by name. The "show" entry only stores
 *  optional time-of-day fields here — its calendar dates live in the
 *  separate `reportDate` / `reportEndDate` state for backwards compat
 *  with the V2 persistence schema. */
export type ExtraSchedule = Partial<Record<SchedulePhaseKey, SchedulePhase>>;

/** A combined schedule including the show phase, derived for downstream
 *  consumers (brief, exports, etc.). */
export type ProjectSchedule = Partial<Record<SchedulePhaseKey, SchedulePhase>>;

export const SCHEDULE_PHASE_LABELS: Record<SchedulePhaseKey, string> = {
  setup: "Setup",
  rehearsal: "Rehearsal",
  show: "Show",
  // Internal key stays "downrig" for backwards compatibility with
  // already-persisted localStorage data; the user-facing label is
  // "Load Out".
  downrig: "Load Out",
};

/** Build a unified schedule from the show dates + the extra phases.
 *  Times for the show phase are pulled from `extra.show` (where the
 *  popover stores them) and merged onto the date range. */
export function buildProjectSchedule(
  reportDate: string,
  reportEndDate: string,
  extra: ExtraSchedule,
): ProjectSchedule {
  const out: ProjectSchedule = { ...extra };
  if (reportDate || reportEndDate) {
    const existingShow = out.show;
    out.show = {
      from: reportDate,
      to: reportEndDate || reportDate,
      fromTime: existingShow?.fromTime,
      toTime: existingShow?.toTime,
    };
  } else if (out.show && !out.show.fromTime && !out.show.toTime) {
    delete out.show;
  }
  return out;
}

/**
 * The user's theme preference. "system" follows the OS / browser
 * `prefers-color-scheme` setting. Old saved states with "light" / "dark"
 * remain valid (back-compat); new users default to "system".
 */
type ThemePref = "light" | "dark" | "system";

type PersistedV2 = {
  theme: ThemePref;
  venue: string;
  reportDate: string;
  /** Optional end date for the SHOW phase. Empty = single day.
   *  ISO date (YYYY-MM-DD). */
  reportEndDate?: string;
  /** Optional ranges for the other production phases — setup, rehearsal,
   *  downrig. The show phase is stored in reportDate/reportEndDate. */
  extraSchedule?: ExtraSchedule;
  engineer: string;
  systems: System[];
  activeSystemId: string;
  showFixtures?: ShowFixture[];
  mainView?: MainView;
  /** DMX/position overlays for fixtures linked from the rigging report,
   *  keyed by the source rigging Row id. */
  linkedMeta?: Record<string, LinkedMeta>;
  /** Manual (non-linked) LED screens added on the LED Screen Report tab. */
  ledScreens?: LedScreen[];
  /** Per-screen overlay (panel type, layout, output, color, notes) for LED
   *  screens linked from a rigging ledRow, keyed by source Row id. */
  ledLinkedMeta?: Record<string, LedLinkedMeta>;
  /** LED Screen Report settings (port limit, label visibility). */
  ledSettings?: LedSettings;
  /** Stage Report — list of stages (Nivtec deck calculator). */
  stages?: Stage[];
  /** Crew Report — call-sheet of crew members. */
  crew?: CrewMember[];
  /** Sound Report — audio inventory items. */
  soundItems?: SoundItem[];
  /** Lighting Report → Power Plan — circuits and per-phase items. */
  power?: PowerPlan;
  /** Rigg Plan — venue + per-system truss positions. */
  riggPlan?: RiggPlan;
};

/** Defensive read of arbitrary persisted JSON into a clean
 *  ExtraSchedule. Unknown keys / non-string fields are dropped so
 *  malformed localStorage cannot inject invalid date strings into
 *  the date-input UI. */
function sanitizeExtraSchedule(raw: unknown): ExtraSchedule {
  if (!raw || typeof raw !== "object") return {};
  const obj = raw as Record<string, unknown>;
  const out: ExtraSchedule = {};
  (["setup", "rehearsal", "show", "downrig"] as const).forEach((k) => {
    const ph = obj[k];
    if (!ph || typeof ph !== "object") return;
    const phObj = ph as Record<string, unknown>;
    const from = typeof phObj.from === "string" ? phObj.from : "";
    const to = typeof phObj.to === "string" ? phObj.to : "";
    const fromTime =
      typeof phObj.fromTime === "string" ? phObj.fromTime : undefined;
    const toTime =
      typeof phObj.toTime === "string" ? phObj.toTime : undefined;
    if (!from && !to && !fromTime && !toTime) return;
    out[k] = { from, to, fromTime, toTime };
  });
  return out;
}

function loadPersisted(): Partial<PersistedV2> | null {
  try {
    const rawV2 = localStorage.getItem(STORAGE_KEY_V2);
    if (rawV2) {
      const parsed = JSON.parse(rawV2) as Partial<PersistedV2>;
      // Sanitize the only field whose shape we care to harden — the
      // rest of PersistedV2 was already trusted before this change.
      return {
        ...parsed,
        extraSchedule: sanitizeExtraSchedule(parsed.extraSchedule),
      };
    }

    const rawV1 = localStorage.getItem(STORAGE_KEY_V1);
    if (rawV1) {
      const v1 = JSON.parse(rawV1);
      const sys: System = {
        id: newId("sys"),
        name: v1.systemName || "LX1",
        pointCount: v1.pointCount ?? 3,
        dynamicFactor: v1.dynamicFactor ?? 1.25,
        hoistIndex: v1.hoistIndex ?? 0,
        riggingRows: Array.isArray(v1.riggingRows)
          ? v1.riggingRows
          : [makeRow("Truss", 4)],
        fixtureRows: Array.isArray(v1.fixtureRows) ? v1.fixtureRows : [],
        ledRows: Array.isArray(v1.ledRows) ? v1.ledRows : [],
      };
      return {
        theme: v1.theme ?? "system",
        venue: v1.venue ?? "",
        reportDate: v1.reportDate ?? new Date().toISOString().slice(0, 10),
        engineer: v1.engineer ?? "",
        systems: [sys],
        activeSystemId: sys.id,
      };
    }
    return null;
  } catch {
    return null;
  }
}

type SystemMetrics = {
  payload: number;
  power: number;
  area: number;
  static: number;
  dynamic: number;
  motorPower: number;
  peak: number;
  swl: number;
  headroom: number;
  factors: number[];
  staticPointLoads: number[];
  dynamicPointLoads: number[];
  hoist: Hoist;
};

function computeMetrics(sys: System): SystemMetrics {
  let payload = 0,
    power = 0,
    area = 0;
  for (const row of [...sys.riggingRows, ...sys.fixtureRows, ...sys.ledRows]) {
    const item = getRowItem(row);
    if (!item) continue;
    payload += item.weight * row.qty;
    power += item.wattage * row.qty;
    area += item.area * row.qty;
  }
  const hoist = getHoist(sys.hoistIndex);
  const motorPower = hoist.watt * sys.pointCount;
  const staticTotal = payload + sys.pointCount * hoist.weight;
  const dynamicTotal = staticTotal * sys.dynamicFactor;
  const factors = distributionFactors[sys.pointCount] ?? [];
  const staticPointLoads = factors.map((f) => staticTotal * f);
  const dynamicPointLoads = factors.map((f) => dynamicTotal * f);
  const peak = dynamicPointLoads.length ? Math.max(...dynamicPointLoads) : 0;
  return {
    payload,
    power,
    area,
    static: staticTotal,
    dynamic: dynamicTotal,
    motorPower,
    peak,
    swl: hoist.swl,
    headroom: hoist.swl - peak,
    factors,
    staticPointLoads,
    dynamicPointLoads,
    hoist,
  };
}

function SignOutButton() {
  const { signOut } = useClerk();
  const { user } = useUser();
  const label =
    user?.primaryEmailAddress?.emailAddress ??
    user?.username ??
    user?.firstName ??
    "Account";
  return (
    <button
      className="btn btn-reset"
      onClick={() => {
        try {
          sessionStorage.setItem("ehs-skip-dev-auto-signin", "1");
        } catch {
          /* sessionStorage may be unavailable */
        }
        try {
          localStorage.removeItem("ehs-user-role");
        } catch {
          /* localStorage may be unavailable */
        }
        void signOut();
      }}
      title={`Signed in as ${label}. Click to sign out.`}
      style={{ display: "inline-flex", alignItems: "center", gap: 6 }}
    >
      <span style={{ opacity: 0.85 }}>{label}</span>
      <span aria-hidden>·</span>
      <span>Sign out</span>
    </button>
  );
}

/**
 * Three-way theme picker shown in the top-right of the dashboard header.
 * Lets the user choose Light, Dark, or System (follow OS `prefers-color-scheme`).
 *
 * Implements the ARIA radiogroup keyboard pattern: only the selected radio is
 * in the tab order (`tabIndex=0`); ArrowLeft/Right (and Home/End) move focus
 * AND change the selection.
 */
function ThemeSegmentedControl({
  pref,
  onChange,
}: {
  pref: ThemePref;
  onChange: (next: ThemePref) => void;
}) {
  const options = useMemo<
    ReadonlyArray<{ value: ThemePref; label: string; icon: string }>
  >(
    () => [
      { value: "light", label: "Light", icon: "☀" },
      { value: "dark", label: "Dark", icon: "☾" },
      { value: "system", label: "System", icon: "⌬" },
    ],
    [],
  );
  const btnRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const selectedIndex = Math.max(
    0,
    options.findIndex((o) => o.value === pref),
  );
  const move = (next: number) => {
    const i = ((next % options.length) + options.length) % options.length;
    onChange(options[i].value);
    btnRefs.current[i]?.focus();
  };
  const onKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    switch (e.key) {
      case "ArrowRight":
      case "ArrowDown":
        e.preventDefault();
        move(selectedIndex + 1);
        break;
      case "ArrowLeft":
      case "ArrowUp":
        e.preventDefault();
        move(selectedIndex - 1);
        break;
      case "Home":
        e.preventDefault();
        move(0);
        break;
      case "End":
        e.preventDefault();
        move(options.length - 1);
        break;
      default:
        break;
    }
  };
  return (
    <div
      role="radiogroup"
      aria-label="Theme"
      className="theme-seg"
      title="Choose theme: Light, Dark, or System"
      onKeyDown={onKeyDown}
    >
      {options.map((o, i) => {
        const selected = pref === o.value;
        return (
          <button
            key={o.value}
            ref={(el) => {
              btnRefs.current[i] = el;
            }}
            type="button"
            role="radio"
            aria-checked={selected}
            aria-label={`${o.label} theme`}
            tabIndex={selected ? 0 : -1}
            className={`theme-seg-btn${selected ? " is-selected" : ""}`}
            onClick={() => onChange(o.value)}
          >
            <span aria-hidden>{o.icon}</span>
            <span className="theme-seg-label">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function App() {
  const persisted = useRef<Partial<PersistedV2> | null>(loadPersisted()).current;
  const initialSystem = makeSystem("LX1");

  const [themePref, setThemePref] = useState<ThemePref>(() => {
    const t = persisted?.theme;
    return t === "light" || t === "dark" || t === "system" ? t : "system";
  });
  const [systemTheme, setSystemTheme] = useState<"light" | "dark">(() => {
    if (typeof window === "undefined" || !window.matchMedia) return "light";
    return window.matchMedia("(prefers-color-scheme: dark)").matches
      ? "dark"
      : "light";
  });
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = (e: MediaQueryListEvent) =>
      setSystemTheme(e.matches ? "dark" : "light");
    if (typeof mq.addEventListener === "function") {
      mq.addEventListener("change", handler);
      return () => mq.removeEventListener("change", handler);
    }
    // Older Safari fallback
    mq.addListener(handler);
    return () => mq.removeListener(handler);
  }, []);
  const theme: "light" | "dark" =
    themePref === "system" ? systemTheme : themePref;
  const [venue, setVenue] = useState(persisted?.venue ?? "");
  const [reportDate, setReportDate] = useState(
    persisted?.reportDate ?? new Date().toISOString().slice(0, 10),
  );
  const [reportEndDate, setReportEndDate] = useState(
    persisted?.reportEndDate ?? "",
  );
  const [extraSchedule, setExtraSchedule] = useState<ExtraSchedule>(
    persisted?.extraSchedule ?? {},
  );
  const [engineer, setEngineer] = useState(persisted?.engineer ?? "");
  const [systems, setSystems] = useState<System[]>(
    persisted?.systems && persisted.systems.length > 0
      ? persisted.systems
      : [initialSystem],
  );
  const [activeSystemId, setActiveSystemId] = useState<string>(() => {
    const fromPersisted = persisted?.activeSystemId;
    const list = persisted?.systems && persisted.systems.length > 0
      ? persisted.systems
      : [initialSystem];
    if (fromPersisted && list.some((s) => s.id === fromPersisted)) {
      return fromPersisted;
    }
    return list[0].id;
  });

  const [mainView, setMainView] = useState<MainView>(persisted?.mainView ?? "rigging");
  /** Equipment-library picker state. `target` controls which add-handler the
   *  picked item flows into; `null` means the picker is closed. */
  const [pickerTarget, setPickerTarget] = useState<
    | null
    | { kind: "sound" }
    | { kind: "lighting" }
    | { kind: "power"; circuitId: string; phase: PowerPhase }
  >(null);
  const closePicker = () => setPickerTarget(null);
  const [showFixtures, setShowFixtures] = useState<ShowFixture[]>(
    persisted?.showFixtures ?? [],
  );
  const [linkedMeta, setLinkedMeta] = useState<Record<string, LinkedMeta>>(
    persisted?.linkedMeta ?? {},
  );
  const [ledScreens, setLedScreens] = useState<LedScreen[]>(
    () =>
      (persisted?.ledScreens ?? []).map((s) => ({
        ...s,
        panelKey: migrateLedPanelKey(s.panelKey),
      })),
  );
  const [ledLinkedMeta, setLedLinkedMeta] = useState<
    Record<string, LedLinkedMeta>
  >(() => {
    const raw = persisted?.ledLinkedMeta ?? {};
    const out: Record<string, LedLinkedMeta> = {};
    for (const [k, v] of Object.entries(raw)) {
      out[k] = { ...v, panelKey: migrateLedPanelKey(v.panelKey) };
    }
    return out;
  });
  const [ledSettings, setLedSettings] = useState<LedSettings>(
    normalizeLedSettings(persisted?.ledSettings),
  );
  const [crew, setCrew] = useState<CrewMember[]>(
    () => (persisted?.crew ?? []).map(normalizeCrewMember),
  );
  const [soundItems, setSoundItems] = useState<SoundItem[]>(
    () => (persisted?.soundItems ?? []).map(normalizeSoundItem),
  );
  const [power, setPower] = useState<PowerPlan>(
    () => normalizePowerPlan(persisted?.power),
  );
  const [stages, setStages] = useState<Stage[]>(
    () => (persisted?.stages ?? []).map(normalizeStage),
  );
  const [riggPlan, setRiggPlan] = useState<RiggPlan>(() =>
    normalizeRiggPlan(persisted?.riggPlan),
  );

  // The floor-plan backdrop library lives in its own localStorage slot
  // so a few MB of drawing data URLs never bloat the main report blob
  // (and a QuotaExceededError on the floor-plan slot doesn't kill the
  // rest of the report's autosave). The producer can stack multiple
  // drawings — one of them is "active" at a time and rendered behind
  // the Rigg Plan canvas.
  const [floorPlanLibrary, setFloorPlanLibrary] = useState<FloorPlanLibrary>(
    () => loadFloorPlanLibrary(),
  );
  useEffect(() => {
    saveFloorPlanLibrary(floorPlanLibrary);
  }, [floorPlanLibrary]);
  /** Append a new drawing to the library and make it the active
   *  backdrop. Used by the Drawing Importer's "Use as floor plan"
   *  button — calling it three times stacks three plans the user can
   *  switch between. */
  const addFloorPlan = (plan: FloorPlan) => {
    setFloorPlanLibrary((lib) => ({
      plans: [...lib.plans, plan],
      activeId: plan.id,
    }));
  };
  /** Remove a single plan by id. If the active plan was removed, fall
   *  back to the next one in the list (or `null` if the library is
   *  empty afterwards) so the canvas always knows what to render. */
  const removeFloorPlan = (id: string) => {
    setFloorPlanLibrary((lib) => {
      const plans = lib.plans.filter((p) => p.id !== id);
      const activeId =
        lib.activeId === id
          ? (plans[0]?.id ?? null)
          : lib.activeId;
      return { plans, activeId };
    });
  };
  /** Switch which plan is shown as the backdrop. Pass `null` to hide
   *  the backdrop without deleting any plans. */
  const selectFloorPlan = (id: string | null) => {
    setFloorPlanLibrary((lib) => ({
      ...lib,
      activeId: id == null ? null : (lib.plans.some((p) => p.id === id) ? id : lib.activeId),
    }));
  };

  const [modalTarget, setModalTarget] = useState<Category | null>(null);
  const [custName, setCustName] = useState("");
  const [custWeight, setCustWeight] = useState("");
  const [custWatt, setCustWatt] = useState("");
  const [custArea, setCustArea] = useState("");

  const [savedAt, setSavedAt] = useState<string>("");
  const [shareOpen, setShareOpen] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  useEffect(() => {
    const data: PersistedV2 = {
      theme: themePref,
      venue,
      reportDate,
      reportEndDate,
      extraSchedule,
      engineer,
      systems,
      activeSystemId,
      showFixtures,
      mainView,
      linkedMeta,
      ledScreens,
      ledLinkedMeta,
      ledSettings,
      stages,
      crew,
      soundItems,
      power,
      riggPlan,
    };
    try {
      localStorage.setItem(STORAGE_KEY_V2, JSON.stringify(data));
      setSavedAt(
        new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      );
    } catch {
      /* ignore quota errors */
    }
  }, [
    themePref,
    venue,
    reportDate,
    reportEndDate,
    extraSchedule,
    engineer,
    systems,
    activeSystemId,
    showFixtures,
    mainView,
    linkedMeta,
    ledScreens,
    ledLinkedMeta,
    ledSettings,
    stages,
    crew,
    soundItems,
    power,
    riggPlan,
  ]);

  const activeSystem =
    systems.find((s) => s.id === activeSystemId) ?? systems[0];

  const updateActiveSystem = (updates: Partial<System>) => {
    setSystems((all) =>
      all.map((s) => (s.id === activeSystem.id ? { ...s, ...updates } : s)),
    );
  };

  const updateRowsKey = (
    key: "riggingRows" | "fixtureRows" | "ledRows",
    fn: (rows: Row[]) => Row[],
  ) => {
    setSystems((all) =>
      all.map((s) =>
        s.id === activeSystem.id ? { ...s, [key]: fn(s[key]) } : s,
      ),
    );
  };

  const addSystem = () => {
    const nextNumber = systems.length + 1;
    let baseName = `LX${nextNumber}`;
    while (systems.some((s) => s.name === baseName)) baseName += "'";
    const sys = makeSystem(baseName);
    setSystems((all) => [...all, sys]);
    setActiveSystemId(sys.id);
  };

  const duplicateActiveSystem = () => {
    const copy: System = {
      ...activeSystem,
      id: newId("sys"),
      name: `${activeSystem.name} copy`,
      riggingRows: activeSystem.riggingRows.map((r) => ({ ...r, id: newId("row") })),
      fixtureRows: activeSystem.fixtureRows.map((r) => ({ ...r, id: newId("row") })),
      ledRows: activeSystem.ledRows.map((r) => ({ ...r, id: newId("row") })),
    };
    setSystems((all) => [...all, copy]);
    setActiveSystemId(copy.id);
  };

  const removeSystem = (id: string) => {
    const target = systems.find((s) => s.id === id);
    if (!target) return;
    // When this is the last system left, deleting used to be blocked
    // outright. That made it impossible to wipe a set of imported
    // LX1/LX2/... systems and start fresh — the last row was always
    // stuck. Now we still need ≥ 1 system in the report (the rest of
    // the UI assumes activeSystem exists), but we satisfy that by
    // auto-creating one empty "System 1" to replace it. End result:
    // user can click × down the whole list and land on a true clean
    // slate without touching the venue, inventory, or floor plans.
    const isLast = systems.length <= 1;
    const promptMsg = isLast
      ? `Remove rigging system "${target.name}" and start fresh? Its gear list will be lost and a new empty "System 1" will replace it.`
      : `Remove rigging system "${target.name}"? Its gear list will be lost.`;
    if (!confirm(promptMsg)) return;

    if (isLast) {
      const fresh = makeEmptySystem("System 1");
      setSystems([fresh]);
      setActiveSystemId(fresh.id);
      return;
    }
    const remaining = systems.filter((s) => s.id !== id);
    setSystems(remaining);
    if (activeSystemId === id) setActiveSystemId(remaining[0].id);
  };

  const openModal = (category: Category) => {
    setModalTarget(category);
    setCustName("");
    setCustWeight("");
    setCustWatt("");
    setCustArea("");
  };
  const closeModal = () => setModalTarget(null);

  // ── Show Fixtures (Lighting Plan) ───────────────────────────────────────

  // Garbage-collect linkedMeta entries whose source rigging row no longer
  // exists (system or fixtureRow was deleted). Keeps localStorage tidy.
  useEffect(() => {
    const liveIds = new Set<string>();
    for (const sys of systems)
      for (const row of sys.fixtureRows) liveIds.add(row.id);
    setLinkedMeta((all) => {
      const keys = Object.keys(all);
      const orphans = keys.filter((k) => !liveIds.has(k));
      if (orphans.length === 0) return all;
      const next: Record<string, LinkedMeta> = {};
      for (const k of keys) if (liveIds.has(k)) next[k] = all[k];
      return next;
    });
  }, [systems]);

  /** Fixtures auto-derived from each rigging system's fixtureRows. Read-only
   *  base info (name/qty/weight/watts/systemId); DMX/position overlays come
   *  from `linkedMeta` keyed by the source rigging Row id. */
  const linkedFixtures = useMemo<ShowFixture[]>(() => {
    const out: ShowFixture[] = [];
    for (const sys of systems) {
      for (const row of sys.fixtureRows) {
        const item = getRowItem(row);
        if (!item) continue;
        const stored = linkedMeta[row.id];
        const meta = stored ?? defaultLinkedMeta();

        // Resolve DMX mode + channel count.
        // - Item has modes + meta.dmxModeIndex is a valid index → use mode's channels
        // - Item has modes + meta.dmxModeIndex === null → "Custom" override (use stored channels)
        // - Item has modes + no stored meta → default to first mode
        // - Item has no modes → use stored channels (free entry)
        const modes = item.dmxModes;
        let resolvedModeIndex: number | null | undefined;
        let resolvedChannels: number;
        if (modes && modes.length > 0) {
          if (!stored || meta.dmxModeIndex === undefined) {
            // No stored meta OR legacy meta from before dmxModes existed
            // (no dmxModeIndex field) → default to first mode. This avoids
            // dropping channels to 0 for users upgrading from older saves.
            resolvedModeIndex = 0;
            resolvedChannels = modes[0].channels;
          } else if (
            meta.dmxModeIndex !== null &&
            meta.dmxModeIndex >= 0 &&
            meta.dmxModeIndex < modes.length
          ) {
            resolvedModeIndex = meta.dmxModeIndex;
            resolvedChannels = modes[meta.dmxModeIndex].channels;
          } else {
            // null (explicit Custom) or out-of-range → custom entry
            resolvedModeIndex = null;
            resolvedChannels = meta.dmxChannels;
          }
        } else {
          resolvedModeIndex = undefined;
          resolvedChannels = meta.dmxChannels;
        }

        out.push({
          id: `linked-${row.id}`,
          name: item.name,
          qty: row.qty,
          weight: item.weight,
          watts: item.wattage,
          systemId: sys.id,
          linked: true,
          sourceRowId: row.id,
          dmxChannels: resolvedChannels,
          dmxModeIndex: resolvedModeIndex,
          availableDmxModes: modes,
          beamAngle: meta.beamAngle,
          position: meta.position,
          circuit: meta.circuit,
          universe: meta.universe,
          startAddress: meta.startAddress,
          notes: meta.notes,
        });
      }
    }
    return out;
  }, [systems, linkedMeta]);

  const allLightingFixtures = useMemo<ShowFixture[]>(
    () => [...linkedFixtures, ...showFixtures],
    [linkedFixtures, showFixtures],
  );

  // ── LED Screen Report ──────────────────────────────────────────────────

  /** Panel library derived directly from the rigging report's "LED Screen"
   *  inventory. Items without pixel/physical info (e.g. Molton fabric) are
   *  filtered out. A synthetic "Custom panel…" entry is appended last. */
  const ledPanels = useMemo(
    () => buildLedPanels(inventory["LED Screen"]),
    [],
  );
  const defaultLedPanelKey = useMemo(
    () => defaultPanelKeyOf(ledPanels),
    [ledPanels],
  );

  // Garbage-collect ledLinkedMeta entries whose source rigging ledRow no
  // longer exists OR is not a panel-mappable inventory item (e.g. Molton).
  useEffect(() => {
    const liveIds = new Set<string>();
    for (const sys of systems) {
      for (const row of sys.ledRows) {
        const item = getRowItem(row);
        if (item && findPanelKeyForInventoryName(item.name, ledPanels)) {
          liveIds.add(row.id);
        }
      }
    }
    setLedLinkedMeta((all) => {
      const keys = Object.keys(all);
      const orphans = keys.filter((k) => !liveIds.has(k));
      if (orphans.length === 0) return all;
      const next: Record<string, LedLinkedMeta> = {};
      for (const k of keys) if (liveIds.has(k)) next[k] = all[k];
      return next;
    });
  }, [systems, ledPanels]);

  /** Screens auto-derived from each rigging system's ledRows. Layout
   *  (panelsWide/Tall, output, color, notes) lives in `ledLinkedMeta`
   *  keyed by source Row id; qty changes nudge the default layout. */
  const linkedLedScreens = useMemo<LedScreen[]>(() => {
    const out: LedScreen[] = [];
    let colorIdx = 0;
    for (const sys of systems) {
      for (const row of sys.ledRows) {
        const item = getRowItem(row);
        if (!item) continue;
        const detected = findPanelKeyForInventoryName(item.name, ledPanels);
        if (!detected) continue;
        const stored = ledLinkedMeta[row.id];
        const fallback = defaultLinkedLedMeta(row.qty, detected);
        const meta: LedLinkedMeta = stored ?? {
          ...fallback,
          color: LED_SCREEN_COLORS[colorIdx % LED_SCREEN_COLORS.length],
        };
        colorIdx++;
        const autoName = `${sys.name} · ${item.name}`;
        const displayName =
          meta.nameOverride && meta.nameOverride.trim().length > 0
            ? meta.nameOverride
            : autoName;
        out.push({
          id: `led-linked-${row.id}`,
          name: displayName,
          panelKey: meta.panelKey,
          panelsWide: meta.panelsWide,
          panelsTall: meta.panelsTall,
          color: meta.color,
          outputIndex: meta.outputIndex,
          notes: meta.notes,
          customPanel: meta.customPanel,
          linked: true,
          sourceRowId: row.id,
          // Project per-screen annotations from the linked meta into the
          // resolved screen so the visual / export / share path treats
          // linked and manual screens identically.
          nameScale: meta.nameScale,
          markers: meta.markers,
        });
      }
    }
    return out;
  }, [systems, ledLinkedMeta, ledPanels]);

  const allLedScreens = useMemo<LedScreen[]>(
    () => [...linkedLedScreens, ...ledScreens],
    [linkedLedScreens, ledScreens],
  );

  const ledTotals = useMemo(
    () => computeLedTotals(allLedScreens, ledSettings, ledPanels),
    [allLedScreens, ledSettings, ledPanels],
  );

  /** Project state assembled into the shape the brief encoder needs.
   *  Resolves hoist labels (from the App-level `hoistModels` table) and
   *  LED panel definitions (from the dynamic `ledPanels` list) here so
   *  the share modal — and the projectBrief lib — never have to reach
   *  back into App-level state. Recomputed when any source field changes. */
  const briefInput = useMemo<BuildBriefInput>(() => {
    return {
      venue,
      reportDate,
      reportEndDate,
      schedule: buildProjectSchedule(reportDate, reportEndDate, extraSchedule),
      engineer,
      // The `recipientCrewId` is overridden per-link by ShareBriefModal.
      recipientCrewId: null,
      crew,
      rigging: {
        systems: systems.map((s) => {
          const hoist = getHoist(s.hoistIndex);
          return {
            id: s.id,
            name: s.name,
            pointCount: s.pointCount,
            dynamicFactor: s.dynamicFactor,
            hoistLabel: hoist.label,
            hoistWatt: hoist.watt,
            riggingRowCount: s.riggingRows.length,
            fixtureRowCount: s.fixtureRows.length,
            ledRowCount: s.ledRows.length,
          };
        }),
      },
      lighting: {
        showFixtures: allLightingFixtures.map((f) => ({
          qty: f.qty,
          watts: f.watts,
          universe: f.universe,
        })),
        power: {
          circuits: power.circuits.map((c) => ({
            voltage: c.voltage,
            ampsPerPhase: c.ampsPerPhase,
            items: c.items.map((it) => ({
              qty: it.qty,
              wattsPerUnit: it.wattsPerUnit,
              phase: it.phase,
            })),
          })),
        },
      },
      led: {
        ledScreens: allLedScreens.map((s) => {
          const panel = resolveScreenPanel(s, ledPanels);
          return {
            id: s.id,
            name: s.name,
            panelType: panel.name,
            cols: s.panelsWide,
            rows: s.panelsTall,
            panelWatts: panel.power,
          };
        }),
        processor: findProcessor(ledSettings.processorId)?.name ?? "",
      },
      stages,
      sound: soundItems,
      riggPlan,
      // Pass-through state used by ShareBriefModal to render one PNG
      // per LED screen (with the producer's pill-size + power/signal
      // markers) and upload it as a brief attachment. Not embedded in
      // the brief itself — only used to drive the upload step.
      ledDiagrams: {
        screens: allLedScreens,
        panels: ledPanels,
        settings: ledSettings,
      },
    };
  }, [
    venue,
    reportDate,
    reportEndDate,
    extraSchedule,
    engineer,
    crew,
    systems,
    allLightingFixtures,
    power,
    allLedScreens,
    ledPanels,
    ledSettings,
    stages,
    soundItems,
    riggPlan,
  ]);

  const addLedScreen = () => {
    const idx = ledScreens.length + linkedLedScreens.length;
    setLedScreens((all) => [
      ...all,
      newLedScreen(defaultLedPanelKey, {
        name: `Screen ${idx + 1}`,
        color: LED_SCREEN_COLORS[idx % LED_SCREEN_COLORS.length],
      }),
    ]);
  };

  const updateLedScreen = (id: string, patch: Partial<LedScreen>) => {
    if (id.startsWith("led-linked-")) {
      const sourceRowId = id.slice("led-linked-".length);
      // Snapshot the currently-resolved linked screen as the base for the
      // first edit, so we don't drop the qty-derived default layout when
      // the user simply changes a single field like color or notes.
      const current = allLedScreens.find((s) => s.id === id);
      const seed: LedLinkedMeta = current
        ? {
            panelKey: current.panelKey,
            panelsWide: current.panelsWide,
            panelsTall: current.panelsTall,
            color: current.color,
            outputIndex: current.outputIndex,
            notes: current.notes,
            customPanel: current.customPanel,
          }
        : defaultLinkedLedMeta(1, defaultLedPanelKey);
      setLedLinkedMeta((all) => {
        const prev = all[sourceRowId] ?? seed;
        const next: LedLinkedMeta = {
          ...prev,
          ...("panelKey" in patch ? { panelKey: patch.panelKey! } : {}),
          ...("panelsWide" in patch ? { panelsWide: patch.panelsWide! } : {}),
          ...("panelsTall" in patch ? { panelsTall: patch.panelsTall! } : {}),
          ...("color" in patch ? { color: patch.color! } : {}),
          ...("outputIndex" in patch
            ? { outputIndex: patch.outputIndex ?? null }
            : {}),
          ...("notes" in patch ? { notes: patch.notes ?? "" } : {}),
          ...("customPanel" in patch
            ? { customPanel: patch.customPanel }
            : {}),
          // Persist a user-typed display name for a linked screen. Empty
          // string clears the override and restores the auto-generated name.
          ...("name" in patch
            ? { nameOverride: patch.name ?? "" }
            : {}),
          // Per-screen annotation patches: forwarded into the linked
          // meta so the field survives unlink / relink cycles and is
          // available to any consumer reading from `linkedLedScreens`.
          ...("nameScale" in patch
            ? { nameScale: patch.nameScale }
            : {}),
          ...("markers" in patch
            ? { markers: patch.markers ? [...patch.markers] : [] }
            : {}),
        };
        return { ...all, [sourceRowId]: next };
      });
      return;
    }
    setLedScreens((all) =>
      all.map((s) => (s.id === id ? { ...s, ...patch } : s)),
    );
  };

  const updateLedCustomPanel = (
    id: string,
    patch: Partial<LedCustomPanel>,
  ) => {
    const screen = allLedScreens.find((s) => s.id === id);
    if (!screen) return;
    const base =
      screen.customPanel ??
      ({
        pixelWidth: CUSTOM_LED_PANEL.pixelWidth,
        pixelHeight: CUSTOM_LED_PANEL.pixelHeight,
        physicalWidth: CUSTOM_LED_PANEL.physicalWidth,
        physicalHeight: CUSTOM_LED_PANEL.physicalHeight,
        weight: CUSTOM_LED_PANEL.weight,
        power: CUSTOM_LED_PANEL.power,
      } as LedCustomPanel);
    updateLedScreen(id, { customPanel: { ...base, ...patch } });
  };

  const removeLedScreen = (id: string) => {
    if (id.startsWith("led-linked-")) return; // linked rows can't be deleted here
    setLedScreens((all) => all.filter((s) => s.id !== id));
  };

  const duplicateLedScreen = (id: string) => {
    const src = allLedScreens.find((s) => s.id === id);
    if (!src) return;
    setLedScreens((all) => [
      ...all,
      newLedScreen(defaultLedPanelKey, {
        name: `${src.name} (copy)`,
        panelKey: src.panelKey,
        panelsWide: src.panelsWide,
        panelsTall: src.panelsTall,
        color: src.color,
        outputIndex: null,
        notes: src.notes,
        customPanel: src.customPanel,
        // Carry the producer's pill scaling and cable markers across the
        // duplicate, so "copy of X" matches what they see on screen X.
        // Markers are deep-copied with fresh ids so editing the copy
        // never mutates the original (and to prevent React key clashes).
        nameScale: src.nameScale,
        markers: (src.markers ?? []).map((m, i) => ({
          ...m,
          id: `${src.id}-dup-${Date.now()}-${i}`,
        })),
      }),
    ]);
  };

  const updateLedSettings = (patch: Partial<LedSettings>) => {
    setLedSettings((s) => ({ ...s, ...patch }));
  };

  const exportLedScreen = async (id: string) => {
    const screen = allLedScreens.find((s) => s.id === id);
    if (!screen) return;
    try {
      const logoDataUrl = await getLogoDataUrl(ehsLogo);
      await exportScreenAsPng({
        screen,
        panels: ledPanels,
        settings: ledSettings,
        logoDataUrl,
      });
    } catch (err) {
      console.error("PNG export failed:", err);
      alert(
        "Could not generate the PNG. Try a smaller screen or check the console for details.",
      );
    }
  };

  // ---- Rigg Plan ----
  // Garbage-collect orphan trusses whenever a system gets deleted, so
  // the persisted blob never accumulates stale entries from removed
  // systems. Keyed on the live system-id list (stable string) so this
  // doesn't fire on every drag.
  const liveSystemIds = systems.map((s) => s.id).join("|");
  useEffect(() => {
    setRiggPlan((p) => {
      const live = new Set(systems.map((s) => s.id));
      const next: Record<string, RiggPlanTruss> = {};
      let changed = false;
      for (const [id, t] of Object.entries(p.trussById)) {
        if (live.has(id)) next[id] = t;
        else changed = true;
      }
      return changed ? { ...p, trussById: next } : p;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [liveSystemIds]);

  const updateRiggPlanVenue = (patch: Partial<RiggPlanVenue>) => {
    setRiggPlan((p) => {
      // If the producer has deleted the venue, an "update" implicitly
      // re-creates it with default dimensions before applying the patch
      // — so e.g. the drawing-importer's "Apply venue" path can always
      // populate a venue, even from the empty state.
      const base = p.venue ?? makeDefaultVenue();
      const venue = { ...base, ...patch };
      // Re-clamp every existing truss into the new venue so shrinking
      // the venue can never leave trusses dangling outside it.
      const trussById: Record<string, RiggPlanTruss> = {};
      for (const [id, t] of Object.entries(p.trussById)) {
        trussById[id] = clampTrussToVenue(t, venue);
      }
      return { venue, trussById };
    });
  };
  /** Add a fresh venue with default dimensions when the Rigg Plan is
   *  empty. Re-uses the default-build helper so any future tweak to
   *  defaults flows through both first-load and "Add venue". */
  const addRiggPlanVenue = () => {
    setRiggPlan((p) => ({
      ...p,
      venue: p.venue ?? makeDefaultVenue(),
    }));
  };
  /** Delete the venue and every truss associated with it. Trusses and
   *  the floor-plan backdrop image both live in the venue's coordinate
   *  frame, so keeping them around when the venue is gone would leak
   *  hidden state and surprise the user the next time they add a venue
   *  back. The rigging systems themselves are not touched — they stay
   *  on the Rigging Report and will get re-seeded with default truss
   *  positions the next time a venue exists. */
  const deleteRiggPlanVenue = () => {
    if (
      !confirm(
        "Delete the venue? The floor plan and every placed truss will be cleared. The rigging systems themselves stay on the Rigging Report.",
      )
    ) {
      return;
    }
    setRiggPlan(() => ({ venue: null, trussById: {} }));
    setFloorPlanLibrary(emptyFloorPlanLibrary());
  };
  const updateRiggPlanTruss = (
    systemId: string,
    patch: Partial<RiggPlanTruss>,
  ) => {
    setRiggPlan((p) => {
      const prev = p.trussById[systemId];
      const next: RiggPlanTruss = prev
        ? { ...prev, ...patch }
        : ({
            x: 0,
            y: 0,
            z: 6,
            lengthM: 6,
            rotation: 0,
            ...patch,
          } as RiggPlanTruss);
      return {
        ...p,
        trussById: { ...p.trussById, [systemId]: next },
      };
    });
  };

  /** Apply the user-vetted output of the drawing analyser. Each category
   *  is added through the same factories the manual "+ New" buttons use,
   *  so the items appear in their respective tabs as plain editable rows. */
  const applyExtractedItems = (
    extracted: ExtractedItems,
    selection: ApplySelection,
  ): ApplySummary => {
    // Cross-PDF dedup is the heart of this function: when the producer
    // uploads several drawings of the same project, items that recur
    // across them (e.g. an "LX1" truss visible on the rigging plan AND
    // the lighting plan) must collapse to ONE entry on the report
    // rather than stack as duplicates. Each category gets a normalised-
    // name lookup against the existing report; matches are skipped and
    // counted in the returned summary.
    const summary = emptyApplySummary();

    // Venue (Rigg Plan)
    if (selection.applyVenue) {
      const venuePatch: Partial<RiggPlanVenue> = {};
      if (extracted.venue.widthM != null && extracted.venue.widthM > 0) {
        venuePatch.widthM = Math.max(1, Math.round(extracted.venue.widthM * 2) / 2);
      }
      if (extracted.venue.depthM != null && extracted.venue.depthM > 0) {
        venuePatch.depthM = Math.max(1, Math.round(extracted.venue.depthM * 2) / 2);
      }
      if (extracted.venue.ceilingM != null && extracted.venue.ceilingM > 0) {
        venuePatch.ceilingM = Math.max(
          1,
          Math.round(extracted.venue.ceilingM * 2) / 2,
        );
      }
      if (Object.keys(venuePatch).length > 0) {
        updateRiggPlanVenue(venuePatch);
        summary.venueApplied = true;
      }
    }

    // Trusses → new Systems on the Rigging Report.
    //
    // We also keep a name → systemId map covering BOTH systems that
    // already existed and the ones we are about to create, so the
    // Lighting step below can attach each fixture to the same system
    // its truss resolves to. Names are matched case-insensitively
    // because operators on a drawing aren't always consistent
    // ("LX1" vs "Lx 1" vs "lx-1").
    const newSystems: System[] = [];
    const usedNames = new Set(systems.map((s) => s.name));
    /** Lower-cased, whitespace-collapsed lookup key for truss names. */
    const trussKey = (s: string): string =>
      s.trim().toLowerCase().replace(/[\s_-]+/g, "");
    const systemIdByTrussName = new Map<string, string>();
    for (const sys of systems) {
      const k = trussKey(sys.name);
      if (k) systemIdByTrussName.set(k, sys.id);
    }

    /** Add `key → id` to the map only the FIRST time we see `key`.
     *  Used so that if the analyser emits two trusses with the same
     *  label ("LX1", "LX1"), all fixtures tagged "LX1" attach to the
     *  same (first) system instead of being split between them. */
    const indexTruss = (key: string, id: string) => {
      if (key && !systemIdByTrussName.has(key)) {
        systemIdByTrussName.set(key, id);
      }
    };

    /** Map the analyser's per-motor capacity in kg onto one of the
     *  two configured hoist models. We split at the geometric mean
     *  (~707 kg) of 500 and 1000 kg, but force anything ≥ 750 kg up
     *  to the 1 t model so a "1 t" tag never silently rounds down. */
    const pickHoistIndex = (kg: number | null): number => {
      if (kg == null) return 0;
      return kg >= 750 ? 1 : 0;
    };

    if (selection.trussIndexes.size > 0) {
      extracted.trusses.forEach((t, i) => {
        if (!selection.trussIndexes.has(i)) return;
        const rawName = t.name && t.name.trim() ? t.name.trim() : "";
        // Cross-PDF dedup: if a system with this normalised name
        // already exists OR we just created one in this same apply
        // call (handles "LX1" appearing twice in the same PDF too),
        // skip — the existing system stands. The fixture-linking map
        // already points at it, so any lighting tagged with this
        // name will still wire up correctly.
        const dedupKey = rawName ? trussKey(rawName) : "";
        if (dedupKey && systemIdByTrussName.has(dedupKey)) {
          summary.systems.skipped += 1;
          return;
        }
        let name =
          rawName || `LX${systems.length + newSystems.length + 1}`;
        while (usedNames.has(name)) name += "'";
        usedNames.add(name);
        const sys = makeSystem(name);
        sys.pointCount = Math.min(8, Math.max(1, Math.round(t.pointCount || 3)));
        sys.hoistIndex = pickHoistIndex(t.hoistKg);
        newSystems.push(sys);
        summary.systems.added += 1;
        // Index BOTH the original PDF label and the (possibly-suffixed)
        // final name, so a fixture that says trussName="LX1" still
        // resolves even if we had to rename the system to "LX1'" to
        // dedupe. First-write-wins: the FIRST truss row labelled "LX1"
        // owns that label for fixture-linking purposes.
        if (rawName) indexTruss(trussKey(rawName), sys.id);
        indexTruss(trussKey(name), sys.id);
      });
    }

    // Lighting fixtures.
    //
    // Each extracted fixture row may carry a `trussName` from the PDF
    // ("LX1", "FOH", …). We try to link it to:
    //   1. an existing system on the Rigging Report,
    //   2. one of the systems we just created above, or
    //   3. as a last resort, a fresh system auto-created on the fly so
    //      that "fixtures on the same truss end up on the same system"
    //      even when the user didn't tick the matching truss row.
    //
    // Once we have a target system, the fixture goes IN AS A
    // `fixtureRows` row on that system so it shows up under the
    // Rigging Report's "Lighting Fixtures" group AND contributes to
    // the system's load. We try to match the analyser's name against
    // the user's `inventory.Fixtures` library first — a match means we
    // use the user's calibrated weight / wattage / DMX modes instead
    // of the (often rough) PDF numbers. Misses fall back to a custom
    // row carrying the analyser's data verbatim. Fixtures with no
    // truss tag still go to the standalone `showFixtures` list so the
    // user can decide where to assign them.
    if (selection.lightingIndexes.size > 0) {
      const standaloneAdditions: ShowFixture[] = [];
      // systemId → Row[] to append for systems that already exist
      // (newSystems are mutated in place since we hold the references).
      const fixtureRowPatches = new Map<string, Row[]>();
      // Notes coming off the analyser need to ride along with the
      // resulting fixtureRow via linkedMeta (same way the user's own
      // notes are stored). Collected here, committed once below so we
      // don't fire one setLinkedMeta per fixture.
      const noteSeeds: Record<string, string> = {};
      // Build a "this system already has fixture X" lookup for dedup.
      // We use the same `normalizeFixtureName` the inventory matcher
      // uses, which strips parenthetical suffixes like "(32.0kg)" and
      // collapses non-alphanumerics — so an analyser hit on "Clay
      // Paky Mythos 2" matches an existing inventory row whose stored
      // name is "Clay Paky Mythos 2 (32.0kg)". A plain space-collapse
      // would have missed that case and let duplicates through across
      // PDFs. The set tracks `${systemId}|${normalisedName}` pairs.
      const fixtureNameKey = (s: string) => normalizeFixtureName(s);
      const existingFixtureKeys = new Set<string>();
      for (const sys of systems) {
        for (const row of sys.fixtureRows) {
          // A row is either inventory-backed (selectedIndex points at
          // a Fixtures library entry) or custom (the `custom` field
          // carries the raw item with its name). Custom rows always
          // win when present because that's how `makeCustomRow` builds
          // analyser-imported fixtures that didn't match the library.
          const name = row.custom
            ? row.custom.name
            : (inventory.Fixtures[row.selectedIndex]?.name ?? "");
          const key = fixtureNameKey(name);
          if (key) existingFixtureKeys.add(`${sys.id}|${key}`);
        }
      }
      // Also dedup against any standalone show-fixtures that aren't
      // assigned to a system yet — same name + same systemId="" cell.
      for (const sf of showFixtures) {
        const key = fixtureNameKey(sf.name);
        if (key) existingFixtureKeys.add(`${sf.systemId}|${key}`);
      }

      extracted.lighting.forEach((f, i) => {
        if (!selection.lightingIndexes.has(i)) return;
        let systemId = "";
        const trussRaw = (f.trussName ?? "").trim();
        if (trussRaw) {
          const k = trussKey(trussRaw);
          const existingId = systemIdByTrussName.get(k);
          if (existingId) {
            systemId = existingId;
          } else {
            // Auto-create a system for this fixture's truss so all
            // fixtures sharing the same trussName collapse onto it.
            let name = trussRaw;
            while (usedNames.has(name)) name += "'";
            usedNames.add(name);
            const sys = makeSystem(name);
            newSystems.push(sys);
            // Account for this auto-created system in the summary so
            // the importer's "Added N items" banner matches reality —
            // otherwise lighting that conjures a fresh truss is
            // silently invisible to the user.
            summary.systems.added += 1;
            indexTruss(k, sys.id);
            indexTruss(trussKey(name), sys.id);
            systemId = sys.id;
          }
        }

        const qty = Math.max(1, Math.round(f.qty || 1));
        const fixtureName = f.name || "Fixture";
        const weight = f.weightKg != null ? Math.max(0, f.weightKg) : 0;
        const watts = f.watts != null ? Math.max(0, Math.round(f.watts)) : 0;

        // Cross-PDF dedup: if this same fixture name is already on
        // the same target system (or already in the unassigned
        // standalone list when systemId === ""), skip. We do NOT sum
        // quantities — the producer can edit quantities by hand on
        // the source row, but adding an N-th identical row would be
        // surprising. Track the (systemId, name) we just placed so a
        // single PDF that lists the same fixture twice also dedupes.
        const dedupKey = `${systemId}|${fixtureNameKey(fixtureName)}`;
        if (existingFixtureKeys.has(dedupKey)) {
          summary.fixtures.skipped += 1;
          return;
        }
        existingFixtureKeys.add(dedupKey);
        summary.fixtures.added += 1;

        if (systemId) {
          // Build a fixtureRow on the target rigging system.
          const matchedIdx = matchInventoryFixture(fixtureName);
          const row: Row =
            matchedIdx >= 0
              ? {
                  id: newId("row"),
                  category: "Fixtures",
                  selectedIndex: matchedIdx,
                  qty,
                }
              : {
                  ...makeCustomRow("Fixtures", {
                    name: fixtureName,
                    weight,
                    wattage: watts,
                    area: 0,
                  }),
                  qty,
                };
          // newSystems are local objects we still hold a reference to,
          // so we can push into them directly. Existing systems live
          // in state, so we collect patches and apply them in the
          // single setSystems update below.
          const newSys = newSystems.find((s) => s.id === systemId);
          if (newSys) {
            newSys.fixtureRows.push(row);
          } else {
            const list = fixtureRowPatches.get(systemId) ?? [];
            list.push(row);
            fixtureRowPatches.set(systemId, list);
          }
          // Carry the analyser's notes onto the linkedMeta entry so
          // they survive the showFixtures → fixtureRows routing.
          if (f.notes && f.notes.trim()) {
            noteSeeds[row.id] = f.notes.trim();
          }
        } else {
          // No truss tag → leave it as an unassigned standalone fixture
          // so the user can manually pick a system on the Lighting tab.
          standaloneAdditions.push({
            ...makeShowFixture(),
            name: fixtureName,
            qty,
            weight,
            watts,
            systemId: "",
            notes: f.notes || "",
          });
        }
      });

      if (standaloneAdditions.length > 0) {
        setShowFixtures((all) => [...all, ...standaloneAdditions]);
      }

      // Commit existing-system patches together with the newSystems
      // append in a single setSystems update so React only re-renders
      // once and the wiring stays consistent.
      if (newSystems.length > 0 || fixtureRowPatches.size > 0) {
        setSystems((all) => {
          const patched =
            fixtureRowPatches.size > 0
              ? all.map((s) => {
                  const extra = fixtureRowPatches.get(s.id);
                  return extra
                    ? { ...s, fixtureRows: [...s.fixtureRows, ...extra] }
                    : s;
                })
              : all;
          return [...patched, ...newSystems];
        });
        if (newSystems.length > 0) {
          // Focus the first newly-added one so the user can see the
          // result when they switch to the Rigging Report.
          setActiveSystemId(newSystems[0].id);
        }
      }

      // Seed analyser-supplied notes onto each linked fixture's meta
      // so they're visible on the Lighting tab and don't get lost.
      const noteRowIds = Object.keys(noteSeeds);
      if (noteRowIds.length > 0) {
        setLinkedMeta((all) => {
          const next = { ...all };
          for (const rowId of noteRowIds) {
            const prev = next[rowId] ?? defaultLinkedMeta();
            next[rowId] = { ...prev, notes: noteSeeds[rowId] };
          }
          return next;
        });
      }
    } else if (newSystems.length > 0) {
      // Lighting step skipped, but we still committed new trusses.
      setSystems((all) => [...all, ...newSystems]);
      setActiveSystemId(newSystems[0].id);
    }

    // LED screens
    if (selection.ledIndexes.size > 0) {
      const additions: LedScreen[] = [];
      // Cross-PDF dedup: collapse on case-insensitive screen name.
      // Includes both stand-alone LED screens and any LED rows that
      // ride along on a rigging system (`linkedLedScreens`) — both
      // render on the LED tab so users would see them as duplicates
      // either way. Without seeding from `linkedLedScreens` an
      // import could quietly add a second copy of a screen that's
      // already linked from a system row.
      const ledNameKey = (s: string) =>
        s.trim().toLowerCase().replace(/\s+/g, " ");
      const existingLedNames = new Set<string>();
      for (const s of ledScreens) {
        const k = ledNameKey(s.name);
        if (k) existingLedNames.add(k);
      }
      for (const s of linkedLedScreens) {
        const k = ledNameKey(s.name);
        if (k) existingLedNames.add(k);
      }
      // Resolve the active panel's physical size once so we can convert
      // analyser-supplied screen sizes in metres (e.g. "5 x 3 m") into
      // panel counts. Panels with zero physical size (the synthetic
      // Custom fallback) are skipped to avoid divide-by-zero.
      const defaultPanel = getLedPanel(defaultLedPanelKey, ledPanels);
      const panelWm = defaultPanel.physicalWidth;
      const panelHm = defaultPanel.physicalHeight;
      const metresToPanels = (
        sizeM: number | null,
        panelM: number,
      ): number | undefined => {
        if (sizeM == null || sizeM <= 0 || panelM <= 0) return undefined;
        return Math.max(1, Math.round(sizeM / panelM));
      };
      extracted.ledScreens.forEach((s, i) => {
        if (!selection.ledIndexes.has(i)) return;
        const idx = ledScreens.length + additions.length;
        const screenName = s.name || `Screen ${idx + 1}`;
        const dedupKey = ledNameKey(screenName);
        if (dedupKey && existingLedNames.has(dedupKey)) {
          summary.ledScreens.skipped += 1;
          return;
        }
        existingLedNames.add(dedupKey);
        summary.ledScreens.added += 1;
        // Panel grid wins when the analyser gave one outright; otherwise
        // we fall back to the metric size from the drawing.
        const wide =
          s.panelsWide != null && s.panelsWide > 0
            ? Math.round(s.panelsWide)
            : metresToPanels(s.widthM, panelWm);
        const tall =
          s.panelsTall != null && s.panelsTall > 0
            ? Math.round(s.panelsTall)
            : metresToPanels(s.heightM, panelHm);
        additions.push(
          newLedScreen(defaultLedPanelKey, {
            name: screenName,
            color: LED_SCREEN_COLORS[idx % LED_SCREEN_COLORS.length],
            panelsWide: wide,
            panelsTall: tall,
            notes: s.notes || "",
          }),
        );
      });
      if (additions.length > 0) {
        setLedScreens((all) => [...all, ...additions]);
      }
    }

    // Stages — cross-PDF dedup on case-insensitive stage name.
    if (selection.stageIndexes.size > 0) {
      const additions: Stage[] = [];
      const stageNameKey = (s: string) =>
        s.trim().toLowerCase().replace(/\s+/g, " ");
      const existingStageNames = new Set<string>();
      for (const s of stages) {
        const k = stageNameKey(s.name);
        if (k) existingStageNames.add(k);
      }
      extracted.stages.forEach((st, i) => {
        if (!selection.stageIndexes.has(i)) return;
        const stageName =
          st.name || `Stage ${stages.length + additions.length + 1}`;
        const dedupKey = stageNameKey(stageName);
        if (dedupKey && existingStageNames.has(dedupKey)) {
          summary.stages.skipped += 1;
          return;
        }
        existingStageNames.add(dedupKey);
        summary.stages.added += 1;
        const base = makeDefaultStage(stageName);
        additions.push({
          ...base,
          width: st.widthM > 0 ? st.widthM : base.width,
          depth: st.depthM > 0 ? st.depthM : base.depth,
          notes: st.notes || "",
        });
      });
      if (additions.length > 0) {
        setStages((all) => [...all, ...additions]);
      }
    }

    // Sound — cross-PDF dedup on case-insensitive item name. We use
    // name alone (rather than name+category) because the analyser
    // rarely emits the same name for two different physical items;
    // overly-strict matching would let "PA Mains" and "Subs" of the
    // same brand resurface twice across PDFs even when they are the
    // same hardware.
    if (selection.soundIndexes.size > 0) {
      const additions: SoundItem[] = [];
      const soundNameKey = (s: string) =>
        s.trim().toLowerCase().replace(/\s+/g, " ");
      const existingSoundNames = new Set<string>();
      for (const s of soundItems) {
        const k = soundNameKey(s.name);
        if (k) existingSoundNames.add(k);
      }
      extracted.sound.forEach((s, i) => {
        if (!selection.soundIndexes.has(i)) return;
        const itemName = s.name || "Sound";
        const dedupKey = soundNameKey(itemName);
        if (dedupKey && existingSoundNames.has(dedupKey)) {
          summary.sound.skipped += 1;
          return;
        }
        existingSoundNames.add(dedupKey);
        summary.sound.added += 1;
        const base = makeSoundItem();
        additions.push({
          ...base,
          name: itemName,
          qty: Math.max(1, Math.round(s.qty || 1)),
          weightPerUnit: s.weightKg != null ? Math.max(0, s.weightKg) : 0,
          powerPerUnit: s.watts != null ? Math.max(0, Math.round(s.watts)) : 0,
          notes: s.notes || "",
        });
      });
      if (additions.length > 0) {
        setSoundItems((all) => [...all, ...additions]);
      }
    }

    return summary;
  };

  // ---- Crew Report ----
  const addCrew = () => {
    setCrew((all) => [...all, makeCrewMember()]);
  };
  const updateCrew = (id: string, patch: Partial<CrewMember>) => {
    setCrew((all) => all.map((m) => (m.id === id ? { ...m, ...patch } : m)));
  };
  const removeCrew = (id: string) => {
    setCrew((all) => all.filter((m) => m.id !== id));
  };
  const duplicateCrew = (id: string) => {
    setCrew((all) => {
      const i = all.findIndex((m) => m.id === id);
      if (i < 0) return all;
      const src = all[i];
      const copy: CrewMember = {
        ...src,
        id:
          typeof crypto !== "undefined" && "randomUUID" in crypto
            ? `crew-${crypto.randomUUID()}`
            : `crew-${Date.now()}`,
        name: src.name ? `${src.name} (copy)` : "",
      };
      const next = [...all];
      next.splice(i + 1, 0, copy);
      return next;
    });
  };

  // ---- Sound Report ----
  const addSoundItem = () => {
    setSoundItems((all) => [...all, makeSoundItem()]);
  };

  /** Map an EHS library sub-category onto the in-app SoundCategory bucket
   *  used by the Sound Report. Anything we can't classify falls through to
   *  "Other" so the row is still visible. */
  const mapLibrarySoundCategory = (it: LibraryItem) => {
    const s = it.subCategory.toUpperCase();
    if (s.includes("PA")) return "PA Mains" as const;
    if (s.includes("SUB")) return "Subs" as const;
    if (s.includes("MONITOR")) return "Monitors" as const;
    if (s.includes("WIRELESS")) return "Mic Wireless" as const;
    if (s.includes("INPUT")) return "Mic Wired" as const;
    if (s.includes("CONSOLE")) return "Console" as const;
    if (s.includes("DI")) return "DI" as const;
    if (s.includes("STAND")) return "Stand" as const;
    if (s.includes("CABLE")) return "Cable" as const;
    if (s.includes("AMPLIFIER") || s.includes("SPEAKER"))
      return "PA Mains" as const;
    return "Other" as const;
  };

  /** Insert a library pick into whichever tab the picker was opened from. */
  const handleLibraryPick = (it: LibraryItem) => {
    const target = pickerTarget;
    if (!target) return;
    if (target.kind === "sound") {
      const base = makeSoundItem();
      setSoundItems((all) => [
        ...all,
        {
          ...base,
          name: it.name,
          category: mapLibrarySoundCategory(it),
          weight: it.weight,
          watts: it.watts,
          notes: it.notes ?? "",
        },
      ]);
    } else if (target.kind === "lighting") {
      const base = makeShowFixture();
      setShowFixtures((all) => [
        ...all,
        {
          ...base,
          name: it.name,
          weight: it.weight,
          watts: it.watts,
          notes: it.notes ?? "",
        },
      ]);
    } else if (target.kind === "power") {
      const circuitId = target.circuitId;
      const phase = target.phase;
      setPower((p) => {
        // Defensive: if the targeted circuit was deleted before the user
        // could pick, just append the item to the first remaining circuit
        // (or no-op if the plan is empty).
        if (!p.circuits.some((c) => c.id === circuitId)) {
          if (p.circuits.length === 0) return p;
          const fallback = p.circuits[0];
          return {
            ...p,
            circuits: p.circuits.map((c) =>
              c.id === fallback.id
                ? {
                    ...c,
                    items: [
                      ...c.items,
                      {
                        ...makePowerItem(phase),
                        name: it.name,
                        wattsPerUnit: it.watts,
                        notes: it.notes ?? "",
                      },
                    ],
                  }
                : c,
            ),
          };
        }
        return {
          ...p,
          circuits: p.circuits.map((c) =>
            c.id === circuitId
              ? {
                  ...c,
                  items: [
                    ...c.items,
                    {
                      ...makePowerItem(phase),
                      name: it.name,
                      wattsPerUnit: it.watts,
                      notes: it.notes ?? "",
                    },
                  ],
                }
              : c,
          ),
        };
      });
    }
    closePicker();
  };
  const updateSoundItem = (id: string, patch: Partial<SoundItem>) => {
    setSoundItems((all) =>
      all.map((it) => (it.id === id ? { ...it, ...patch } : it)),
    );
  };
  const removeSoundItem = (id: string) => {
    setSoundItems((all) => all.filter((it) => it.id !== id));
  };
  const duplicateSoundItem = (id: string) => {
    setSoundItems((all) => {
      const i = all.findIndex((it) => it.id === id);
      if (i < 0) return all;
      const src = all[i];
      const copy: SoundItem = {
        ...src,
        id:
          typeof crypto !== "undefined" && "randomUUID" in crypto
            ? `snd-${crypto.randomUUID()}`
            : `snd-${Date.now()}`,
        name: src.name ? `${src.name} (copy)` : "",
      };
      const next = [...all];
      next.splice(i + 1, 0, copy);
      return next;
    });
  };

  // ---- Lighting → Power Plan ----
  const addPowerCircuit = () => {
    setPower((p) => ({
      ...p,
      circuits: [...p.circuits, makePowerCircuit(p.circuits.length + 1)],
    }));
  };
  const updatePowerCircuit = (
    id: string,
    patch: Partial<Omit<PowerCircuit, "items">>,
  ) => {
    setPower((p) => ({
      ...p,
      circuits: p.circuits.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    }));
  };
  const removePowerCircuit = (id: string) => {
    setPower((p) => ({
      ...p,
      circuits: p.circuits.filter((c) => c.id !== id),
    }));
  };
  const addPowerItem = (circuitId: string, phase: PowerPhase = "L1") => {
    setPower((p) => ({
      ...p,
      circuits: p.circuits.map((c) =>
        c.id === circuitId
          ? { ...c, items: [...c.items, makePowerItem(phase)] }
          : c,
      ),
    }));
  };
  const updatePowerItem = (
    circuitId: string,
    itemId: string,
    patch: Partial<PowerItem>,
  ) => {
    setPower((p) => ({
      ...p,
      circuits: p.circuits.map((c) =>
        c.id === circuitId
          ? {
              ...c,
              items: c.items.map((it) =>
                it.id === itemId ? { ...it, ...patch } : it,
              ),
            }
          : c,
      ),
    }));
  };
  const removePowerItem = (circuitId: string, itemId: string) => {
    setPower((p) => ({
      ...p,
      circuits: p.circuits.map((c) =>
        c.id === circuitId
          ? { ...c, items: c.items.filter((it) => it.id !== itemId) }
          : c,
      ),
    }));
  };
  const duplicatePowerItem = (circuitId: string, itemId: string) => {
    setPower((p) => ({
      ...p,
      circuits: p.circuits.map((c) => {
        if (c.id !== circuitId) return c;
        const i = c.items.findIndex((it) => it.id === itemId);
        if (i < 0) return c;
        const src = c.items[i];
        const copy: PowerItem = {
          ...src,
          id:
            typeof crypto !== "undefined" && "randomUUID" in crypto
              ? `pwi-${crypto.randomUUID()}`
              : `pwi-${Date.now()}`,
          name: src.name ? `${src.name} (copy)` : "",
        };
        const next = [...c.items];
        next.splice(i + 1, 0, copy);
        return { ...c, items: next };
      }),
    }));
  };

  // ---- Stage Report ----
  const addStage = () => {
    setStages((all) => [
      ...all,
      makeDefaultStage(`Stage ${all.length + 1}`),
    ]);
  };
  const updateStage = (id: string, patch: Partial<Stage>) => {
    setStages((all) =>
      all.map((s) => (s.id === id ? { ...s, ...patch } : s)),
    );
  };
  const removeStage = (id: string) => {
    setStages((all) => all.filter((s) => s.id !== id));
  };
  const duplicateStage = (id: string) => {
    setStages((all) => {
      const i = all.findIndex((s) => s.id === id);
      if (i < 0) return all;
      const src = all[i];
      const copy: Stage = {
        ...src,
        id:
          typeof crypto !== "undefined" && "randomUUID" in crypto
            ? crypto.randomUUID()
            : `stage-${Date.now()}`,
        name: `${src.name} (copy)`,
        rails: { ...src.rails },
        // Deep-copy so the duplicate's manual placements + custom rails
        // can be edited without mutating the original stage.
        manualPlacements: src.manualPlacements.map((p) => ({ ...p })),
        customRails: src.customRails.map((c) => ({
          ...c,
          id:
            typeof crypto !== "undefined" && "randomUUID" in crypto
              ? crypto.randomUUID()
              : `${c.id}-copy-${Math.random().toString(36).slice(2, 8)}`,
        })),
      };
      const next = [...all];
      next.splice(i + 1, 0, copy);
      return next;
    });
  };

  /** Open a printable Stage Build Sheet for a single stage. Loads the
   *  EHS logo so the printout is fully branded; falls back to a logo-
   *  less header if the asset can't be fetched. The popup window is
   *  opened SYNCHRONOUSLY (before any await) so browsers don't classify
   *  it as a programmatic pop-up and block it. */
  const exportStage = async (id: string) => {
    const stage = stages.find((s) => s.id === id);
    if (!stage) return;
    // Open the popup immediately, in the user-gesture click context.
    const targetWin = window.open("", "_blank");
    if (targetWin) {
      // Show a brief placeholder while the logo loads.
      targetWin.document.write(
        `<!doctype html><meta charset="utf-8"><title>Generating Stage Build Sheet…</title><body style="font:14px system-ui;padding:24px;color:#64748b">Generating Stage Build Sheet…</body>`,
      );
    }
    const calc = computeStage(stage);
    let logoDataUrl: string | null = null;
    try {
      logoDataUrl = await getLogoDataUrl(ehsLogo);
    } catch {
      logoDataUrl = null;
    }
    exportStageReport({
      stage,
      calc,
      project: {
        venue,
        date: reportDate,
        endDate: reportEndDate || undefined,
        preparedBy: engineer,
      },
      logoDataUrl,
      targetWin,
    });
  };

  const addShowFixture = () =>
    setShowFixtures((all) => [...all, makeShowFixture()]);

  const updateShowFixture = (id: string, patch: Partial<ShowFixture>) => {
    // Linked rows: route DMX/position overlay fields into linkedMeta.
    // Base fields (name/qty/weight/watts/systemId) ignored — must be
    // edited on the rigging report.
    if (id.startsWith("linked-")) {
      const sourceRowId = id.slice("linked-".length);
      setLinkedMeta((all) => {
        const prev = all[sourceRowId] ?? defaultLinkedMeta();
        const next: LinkedMeta = {
          ...prev,
          ...(patch.dmxChannels !== undefined && {
            dmxChannels: patch.dmxChannels,
          }),
          ...(patch.dmxModeIndex !== undefined && {
            dmxModeIndex: patch.dmxModeIndex,
          }),
          ...(patch.beamAngle !== undefined && { beamAngle: patch.beamAngle }),
          ...(patch.position !== undefined && { position: patch.position }),
          ...(patch.circuit !== undefined && { circuit: patch.circuit }),
          ...(patch.universe !== undefined && { universe: patch.universe }),
          ...(patch.startAddress !== undefined && {
            startAddress: patch.startAddress,
          }),
          ...(patch.notes !== undefined && { notes: patch.notes }),
        };
        return { ...all, [sourceRowId]: next };
      });
      return;
    }
    setShowFixtures((all) =>
      all.map((f) => (f.id === id ? { ...f, ...patch } : f)),
    );
  };

  const removeShowFixture = (id: string) => {
    if (id.startsWith("linked-")) return; // can't remove linked rows here
    setShowFixtures((all) => all.filter((f) => f.id !== id));
  };

  const duplicateShowFixture = (id: string) => {
    // Duplicating a linked row creates a standalone editable copy.
    // Strip mode metadata so the standalone copy gets the plain numeric
    // DMX input (modes are inventory-driven and not meaningful once
    // detached from the rigging row); preserve the resolved channel count
    // as the starting numeric value.
    const source = allLightingFixtures.find((f) => f.id === id);
    if (!source) return;
    const copy: ShowFixture = {
      ...source,
      id: newId("fx"),
      linked: false,
      sourceRowId: undefined,
      dmxModeIndex: undefined,
      availableDmxModes: undefined,
    };
    setShowFixtures((all) => [...all, copy]);
  };

  const lightingTotals = useMemo(() => {
    let qty = 0,
      weight = 0,
      watts = 0,
      channels = 0;
    for (const f of allLightingFixtures) {
      qty += f.qty;
      weight += f.weight * f.qty;
      watts += f.watts * f.qty;
      channels += f.dmxChannels * f.qty;
    }
    const universesUsed = new Set(
      allLightingFixtures
        .filter((f) => f.dmxChannels > 0)
        .map((f) => f.universe),
    ).size;
    return { qty, weight, watts, channels, universesUsed };
  }, [allLightingFixtures]);

  const submitCustom = () => {
    if (!modalTarget) return;
    const item: InventoryItem = {
      name: `${custName || "Custom"} (${parseFloat(custWeight) || 0}kg)`,
      weight: parseFloat(custWeight) || 0,
      wattage: parseFloat(custWatt) || 0,
      area: parseFloat(custArea) || 0,
    };
    const key =
      modalTarget === "Fixtures"
        ? "fixtureRows"
        : modalTarget === "LED Screen"
          ? "ledRows"
          : "riggingRows";
    updateRowsKey(key, (rows) => [
      ...rows,
      makeCustomRow(modalTarget, item),
    ]);
    closeModal();
  };

  const downloadCsv = () => {
    const esc = (v: string | number) => {
      const s = String(v ?? "");
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const rows: string[] = [];
    rows.push(
      [
        "Project Venue",
        "Project Date",
        "Engineer",
        "System",
        "Section",
        "Item",
        "Qty",
        "Unit Weight (kg)",
        "Total Weight (kg)",
        "Unit Power (W)",
        "Total Power (W)",
        "Unit Area (m^2)",
        "Total Area (m^2)",
        "System Points",
        "System Dynamic Factor",
        "Hoist",
        "Hoist SWL (kg)",
      ]
        .map(esc)
        .join(","),
    );

    for (const sys of systems) {
      const hoist = getHoist(sys.hoistIndex);
      const lines: { row: Row; section: string }[] = [
        ...sys.riggingRows.map((r) => ({ row: r, section: "Motors & Support" })),
        ...sys.fixtureRows.map((r) => ({ row: r, section: "Lighting Fixtures" })),
        ...sys.ledRows.map((r) => ({ row: r, section: "LED & Other" })),
      ];

      // Hoist row(s) — record the hoist contribution itself
      rows.push(
        [
          venue,
          reportDate,
          engineer,
          sys.name,
          "Motors & Support",
          hoist.label,
          sys.pointCount,
          hoist.weight,
          (hoist.weight * sys.pointCount).toFixed(2),
          hoist.watt,
          hoist.watt * sys.pointCount,
          0,
          0,
          sys.pointCount,
          sys.dynamicFactor,
          hoist.label,
          hoist.swl,
        ]
          .map(esc)
          .join(","),
      );

      for (const { row, section } of lines) {
        const it = getRowItem(row);
        if (!it) continue;
        rows.push(
          [
            venue,
            reportDate,
            engineer,
            sys.name,
            section,
            it.name,
            row.qty,
            it.weight.toFixed(2),
            (it.weight * row.qty).toFixed(2),
            it.wattage,
            it.wattage * row.qty,
            it.area,
            (it.area * row.qty).toFixed(2),
            sys.pointCount,
            sys.dynamicFactor,
            hoist.label,
            hoist.swl,
          ]
            .map(esc)
            .join(","),
        );
      }
    }

    // Per-system totals + per-point loads as a separate block
    rows.push("");
    rows.push(
      [
        "System",
        "Hoist",
        "Points",
        "Dynamic Factor",
        "Static Total (kg)",
        "Dynamic Total (kg)",
        "Peak Point (kg)",
        "SWL (kg)",
        "Headroom (kg)",
        "Status",
      ]
        .map(esc)
        .join(","),
    );
    for (const { system, metrics } of allMetrics) {
      // No hoist selected → no SWL constraint, so neither "OVERLOAD"
      // nor the 85 %-headroom warning applies.
      const hasHoist = metrics.swl > 0;
      const over = hasHoist && metrics.peak > metrics.swl;
      const status = !hasHoist
        ? "No motor"
        : over
          ? "OVERLOAD"
          : metrics.peak / metrics.swl > 0.85
            ? "Caution"
            : "OK";
      rows.push(
        [
          system.name,
          getHoist(system.hoistIndex).label,
          system.pointCount,
          system.dynamicFactor,
          metrics.static.toFixed(2),
          metrics.dynamic.toFixed(2),
          metrics.peak.toFixed(2),
          metrics.swl,
          metrics.headroom.toFixed(2),
          status,
        ]
          .map(esc)
          .join(","),
      );
    }

    rows.push("");
    rows.push(
      ["System", "Point", "Distribution %", "Static (kg)", "Dynamic (kg)", "SWL Util %", "Status"]
        .map(esc)
        .join(","),
    );
    for (const { system, metrics } of allMetrics) {
      const hasHoist = metrics.swl > 0;
      metrics.factors.forEach((f, i) => {
        const dLoad = metrics.dynamicPointLoads[i];
        const sLoad = metrics.staticPointLoads[i];
        const util = hasHoist ? (dLoad / metrics.swl) * 100 : 0;
        const over = hasHoist && dLoad > metrics.swl;
        const status = !hasHoist
          ? "No motor"
          : over
            ? "OVERLOAD"
            : util > 85
              ? "Caution"
              : "OK";
        rows.push(
          [
            system.name,
            `P${i + 1}`,
            (f * 100).toFixed(1),
            sLoad.toFixed(2),
            dLoad.toFixed(2),
            util.toFixed(1),
            status,
          ]
            .map(esc)
            .join(","),
        );
      });
    }

    const csv = "\uFEFF" + rows.join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const safeVenue = (venue || "rigging-report")
      .replace(/[^a-z0-9_-]+/gi, "_")
      .replace(/^_+|_+$/g, "")
      .slice(0, 40);
    a.href = url;
    a.download = `${safeVenue || "rigging-report"}-${reportDate}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const resetAll = () => {
    if (
      !confirm(
        "Reset the entire report? Every tab — systems, lighting fixtures, LED screens, stages, crew, sound, power plan, rigg plan (including the venue), and the project info — will be cleared.",
      )
    )
      return;
    // Truly empty starting system: no truss row, no motor — so the
    // Rigging Report comes up blank instead of carrying over the
    // pre-seeded "4× FD34" row + first hoist.
    const fresh = makeEmptySystem("LX1");
    setVenue("");
    setReportDate(new Date().toISOString().slice(0, 10));
    setReportEndDate("");
    setExtraSchedule({});
    setEngineer("");
    setSystems([fresh]);
    setActiveSystemId(fresh.id);
    setShowFixtures([]);
    setLinkedMeta({});
    setLedScreens([]);
    setLedLinkedMeta({});
    setLedSettings(DEFAULT_LED_SETTINGS);
    setStages([]);
    setCrew([]);
    setSoundItems([]);
    setPower(defaultPowerPlan());
    // DEFAULT_RIGG_PLAN now starts with `venue: null` and an empty
    // trussById, so this returns the Rigg Plan tab to a truly blank
    // "no venue, no trusses" state rather than the legacy 20×12 m
    // default venue.
    setRiggPlan({ ...DEFAULT_RIGG_PLAN, trussById: {} });
    setFloorPlanLibrary(emptyFloorPlanLibrary());
    setMainView("rigging");
    // Also wipe any in-flight modal/picker/form state so a Reset
    // mid-session doesn't leave a half-filled "Add custom item"
    // dialog or library picker open over the now-empty report.
    setPickerTarget(null);
    setModalTarget(null);
    setCustName("");
    setCustWeight("");
    setCustWatt("");
    setCustArea("");
    setShareOpen(false);
  };

  const metricsByActive = useMemo(() => computeMetrics(activeSystem), [activeSystem]);

  const allMetrics = useMemo(
    () => systems.map((s) => ({ system: s, metrics: computeMetrics(s) })),
    [systems],
  );

  /** Per-system summary the Rigg Plan tab needs — id, name, hoist points,
   *  static/peak load and SWL — derived from the same metrics that drive
   *  the Rigging Report so the floor plan can never disagree with it. */
  const riggPlanSystems = useMemo<RiggPlanSystemInfo[]>(
    () =>
      allMetrics.map(({ system, metrics }) => ({
        id: system.id,
        name: system.name,
        pointCount: system.pointCount,
        staticKg: metrics.static,
        peakKg: metrics.peak,
        swlKg: metrics.swl,
      })),
    [allMetrics],
  );

  const projectTotals = useMemo(() => {
    let totalStatic = 0,
      totalDynamic = 0,
      totalPower = 0,
      totalMotorPower = 0,
      totalPoints = 0,
      totalArea = 0,
      overloadedPoints = 0;
    for (const { metrics } of allMetrics) {
      totalStatic += metrics.static;
      totalDynamic += metrics.dynamic;
      totalPower += metrics.power;
      totalMotorPower += metrics.motorPower;
      totalPoints += metrics.factors.length;
      totalArea += metrics.area;
      // A "no motor" system has no SWL, so by definition no overload.
      if (metrics.swl > 0) {
        overloadedPoints += metrics.dynamicPointLoads.filter(
          (d) => d > metrics.swl,
        ).length;
      }
    }
    return {
      totalStatic,
      totalDynamic,
      totalPower,
      totalMotorPower,
      totalPoints,
      totalArea,
      overloadedPoints,
    };
  }, [allMetrics]);

  const renderItemRow = (
    row: Row,
    listKey: "riggingRows" | "fixtureRows" | "ledRows",
  ) => {
    const items: InventoryItem[] = row.custom
      ? [row.custom]
      : inventory[row.category as Category];
    const item = getRowItem(row);
    const subtotal = item ? item.weight * row.qty : 0;

    return (
      <div className="item-row" key={row.id}>
        <select
          value={row.custom ? 0 : row.selectedIndex}
          onChange={(e) =>
            updateRowsKey(listKey, (rows) =>
              rows.map((r) =>
                r.id === row.id
                  ? { ...r, selectedIndex: Number(e.target.value) }
                  : r,
              ),
            )
          }
          disabled={!!row.custom}
        >
          {items.map((it, i) => (
            <option key={i} value={i}>
              {it.name}
            </option>
          ))}
        </select>
        <NumberField
          min={0}
          value={row.qty}
          transform={(n) => Math.max(0, n || 0)}
          emptyValue={0}
          onCommit={(qty) =>
            updateRowsKey(listKey, (rows) =>
              rows.map((r) =>
                r.id === row.id
                  ? { ...r, qty }
                  : r,
              ),
            )
          }
        />
        <div className="row-subtotal" title="Row total weight">
          {subtotal.toFixed(1)}
          <span>kg</span>
        </div>
        <button
          className="btn btn-del"
          onClick={() =>
            updateRowsKey(listKey, (rows) => rows.filter((r) => r.id !== row.id))
          }
          aria-label="Remove"
        >
          ×
        </button>
      </div>
    );
  };

  const sectionTotal = (rows: Row[]) =>
    rows.reduce((sum, r) => {
      const it = getRowItem(r);
      return sum + (it ? it.weight * r.qty : 0);
    }, 0);

  const peakColor =
    metricsByActive.swl > 0 && metricsByActive.peak > metricsByActive.swl
      ? "var(--danger)"
      : "var(--secondary)";
  const peakUtil =
    metricsByActive.swl > 0 ? metricsByActive.peak / metricsByActive.swl : 0;
  const utilPct = Math.min(100, peakUtil * 100);
  const utilBarColor =
    peakUtil > 1
      ? "var(--danger)"
      : peakUtil > 0.85
        ? "var(--warning)"
        : "var(--primary)";

  return (
    <div className="container">
      <div className="header">
        <div className="header-left">
          <img src={ehsLogo} alt="EHS Logo" className="header-logo-img" />
          <div className="header-title">
            <h1>
              Production <span className="header-title-accent">Tool</span>
            </h1>
          </div>
        </div>
        <div className="header-actions">
          {/* Account cluster — pinned to the top-right of the header.
              Holds the theme picker, Portal link, and signed-in user / Sign out. */}
          <div className="header-account">
            <ThemeSegmentedControl
              pref={themePref}
              onChange={setThemePref}
            />
            <Link
              href="/portal"
              title="Go to your Freelance Portal"
              className="btn btn-reset"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                textDecoration: "none",
              }}
            >
              <span aria-hidden>◉</span>
              <span>Portal</span>
            </Link>
            <SignOutButton />
          </div>
          {/* Document actions — below the account cluster. */}
          <div className="header-doc-actions">
            <span className="autosave-pill" title="Saved locally in your browser">
              ● Saved {savedAt}
            </span>
            <button className="btn btn-reset" onClick={resetAll} title="Clear report">
              Reset
            </button>
            <button className="btn btn-csv" onClick={downloadCsv} title="Download CSV">
              CSV
            </button>
            <button
              className="btn btn-export"
              onClick={() => {
                if (mainView !== "rigging") {
                  setMainView("rigging");
                  requestAnimationFrame(() =>
                    requestAnimationFrame(() => window.print()),
                  );
                } else {
                  window.print();
                }
              }}
            >
              Export Report
            </button>
            <button
              className="btn btn-export"
              onClick={() => setShareOpen(true)}
              title="Generate per-crew brief links to share with freelancers"
            >
              Share with Crew
            </button>
          </div>
        </div>
      </div>

      {/* PROJECT META */}
      <div className="system-identity project-card">
        <div className="project-meta">
          <div className="meta-field">
            <label>Venue / Project</label>
            <input
              type="text"
              value={venue}
              onChange={(e) => setVenue(e.target.value)}
              placeholder="e.g. Sentrum Scene"
            />
          </div>
          <div className="meta-field">
            <label>Schedule</label>
            <ScheduleField
              reportDate={reportDate}
              reportEndDate={reportEndDate}
              extraSchedule={extraSchedule}
              onChangeReportDate={setReportDate}
              onChangeReportEndDate={setReportEndDate}
              onChangeExtraSchedule={setExtraSchedule}
            />
          </div>
          <div className="meta-field">
            <label>Project manager</label>
            <input
              type="text"
              value={engineer}
              onChange={(e) => setEngineer(e.target.value)}
              placeholder="Name"
            />
          </div>
        </div>
      </div>

      {/* TOP-LEVEL VIEW SWITCHER */}
      <div className="view-switcher no-print">
        <button
          className={`view-tab ${mainView === "rigging" ? "is-active" : ""}`}
          onClick={() => setMainView("rigging")}
        >
          Rigging Report
        </button>
        <button
          className={`view-tab ${mainView === "lighting" ? "is-active" : ""}`}
          onClick={() => setMainView("lighting")}
        >
          Lighting Report
          {allLightingFixtures.length > 0 && (
            <span className="view-tab-badge">
              {allLightingFixtures.length}
            </span>
          )}
        </button>
        <button
          className={`view-tab ${mainView === "led" ? "is-active" : ""}`}
          onClick={() => setMainView("led")}
        >
          LED Screen Report
        </button>
        <button
          className={`view-tab ${mainView === "stage" ? "is-active" : ""}`}
          onClick={() => setMainView("stage")}
        >
          Stage Report
          {stages.length > 0 && (
            <span className="view-tab-badge">{stages.length}</span>
          )}
        </button>
        <button
          className={`view-tab ${mainView === "crew" ? "is-active" : ""}`}
          onClick={() => setMainView("crew")}
        >
          Crew Report
          {crew.length > 0 && (
            <span className="view-tab-badge">{crew.length}</span>
          )}
        </button>
        <button
          className={`view-tab ${mainView === "sound" ? "is-active" : ""}`}
          onClick={() => setMainView("sound")}
        >
          Sound Report
          {soundItems.length > 0 && (
            <span className="view-tab-badge">{soundItems.length}</span>
          )}
        </button>
        <button
          className={`view-tab ${mainView === "riggPlan" ? "is-active" : ""}`}
          onClick={() => setMainView("riggPlan")}
        >
          Rigg Plan
          {systems.length > 0 && (
            <span className="view-tab-badge">{systems.length}</span>
          )}
        </button>
      </div>

      {mainView === "rigging" && <>

      {/* PROJECT-WIDE SUMMARY */}
      <div className="dashboard project-summary">
        <div className="dash-item">
          <span>Systems</span>
          <strong>{systems.length}</strong>
          <small>total</small>
        </div>
        <div className="dash-item">
          <span>Hoists</span>
          <strong>{projectTotals.totalPoints}</strong>
          <small>points</small>
        </div>
        <div className="dash-item">
          <span>Project Static</span>
          <strong>{projectTotals.totalStatic.toFixed(1)}</strong>
          <small>kg</small>
        </div>
        <div className="dash-item">
          <span>Project Dynamic</span>
          <strong>{projectTotals.totalDynamic.toFixed(1)}</strong>
          <small>kg</small>
        </div>
        <div className="dash-item">
          <span>Project Power</span>
          <strong>{projectTotals.totalPower.toLocaleString()}</strong>
          <small>W</small>
        </div>
        <div className="dash-item">
          <span>Motor Power</span>
          <strong>{projectTotals.totalMotorPower.toLocaleString()}</strong>
          <small>W</small>
        </div>
        <div className="dash-item">
          <span>Overloads</span>
          <strong
            style={{
              color:
                projectTotals.overloadedPoints > 0
                  ? "var(--danger)"
                  : "var(--success)",
            }}
          >
            {projectTotals.overloadedPoints}
          </strong>
          <small>{projectTotals.overloadedPoints === 1 ? "point" : "points"}</small>
        </div>
      </div>

      {/* SYSTEM MINI CARDS — at-a-glance per-system summary */}
      {systems.length > 1 && (
        <div className="system-mini-grid">
          {allMetrics.map(({ system, metrics }) => {
            const hasHoist = metrics.swl > 0;
            const over = hasHoist && metrics.peak > metrics.swl;
            const util = hasHoist ? metrics.peak / metrics.swl : 0;
            const isActive = system.id === activeSystem.id;
            return (
              <button
                key={system.id}
                className={`system-mini ${isActive ? "is-active" : ""} ${over ? "is-over" : ""}`}
                onClick={() => setActiveSystemId(system.id)}
              >
                <div className="mini-name">{system.name || "Unnamed"}</div>
                <div className="mini-stats">
                  <span>
                    <strong>{metrics.peak.toFixed(0)}</strong>
                    <small>kg peak</small>
                  </span>
                  <span>
                    <strong>{system.pointCount}</strong>
                    <small>pts</small>
                  </span>
                  <span>
                    <strong>{hasHoist ? metrics.swl : "—"}</strong>
                    <small>SWL</small>
                  </span>
                </div>
                <div className="mini-bar">
                  <div
                    className="mini-bar-fill"
                    style={{
                      width: `${Math.min(100, util * 100)}%`,
                      background: over
                        ? "var(--danger)"
                        : util > 0.85
                          ? "var(--warning)"
                          : "var(--primary)",
                    }}
                  />
                </div>
                {over && <span className="mini-over-tag">OVERLOAD</span>}
              </button>
            );
          })}
        </div>
      )}

      {/* SYSTEM TABS */}
      <div className="system-tabs no-print">
        <div className="tabs-list">
          {systems.map((s) => {
            const m = computeMetrics(s);
            const over = m.swl > 0 && m.peak > m.swl;
            const isActive = s.id === activeSystem.id;
            return (
              <div
                key={s.id}
                className={`system-tab ${isActive ? "is-active" : ""} ${over ? "is-over" : ""}`}
                onClick={() => setActiveSystemId(s.id)}
                role="tab"
              >
                <span className="tab-name">{s.name || "Unnamed"}</span>
                {over && <span className="tab-over">⚠</span>}
                <span
                  className="tab-close"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeSystem(s.id);
                  }}
                  aria-label="Remove system"
                  title={
                    systems.length > 1
                      ? "Remove this system"
                      : "Clear this system and start fresh"
                  }
                >
                  ×
                </span>
              </div>
            );
          })}
        </div>
        <div className="tabs-actions">
          <button className="btn btn-tab-action" onClick={duplicateActiveSystem}>
            Duplicate
          </button>
          <button className="btn btn-tab-action btn-tab-add" onClick={addSystem}>
            + New System
          </button>
        </div>
      </div>

      {/* ACTIVE SYSTEM IDENTITY */}
      <div className="system-identity active-system-card">
        <div className="sys-id-main">
          <label>Rigging Reference ID:</label>
          <input
            type="text"
            value={activeSystem.name}
            onChange={(e) => updateActiveSystem({ name: e.target.value })}
            placeholder="e.g. LX1, LX2, VX1"
          />
        </div>
      </div>

      {/* ACTIVE SYSTEM DASHBOARD */}
      <div className="dashboard">
        <div className="dash-item">
          <span>Static Load</span>
          <strong>{metricsByActive.static.toFixed(1)}</strong>
          <small>kg</small>
        </div>
        <div className="dash-item">
          <span>Peak Load</span>
          <strong style={{ color: peakColor }}>
            {metricsByActive.peak.toFixed(1)}
          </strong>
          <small>kg</small>
        </div>
        <div className="dash-item">
          <span>SWL Headroom</span>
          <strong
            style={{
              color:
                metricsByActive.swl > 0 && metricsByActive.headroom < 0
                  ? "var(--danger)"
                  : "var(--text-main)",
            }}
          >
            {metricsByActive.swl <= 0
              ? "—"
              : metricsByActive.headroom >= 0
                ? metricsByActive.headroom.toFixed(0)
                : `−${Math.abs(metricsByActive.headroom).toFixed(0)}`}
          </strong>
          <small>kg</small>
        </div>
        <div className="dash-item">
          <span>Total Area</span>
          <strong>{metricsByActive.area.toFixed(1)}</strong>
          <small>m²</small>
        </div>
        <div className="dash-item">
          <span>Eq. Power</span>
          <strong>{metricsByActive.power.toLocaleString()}</strong>
          <small>W</small>
        </div>
        <div className="dash-item">
          <span>Motor Power</span>
          <strong>{metricsByActive.motorPower.toLocaleString()}</strong>
          <small>W</small>
        </div>
      </div>

      <div className="util-bar-wrap">
        <div className="util-bar-label">
          <span>Peak SWL Utilization — {activeSystem.name}</span>
          <strong style={{ color: utilBarColor }}>
            {(peakUtil * 100).toFixed(1)}%
          </strong>
        </div>
        <div className="util-bar-track">
          <div
            className="util-bar-fill"
            style={{ width: `${utilPct}%`, background: utilBarColor }}
          />
          <div
            className="util-bar-marker"
            style={{ left: "85%" }}
            title="85% caution"
          />
          <div
            className="util-bar-marker util-marker-danger"
            style={{ left: "100%" }}
            title="100% SWL"
          />
        </div>
        <div className="util-bar-legend">
          <span>0 kg</span>
          <span>Caution 85%</span>
          <span>
            SWL {metricsByActive.swl > 0 ? `${metricsByActive.swl} kg` : "—"}
          </span>
        </div>
      </div>

      <div className="main-grid">
        <div className="card">
          <h2>
            1. Motors &amp; Hoists
            <span className="card-total">
              {(
                activeSystem.pointCount *
                getHoist(activeSystem.hoistIndex).weight
              ).toFixed(1)}{" "}
              kg
            </span>
          </h2>
          <div className="motor-config">
            <div className="motor-config-grid">
              <div>
                <label className="field-label">Points</label>
                <select
                  value={activeSystem.pointCount}
                  onChange={(e) =>
                    updateActiveSystem({ pointCount: Number(e.target.value) })
                  }
                >
                  {[2, 3, 4, 5, 6, 7, 8].map((n) => (
                    <option key={n} value={n}>
                      {n} Points
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="field-label">Dynamic Factor</label>
                <select
                  value={activeSystem.dynamicFactor}
                  onChange={(e) =>
                    updateActiveSystem({ dynamicFactor: Number(e.target.value) })
                  }
                >
                  <option value={1.0}>1.0x (Static)</option>
                  <option value={1.25}>1.25x (Standard)</option>
                  <option value={1.5}>1.5x (Heavy)</option>
                  <option value={2.0}>2.0x (Critical)</option>
                </select>
              </div>
            </div>
            <label className="field-label" style={{ marginTop: 10 }}>
              Motor Type
            </label>
            <select
              value={activeSystem.hoistIndex}
              onChange={(e) =>
                updateActiveSystem({ hoistIndex: Number(e.target.value) })
              }
            >
              {/* "None" lets the producer mark a system as dead-hung /
                  pre-rigged from venue infrastructure — the motor row
                  contributes 0 kg / 0 W and the per-point SWL warning
                  stops firing for this system. */}
              <option value={-1}>None</option>
              {hoistModels.map((h, i) => (
                <option key={i} value={i}>
                  {h.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="card">
          <h2>
            2. Truss
            <span className="card-total">
              {sectionTotal(activeSystem.riggingRows).toFixed(1)} kg
            </span>
          </h2>
          <div>
            {activeSystem.riggingRows.map((r) =>
              renderItemRow(r, "riggingRows"),
            )}
          </div>
          {activeSystem.riggingRows.length === 0 && (
            <div className="empty-row">No truss added yet</div>
          )}
          <button
            className="btn btn-add"
            onClick={() =>
              updateRowsKey("riggingRows", (rows) => [
                ...rows,
                makeRow("Truss"),
              ])
            }
          >
            + Add Truss
          </button>
          <button
            className="btn btn-add btn-custom"
            onClick={() => openModal("Truss")}
          >
            + Manual Item
          </button>
        </div>

        <div className="card">
          <h2>
            3. Lighting Fixtures
            <span className="card-total">
              {sectionTotal(activeSystem.fixtureRows).toFixed(1)} kg
            </span>
          </h2>
          <div>
            {activeSystem.fixtureRows.map((r) =>
              renderItemRow(r, "fixtureRows"),
            )}
          </div>
          {activeSystem.fixtureRows.length === 0 && (
            <div className="empty-row">No fixtures added yet</div>
          )}
          <button
            className="btn btn-add"
            onClick={() =>
              updateRowsKey("fixtureRows", (rows) => [
                ...rows,
                makeRow("Fixtures"),
              ])
            }
          >
            + Add Fixture
          </button>
          <button
            className="btn btn-add btn-custom"
            onClick={() => openModal("Fixtures")}
          >
            + Manual Item
          </button>
        </div>

        <div className="card">
          <h2>
            4. LED &amp; Other Equipment
            <span className="card-total">
              {sectionTotal(activeSystem.ledRows).toFixed(1)} kg
            </span>
          </h2>
          <div>
            {activeSystem.ledRows.map((r) => renderItemRow(r, "ledRows"))}
          </div>
          {activeSystem.ledRows.length === 0 && (
            <div className="empty-row">No LED or other equipment added yet</div>
          )}
          <button
            className="btn btn-add"
            onClick={() =>
              updateRowsKey("ledRows", (rows) => [
                ...rows,
                makeRow("LED Screen"),
              ])
            }
          >
            + Add Item
          </button>
          <button
            className="btn btn-add btn-custom"
            onClick={() => openModal("LED Screen")}
          >
            + Manual Item
          </button>
        </div>

        <div className="card full-width">
          <h2>5. Rigging Point Calculations — {activeSystem.name}</h2>
          <div className="analysis-container">
            <div className="points-summary">
              {metricsByActive.factors.map((f, i) => {
                const sLoad = metricsByActive.staticPointLoads[i];
                const dLoad = metricsByActive.dynamicPointLoads[i];
                const pct = Math.round(f * 100);
                const util =
                  metricsByActive.swl > 0 ? dLoad / metricsByActive.swl : 0;
                const isDanger =
                  metricsByActive.swl > 0 && dLoad > metricsByActive.swl;
                const isWarning = !isDanger && util > 0.85;
                return (
                  <div
                    className={`point-box ${isDanger ? "is-danger" : isWarning ? "is-warning" : ""}`}
                    key={i}
                  >
                    {isDanger && (
                      <div className="overload-badge">
                        <span>⚠</span> OVERLOAD
                      </div>
                    )}
                    {isWarning && (
                      <div className="overload-badge warning-badge">
                        <span>⚠</span> CAUTION
                      </div>
                    )}
                    <span className="point-label">
                      POINT 0{i + 1} ({pct}%)
                    </span>
                    <span className="p-val">
                      {dLoad.toFixed(1)}
                      <small>kg</small>
                    </span>
                    <span className="p-dyn">Static: {sLoad.toFixed(0)}kg</span>
                    <div className="point-util-bar">
                      <div
                        className="point-util-fill"
                        style={{
                          width: `${Math.min(100, util * 100)}%`,
                          background: isDanger
                            ? "white"
                            : isWarning
                              ? "var(--warning)"
                              : "var(--primary)",
                        }}
                      />
                    </div>
                    <span className="p-util-text">
                      {(util * 100).toFixed(0)}% of SWL
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="chart-section">
              <div className="chart-legend">
                <span>
                  <i style={{ background: "var(--static-bar)" }} /> Static
                </span>
                <span>
                  <i style={{ background: "var(--secondary)" }} /> Dynamic ({activeSystem.dynamicFactor}x)
                </span>
                <span>
                  <i style={{ background: "var(--danger)" }} /> Over SWL
                </span>
              </div>
              <div className="bar-chart">
                {metricsByActive.factors.map((_, i) => {
                  const sLoad = metricsByActive.staticPointLoads[i];
                  const dLoad = metricsByActive.dynamicPointLoads[i];
                  const denom =
                    Math.max(metricsByActive.peak, metricsByActive.swl) || 1;
                  const sH = (sLoad / denom) * 240;
                  const dH = (dLoad / denom) * 240;
                  // Without an SWL constraint (no motor), the dynamic
                  // bar should use the neutral colour — otherwise any
                  // positive load would falsely paint red.
                  const barColor =
                    metricsByActive.swl > 0 && dLoad > metricsByActive.swl
                      ? "var(--danger)"
                      : "var(--secondary)";
                  return (
                    <div className="bar-group" key={i}>
                      <div className="bars-side-by-side">
                        <div
                          className="bar"
                          style={{
                            height: `${sH}px`,
                            background: "var(--static-bar)",
                          }}
                          data-value={sLoad.toFixed(0)}
                        />
                        <div
                          className="bar"
                          style={{ height: `${dH}px`, background: barColor }}
                          data-value={dLoad.toFixed(0)}
                        />
                      </div>
                    </div>
                  );
                })}
                {/* SWL guideline — only meaningful when a motor is
                    selected; for no-motor systems we hide it instead
                    of drawing a misleading "SWL 0kg" line at the
                    chart floor. */}
                {metricsByActive.swl > 0 && (
                  <div
                    className="swl-line"
                    style={{
                      bottom: `${(metricsByActive.swl / (Math.max(metricsByActive.peak, metricsByActive.swl) || 1)) * 240}px`,
                    }}
                    title={`SWL ${metricsByActive.swl}kg`}
                  >
                    <span>SWL {metricsByActive.swl}kg</span>
                  </div>
                )}
              </div>
              <div className="vis-container">
                {metricsByActive.factors.map((f, i) => (
                  <div className="vis-point" key={i}>
                    <div className="vis-arrow" />
                    <span className="vis-pct">{Math.round(f * 100)}%</span>
                    <span className="vis-label">P{i + 1}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* PRINT PER-SYSTEM PAGES */}
          <div className="print-only print-systems">
            {allMetrics.map(({ system, metrics }) => (
              <div className="print-system-page" key={system.id}>
                <h3 className="print-system-title">
                  {system.name} — {getHoist(system.hoistIndex).label}
                </h3>
                <div className="print-system-stats">
                  <span>
                    Static: <strong>{metrics.static.toFixed(1)} kg</strong>
                  </span>
                  <span>
                    Dynamic ({system.dynamicFactor}x):{" "}
                    <strong>{metrics.dynamic.toFixed(1)} kg</strong>
                  </span>
                  <span>
                    Peak point:{" "}
                    <strong
                      style={{
                        color:
                          metrics.swl > 0 && metrics.peak > metrics.swl
                            ? "var(--danger)"
                            : "inherit",
                      }}
                    >
                      {metrics.peak.toFixed(1)} kg
                    </strong>
                  </span>
                  <span>
                    SWL:{" "}
                    <strong>
                      {metrics.swl > 0 ? `${metrics.swl} kg` : "—"}
                    </strong>
                  </span>
                  <span>
                    Headroom:{" "}
                    <strong
                      style={{
                        color:
                          metrics.swl > 0 && metrics.headroom < 0
                            ? "var(--danger)"
                            : "inherit",
                      }}
                    >
                      {metrics.swl > 0
                        ? `${metrics.headroom.toFixed(0)} kg`
                        : "—"}
                    </strong>
                  </span>
                </div>
                <table className="print-table print-points-table">
                  <thead>
                    <tr>
                      <th>Point</th>
                      <th>%</th>
                      <th>Static (kg)</th>
                      <th>Dynamic (kg)</th>
                      <th>SWL Util</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {metrics.factors.map((f, i) => {
                      const dLoad = metrics.dynamicPointLoads[i];
                      const sLoad = metrics.staticPointLoads[i];
                      const hasHoist = metrics.swl > 0;
                      const util = hasHoist ? dLoad / metrics.swl : 0;
                      const over = hasHoist && dLoad > metrics.swl;
                      const status = !hasHoist
                        ? "—"
                        : over
                          ? "OVERLOAD"
                          : util > 0.85
                            ? "Caution"
                            : "OK";
                      return (
                        <tr key={i} className={over ? "print-over-row" : ""}>
                          <td>P{i + 1}</td>
                          <td>{Math.round(f * 100)}%</td>
                          <td>{sLoad.toFixed(1)}</td>
                          <td>{dLoad.toFixed(1)}</td>
                          <td>{hasHoist ? `${(util * 100).toFixed(0)}%` : "—"}</td>
                          <td>{status}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                <table className="print-table print-manifest-table">
                  <thead>
                    <tr>
                      <th>Section</th>
                      <th>Item</th>
                      <th>Qty</th>
                      <th>Unit Wt</th>
                      <th>Total Wt</th>
                      <th>Power</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      ...system.riggingRows.map((r) => ({
                        row: r,
                        section: "Motors & Support",
                      })),
                      ...system.fixtureRows.map((r) => ({
                        row: r,
                        section: "Lighting Fixtures",
                      })),
                      ...system.ledRows.map((r) => ({
                        row: r,
                        section: "LED & Other",
                      })),
                    ].map(({ row, section }) => {
                      const it = getRowItem(row);
                      if (!it) return null;
                      return (
                        <tr key={row.id}>
                          <td>{section}</td>
                          <td>{it.name}</td>
                          <td>{row.qty}</td>
                          <td>{it.weight.toFixed(2)} kg</td>
                          <td>{(it.weight * row.qty).toFixed(2)} kg</td>
                          <td>{(it.wattage * row.qty).toLocaleString()} W</td>
                        </tr>
                      );
                    })}
                    <tr className="print-table-total">
                      <td colSpan={4}>Payload total</td>
                      <td>{metrics.payload.toFixed(2)} kg</td>
                      <td>{metrics.power.toLocaleString()} W</td>
                    </tr>
                    <tr className="print-table-grand">
                      <td colSpan={4}>
                        {system.hoistIndex < 0
                          ? "Static (no motor)"
                          : `Static (incl. ${system.pointCount} hoists)`}
                      </td>
                      <td>{metrics.static.toFixed(2)} kg</td>
                      <td>{metrics.motorPower.toLocaleString()} W</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ))}

            <div className="print-system-page">
              <h3 className="print-system-title">Project Totals</h3>
              <table className="print-table">
                <thead>
                  <tr>
                    <th>System</th>
                    <th>Hoist</th>
                    <th>Pts</th>
                    <th>Static (kg)</th>
                    <th>Dynamic (kg)</th>
                    <th>Peak (kg)</th>
                    <th>SWL</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {allMetrics.map(({ system, metrics }) => {
                    const hasHoist = metrics.swl > 0;
                    const over = hasHoist && metrics.peak > metrics.swl;
                    const status = !hasHoist
                      ? "No motor"
                      : over
                        ? "OVERLOAD"
                        : "OK";
                    return (
                      <tr key={system.id} className={over ? "print-over-row" : ""}>
                        <td>{system.name}</td>
                        <td>{getHoist(system.hoistIndex).label}</td>
                        <td>{system.pointCount}</td>
                        <td>{metrics.static.toFixed(1)}</td>
                        <td>{metrics.dynamic.toFixed(1)}</td>
                        <td>{metrics.peak.toFixed(1)}</td>
                        <td>{hasHoist ? metrics.swl : "—"}</td>
                        <td>{status}</td>
                      </tr>
                    );
                  })}
                  <tr className="print-table-grand">
                    <td colSpan={2}>Project total</td>
                    <td>{projectTotals.totalPoints}</td>
                    <td>{projectTotals.totalStatic.toFixed(1)}</td>
                    <td>{projectTotals.totalDynamic.toFixed(1)}</td>
                    <td colSpan={3}>
                      {projectTotals.totalMotorPower.toLocaleString()} W motor power
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="footer">
            <div className="footer-company">EHS AS</div>
            <div className="footer-address">
              Kjeller vest 3, 2007 Kjeller, Norway | Tel: 22 38 90 20 |
              www.ehs.no
            </div>
            <div className="footer-disclaimer">
              Calculations based on EXE Rise D8+ Specifications. Motor weights
              include 24m of chain. Specifications (Safety Factor 8:1).
            </div>
          </div>
        </div>
      </div>

      </>}

      {mainView === "stage" && (
        <StageReportView
          stages={stages}
          onAdd={addStage}
          onUpdate={updateStage}
          onRemove={removeStage}
          onDuplicate={duplicateStage}
          onExport={exportStage}
        />
      )}

      {mainView === "crew" && (
        <CrewReportView
          crew={crew}
          onAdd={addCrew}
          onUpdate={updateCrew}
          onRemove={removeCrew}
          onDuplicate={duplicateCrew}
        />
      )}

      {mainView === "sound" && (
        <SoundReportView
          items={soundItems}
          onAdd={addSoundItem}
          onAddFromLibrary={() => setPickerTarget({ kind: "sound" })}
          onUpdate={updateSoundItem}
          onRemove={removeSoundItem}
          onDuplicate={duplicateSoundItem}
        />
      )}

      {mainView === "riggPlan" && (
        <RiggPlanView
          plan={riggPlan}
          systems={riggPlanSystems}
          onUpdateVenue={updateRiggPlanVenue}
          onAddVenue={addRiggPlanVenue}
          onDeleteVenue={deleteRiggPlanVenue}
          onUpdateTruss={updateRiggPlanTruss}
          onDeleteSystem={removeSystem}
          onJumpToRigging={() => setMainView("rigging")}
          onApplyExtractedItems={applyExtractedItems}
          projectName={venue}
          floorPlans={floorPlanLibrary.plans}
          activeFloorPlanId={floorPlanLibrary.activeId}
          onAddFloorPlan={addFloorPlan}
          onRemoveFloorPlan={removeFloorPlan}
          onSelectFloorPlan={selectFloorPlan}
        />
      )}

      {mainView === "led" && (
        <LedScreenReportView
          screens={allLedScreens}
          panels={ledPanels}
          settings={ledSettings}
          totals={ledTotals}
          linkedCount={linkedLedScreens.length}
          standaloneCount={ledScreens.length}
          onAddScreen={addLedScreen}
          onUpdateScreen={updateLedScreen}
          onUpdateCustomPanel={updateLedCustomPanel}
          onRemoveScreen={removeLedScreen}
          onDuplicateScreen={duplicateLedScreen}
          onUpdateSettings={updateLedSettings}
          onExportScreen={exportLedScreen}
          onJumpToRigging={() => setMainView("rigging")}
        />
      )}

      {mainView === "lighting" && (
        <LightingPlanView
          fixtures={allLightingFixtures}
          linkedCount={linkedFixtures.length}
          standaloneCount={showFixtures.length}
          systems={systems}
          totals={lightingTotals}
          onAdd={addShowFixture}
          onUpdate={updateShowFixture}
          onRemove={removeShowFixture}
          onDuplicate={duplicateShowFixture}
          onJumpToRigging={() => setMainView("rigging")}
          onAddFromLibrary={() => setPickerTarget({ kind: "lighting" })}
          onAddPowerItemFromLibrary={(circuitId, phase) =>
            setPickerTarget({ kind: "power", circuitId, phase })
          }
          power={power}
          onAddPowerCircuit={addPowerCircuit}
          onUpdatePowerCircuit={updatePowerCircuit}
          onRemovePowerCircuit={removePowerCircuit}
          onAddPowerItem={addPowerItem}
          onUpdatePowerItem={updatePowerItem}
          onRemovePowerItem={removePowerItem}
          onDuplicatePowerItem={duplicatePowerItem}
        />
      )}

      {shareOpen ? (
        <ShareBriefModal
          state={briefInput}
          onClose={() => setShareOpen(false)}
        />
      ) : null}

      <EquipmentPicker
        open={pickerTarget !== null}
        tab={
          pickerTarget?.kind === "sound"
            ? "sound"
            : pickerTarget?.kind === "lighting"
              ? "lighting"
              : pickerTarget?.kind === "power"
                ? "power"
                : undefined
        }
        onClose={closePicker}
        onPick={handleLibraryPick}
      />

      {modalTarget && (
        <div className="modal-backdrop" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3>Add Custom Item</h3>
            <input
              type="text"
              placeholder="Item Name"
              value={custName}
              onChange={(e) => setCustName(e.target.value)}
            />
            <input
              type="number"
              placeholder="Weight (kg)"
              value={custWeight}
              onChange={(e) => setCustWeight(e.target.value)}
            />
            <input
              type="number"
              placeholder="Power (W)"
              value={custWatt}
              onChange={(e) => setCustWatt(e.target.value)}
            />
            <input
              type="number"
              placeholder="Area per unit (m²)"
              step="0.01"
              value={custArea}
              onChange={(e) => setCustArea(e.target.value)}
            />
            <div className="modal-actions">
              <button className="btn btn-export" onClick={submitCustom}>
                Add
              </button>
              <button className="btn btn-custom" onClick={closeModal}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

type LightingPlanViewProps = {
  fixtures: ShowFixture[];
  linkedCount: number;
  standaloneCount: number;
  systems: System[];
  totals: {
    qty: number;
    weight: number;
    watts: number;
    channels: number;
    universesUsed: number;
  };
  onAdd: () => void;
  onUpdate: (id: string, patch: Partial<ShowFixture>) => void;
  onRemove: (id: string) => void;
  onDuplicate: (id: string) => void;
  onJumpToRigging: () => void;
  onAddFromLibrary: () => void;
  onAddPowerItemFromLibrary: (circuitId: string, phase: PowerPhase) => void;
  power: PowerPlan;
  onAddPowerCircuit: () => void;
  onUpdatePowerCircuit: (
    id: string,
    patch: Partial<Omit<PowerCircuit, "items">>,
  ) => void;
  onRemovePowerCircuit: (id: string) => void;
  onAddPowerItem: (circuitId: string, phase?: PowerPhase) => void;
  onUpdatePowerItem: (
    circuitId: string,
    itemId: string,
    patch: Partial<PowerItem>,
  ) => void;
  onRemovePowerItem: (circuitId: string, itemId: string) => void;
  onDuplicatePowerItem: (circuitId: string, itemId: string) => void;
};

function LightingPlanView({
  fixtures,
  linkedCount,
  standaloneCount,
  systems,
  totals,
  onAdd,
  onUpdate,
  onRemove,
  onDuplicate,
  onJumpToRigging,
  onAddFromLibrary,
  onAddPowerItemFromLibrary,
  power,
  onAddPowerCircuit,
  onUpdatePowerCircuit,
  onRemovePowerCircuit,
  onAddPowerItem,
  onUpdatePowerItem,
  onRemovePowerItem,
  onDuplicatePowerItem,
}: LightingPlanViewProps) {
  const systemNameById = new Map(systems.map((s) => [s.id, s.name]));
  return (
    <>
      <div className="dashboard project-summary">
        <div className="dash-item">
          <span>Fixtures</span>
          <strong>{totals.qty}</strong>
          <small>units</small>
        </div>
        <div className="dash-item">
          <span>Weight</span>
          <strong>{totals.weight.toFixed(1)}</strong>
          <small>kg</small>
        </div>
        <div className="dash-item">
          <span>Power</span>
          <strong>{totals.watts.toLocaleString()}</strong>
          <small>W</small>
        </div>
        <div className="dash-item">
          <span>DMX Channels</span>
          <strong>{totals.channels.toLocaleString()}</strong>
          <small>used</small>
        </div>
        <div className="dash-item">
          <span>Universes</span>
          <strong>{totals.universesUsed}</strong>
          <small>active</small>
        </div>
        <div className="dash-item">
          <span>Lines</span>
          <strong>{fixtures.length}</strong>
          <small>entries</small>
        </div>
      </div>

      <PowerPlanView
        plan={power}
        onAddCircuit={onAddPowerCircuit}
        onUpdateCircuit={onUpdatePowerCircuit}
        onRemoveCircuit={onRemovePowerCircuit}
        onAddItem={onAddPowerItem}
        onAddItemFromLibrary={onAddPowerItemFromLibrary}
        onUpdateItem={onUpdatePowerItem}
        onRemoveItem={onRemovePowerItem}
        onDuplicateItem={onDuplicatePowerItem}
      />

      <div className="card">
        <h2>
          Show Fixture List
          <span className="card-total">
            {fixtures.length} {fixtures.length === 1 ? "line" : "lines"}
            {linkedCount > 0 && (
              <span className="fx-source-tally">
                {" "}
                · {linkedCount} from rigging · {standaloneCount} extra
              </span>
            )}
          </span>
        </h2>
        <div className="lighting-help">
          Fixtures you add to the rigging report appear here automatically.
          Add DMX address, position and circuit on this view; everything else
          stays in sync with rigging.{" "}
          <button
            type="button"
            className="link-btn"
            onClick={onJumpToRigging}
          >
            Open Rigging Report
          </button>
        </div>
        {fixtures.length === 0 ? (
          <div className="lighting-empty">
            No fixtures yet. Add some on the{" "}
            <button
              type="button"
              className="link-btn"
              onClick={onJumpToRigging}
            >
              Rigging Report
            </button>{" "}
            (they will sync here automatically), or click{" "}
            <strong>+ Add Extra Fixture</strong> below for one-off entries.
          </div>
        ) : (
          <div className="fx-table-wrap">
            <table className="fx-table">
              <thead>
                <tr>
                  <th style={{ minWidth: 200 }}>Fixture</th>
                  <th>Qty</th>
                  <th>Weight (kg)</th>
                  <th>Power (W)</th>
                  <th>DMX Ch</th>
                  <th>Truss</th>
                  <th>Pos (m)</th>
                  <th>Circuit</th>
                  <th>Univ.</th>
                  <th>Address</th>
                  <th>End</th>
                  <th>Total Wt</th>
                  <th>Total W</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {fixtures.map((f) => {
                  const totalChans = f.dmxChannels * f.qty;
                  const endAddr =
                    totalChans > 0
                      ? f.startAddress + totalChans - 1
                      : 0;
                  const overflow = endAddr > 512;
                  const totalWt = f.weight * f.qty;
                  const totalW = f.watts * f.qty;
                  const linkedSysName = f.linked
                    ? systemNameById.get(f.systemId) ?? "—"
                    : "";
                  return (
                    <tr
                      key={f.id}
                      className={f.linked ? "fx-row-linked" : undefined}
                    >
                      <td>
                        {f.linked ? (
                          <div className="fx-linked-cell">
                            <span
                              className="fx-link-badge"
                              title={`From rigging system ${linkedSysName}`}
                            >
                              {linkedSysName}
                            </span>
                            <span
                              className="fx-linked-name"
                              title={f.name}
                            >
                              {f.name}
                            </span>
                          </div>
                        ) : (
                          <input
                            type="text"
                            value={f.name}
                            onChange={(e) =>
                              onUpdate(f.id, { name: e.target.value })
                            }
                            placeholder="e.g. Martin MAC Aura PXL"
                            className="fx-input fx-input-name"
                            aria-label="Fixture name"
                          />
                        )}
                      </td>
                      <td>
                        {f.linked ? (
                          <span className="fx-readonly fx-readonly-num">
                            {f.qty}
                          </span>
                        ) : (
                          <NumberField
                            min={1}
                            step={1}
                            value={f.qty}
                            transform={(n) => Math.max(1, Math.floor(n || 1))}
                            emptyValue={1}
                            onCommit={(qty) =>
                              onUpdate(f.id, {
                                qty,
                              })
                            }
                            className="fx-input fx-input-num"
                            aria-label="Quantity"
                          />
                        )}
                      </td>
                      <td>
                        {f.linked ? (
                          <span className="fx-readonly fx-readonly-num">
                            {f.weight.toFixed(1)}
                          </span>
                        ) : (
                          <NumberField
                            step="0.1"
                            min={0}
                            value={f.weight}
                            transform={(n) => Math.max(0, n || 0)}
                            emptyValue={0}
                            onCommit={(weight) =>
                              onUpdate(f.id, {
                                weight,
                              })
                            }
                            className="fx-input fx-input-num"
                            aria-label="Weight per fixture in kilograms"
                          />
                        )}
                      </td>
                      <td>
                        {f.linked ? (
                          <span className="fx-readonly fx-readonly-num">
                            {f.watts}
                          </span>
                        ) : (
                          <NumberField
                            min={0}
                            value={f.watts}
                            transform={(n) => Math.max(0, n || 0)}
                            emptyValue={0}
                            onCommit={(watts) =>
                              onUpdate(f.id, {
                                watts,
                              })
                            }
                            className="fx-input fx-input-num"
                            aria-label="Power per fixture in watts"
                          />
                        )}
                      </td>
                      <td>
                        {f.availableDmxModes &&
                        f.availableDmxModes.length > 0 ? (
                          <div className="fx-mode-cell">
                            <select
                              value={
                                f.dmxModeIndex === null ||
                                f.dmxModeIndex === undefined
                                  ? -1
                                  : f.dmxModeIndex
                              }
                              onChange={(e) => {
                                const v = Number(e.target.value);
                                if (v === -1) {
                                  // Switch to Custom — keep current channel
                                  // count as the starting custom value.
                                  onUpdate(f.id, {
                                    dmxModeIndex: null,
                                    dmxChannels: f.dmxChannels,
                                  });
                                } else {
                                  onUpdate(f.id, { dmxModeIndex: v });
                                }
                              }}
                              className="fx-input fx-input-select fx-mode-select"
                              aria-label="DMX mode"
                            >
                              {f.availableDmxModes.map((m, i) => (
                                <option key={i} value={i}>
                                  {m.name} ({m.channels}ch)
                                </option>
                              ))}
                              <option value={-1}>Custom…</option>
                            </select>
                            {f.dmxModeIndex === null ? (
                              <NumberField
                                min={0}
                                step={1}
                                value={f.dmxChannels}
                                transform={(n) => Math.max(0, Math.floor(n || 0))}
                                emptyValue={0}
                                onCommit={(dmxChannels) =>
                                  onUpdate(f.id, {
                                    dmxChannels,
                                  })
                                }
                                className="fx-input fx-input-num fx-mode-custom"
                                aria-label="DMX channels per fixture (custom)"
                              />
                            ) : (
                              <span
                                className="fx-mode-channels"
                                aria-label="DMX channels per fixture"
                              >
                                {f.dmxChannels}
                              </span>
                            )}
                          </div>
                        ) : (
                          <NumberField
                            min={0}
                            step={1}
                            value={f.dmxChannels}
                            transform={(n) => Math.max(0, Math.floor(n || 0))}
                            emptyValue={0}
                            onCommit={(dmxChannels) =>
                              onUpdate(f.id, {
                                dmxChannels,
                              })
                            }
                            className="fx-input fx-input-num"
                            aria-label="DMX channels per fixture"
                          />
                        )}
                      </td>
                      <td>
                        {f.linked ? (
                          <span className="fx-readonly">{linkedSysName}</span>
                        ) : (
                          <select
                            value={f.systemId}
                            onChange={(e) =>
                              onUpdate(f.id, { systemId: e.target.value })
                            }
                            className="fx-input fx-input-select"
                            aria-label="Truss assignment"
                          >
                            <option value="">—</option>
                            {systems.map((s) => (
                              <option key={s.id} value={s.id}>
                                {s.name}
                              </option>
                            ))}
                          </select>
                        )}
                      </td>
                      <td>
                        <NumberField
                          step="0.1"
                          value={f.position}
                          transform={(n) => n || 0}
                          emptyValue={0}
                          onCommit={(position) =>
                            onUpdate(f.id, { position })
                          }
                          className="fx-input fx-input-num"
                          aria-label="Position on truss in meters"
                        />
                      </td>
                      <td>
                        <input
                          type="text"
                          value={f.circuit}
                          onChange={(e) =>
                            onUpdate(f.id, { circuit: e.target.value })
                          }
                          placeholder="—"
                          className="fx-input fx-input-circuit"
                          aria-label="Power circuit"
                        />
                      </td>
                      <td>
                        <NumberField
                          min={1}
                          step={1}
                          value={f.universe}
                          transform={(n) => Math.max(1, Math.floor(n || 1))}
                          emptyValue={1}
                          onCommit={(universe) =>
                            onUpdate(f.id, { universe })
                          }
                          className="fx-input fx-input-num"
                          aria-label="DMX universe"
                        />
                      </td>
                      <td>
                        <NumberField
                          min={1}
                          max={512}
                          step={1}
                          value={f.startAddress}
                          transform={(n) =>
                            Math.max(1, Math.min(512, Math.floor(n || 1)))
                          }
                          emptyValue={1}
                          onCommit={(startAddress) =>
                            onUpdate(f.id, { startAddress })
                          }
                          className="fx-input fx-input-num"
                          aria-label="DMX start address"
                        />
                      </td>
                      <td
                        className={`fx-end ${overflow ? "fx-end-over" : ""}`}
                        title={
                          overflow
                            ? "Exceeds 512 channels — bump start address or universe"
                            : ""
                        }
                      >
                        {endAddr || "—"}
                        {overflow && " ⚠"}
                      </td>
                      <td className="fx-total">{totalWt.toFixed(1)}</td>
                      <td className="fx-total">{totalW.toLocaleString()}</td>
                      <td className="fx-actions">
                        <button
                          className="fx-row-btn"
                          onClick={() => onDuplicate(f.id)}
                          title={
                            f.linked
                              ? "Copy as a standalone editable row"
                              : "Duplicate row"
                          }
                          aria-label={
                            f.linked
                              ? "Copy as standalone row"
                              : "Duplicate row"
                          }
                        >
                          ⎘
                        </button>
                        {f.linked ? (
                          <button
                            className="fx-row-btn fx-row-btn-jump"
                            onClick={onJumpToRigging}
                            title="Edit qty/weight on the Rigging Report"
                            aria-label="Edit on Rigging Report"
                          >
                            ↗
                          </button>
                        ) : (
                          <button
                            className="fx-row-btn fx-row-btn-del"
                            onClick={() => onRemove(f.id)}
                            title="Delete row"
                            aria-label="Delete row"
                          >
                            ×
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              {fixtures.length > 0 && (
                <tfoot>
                  <tr>
                    <td colSpan={12} style={{ textAlign: "right" }}>
                      <strong>Totals</strong>
                    </td>
                    <td className="fx-total">{totals.weight.toFixed(1)}</td>
                    <td className="fx-total">
                      {totals.watts.toLocaleString()}
                    </td>
                    <td></td>
                  </tr>
                </tfoot>
              )}
            </table>
          </div>
        )}
        <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <button className="btn btn-soft" onClick={onAddFromLibrary}>
            + From EHS Library
          </button>
          <button className="btn btn-export" onClick={onAdd}>
            + Add Extra Fixture
          </button>
          <span className="lighting-help" style={{ marginLeft: 4 }}>
            Use these for one-off fixtures that aren't on the rigging report.
          </span>
        </div>
      </div>
    </>
  );
}

/* ───────────── Schedule field (compact popover) ─────────────
 * Shows a single trigger pill summarising the production schedule
 * (e.g. "Setup Jun 14 → Downrig Jun 18 · 4 phases"). Clicking the
 * trigger opens a small popover with one row per phase: Setup,
 * Rehearsal, Show, and Downrig. Each row has From/To date inputs.
 * Click-outside or pressing Escape closes the popover. The "Show"
 * phase writes back to reportDate/reportEndDate; the others live in
 * extraSchedule. */

const SCHEDULE_PHASES_ORDER: SchedulePhaseKey[] = [
  "setup",
  "rehearsal",
  "show",
  "downrig",
];

function fmtShortDate(iso: string): string {
  if (!iso) return "";
  const d = new Date(iso + "T00:00:00");
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

function summariseSchedule(
  reportDate: string,
  reportEndDate: string,
  extra: ExtraSchedule,
): { label: string; phaseCount: number } {
  const all: Array<{ key: SchedulePhaseKey; from: string; to: string }> = [];
  if (reportDate || reportEndDate) {
    all.push({
      key: "show",
      from: reportDate,
      to: reportEndDate || reportDate,
    });
  }
  (["setup", "rehearsal", "downrig"] as const).forEach((k) => {
    const ph = extra[k];
    if (ph && (ph.from || ph.to)) all.push({ key: k, from: ph.from, to: ph.to });
  });
  if (all.length === 0) return { label: "Add dates", phaseCount: 0 };
  const fromIso = all
    .map((p) => p.from || p.to)
    .filter(Boolean)
    .sort()[0];
  const toIso = all
    .map((p) => p.to || p.from)
    .filter(Boolean)
    .sort()
    .slice(-1)[0];
  const span =
    fromIso && toIso && fromIso !== toIso
      ? `${fmtShortDate(fromIso)} → ${fmtShortDate(toIso)}`
      : fmtShortDate(fromIso || toIso || "");
  return { label: span, phaseCount: all.length };
}

function ScheduleField({
  reportDate,
  reportEndDate,
  extraSchedule,
  onChangeReportDate,
  onChangeReportEndDate,
  onChangeExtraSchedule,
}: {
  reportDate: string;
  reportEndDate: string;
  extraSchedule: ExtraSchedule;
  onChangeReportDate: (v: string) => void;
  onChangeReportEndDate: (v: string) => void;
  onChangeExtraSchedule: (
    updater: (prev: ExtraSchedule) => ExtraSchedule,
  ) => void;
}) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    // Capture phase so native date pickers can't swallow Escape before us.
    document.addEventListener("keydown", onKey, true);
    return () => {
      document.removeEventListener("keydown", onKey, true);
    };
  }, [open]);

  const summary = summariseSchedule(reportDate, reportEndDate, extraSchedule);

  type PhaseSide = "from" | "to" | "fromTime" | "toTime";

  const setPhase = (key: SchedulePhaseKey, side: PhaseSide, value: string) => {
    // The show phase routes its calendar dates to reportDate/reportEndDate
    // and its times into extraSchedule.show (alongside empty date strings).
    if (key === "show" && side === "from") {
      onChangeReportDate(value);
      if (reportEndDate && value && reportEndDate < value) {
        onChangeReportEndDate(value);
      }
      return;
    }
    if (key === "show" && side === "to") {
      onChangeReportEndDate(value);
      return;
    }
    onChangeExtraSchedule((prev) => {
      const current: SchedulePhase = prev[key] ?? {
        from: "",
        to: "",
        fromTime: "",
        toTime: "",
      };
      const next: SchedulePhase = { ...current, [side]: value };
      // Auto-bump "to" forward if user pushed "from" past it (dates only).
      if (side === "from" && next.to && value && next.to < value) {
        next.to = value;
      }
      const isEmpty =
        !next.from && !next.to && !next.fromTime && !next.toTime;
      const out: ExtraSchedule = { ...prev };
      if (isEmpty) {
        delete out[key];
      } else {
        out[key] = next;
      }
      return out;
    });
  };

  const getPhase = (key: SchedulePhaseKey): SchedulePhase => {
    const stored = extraSchedule[key];
    if (key === "show") {
      return {
        from: reportDate,
        to: reportEndDate,
        fromTime: stored?.fromTime ?? "",
        toTime: stored?.toTime ?? "",
      };
    }
    return stored ?? { from: "", to: "", fromTime: "", toTime: "" };
  };

  const clearAll = () => {
    onChangeReportDate(new Date().toISOString().slice(0, 10));
    onChangeReportEndDate("");
    onChangeExtraSchedule(() => ({}));
  };

  return (
    <div style={{ position: "relative" }}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-haspopup="dialog"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 8,
          width: "100%",
          padding: "9px 10px",
          border: "1px solid var(--border-color)",
          borderRadius: 8,
          background: "var(--input-bg)",
          color: "var(--text-main)",
          font: "inherit",
          fontWeight: 600,
          fontSize: 14,
          cursor: "pointer",
          textAlign: "left",
        }}
      >
        <span
          style={{
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
          }}
        >
          {summary.label}
          {summary.phaseCount > 1 ? (
            <span
              style={{
                marginLeft: 6,
                fontSize: 11,
                fontWeight: 700,
                color: "var(--text-muted)",
              }}
            >
              · {summary.phaseCount} phases
            </span>
          ) : null}
        </span>
        <span
          aria-hidden
          style={{
            opacity: 0.6,
            transform: open ? "rotate(180deg)" : "none",
            transition: "transform 120ms",
          }}
        >
          ▾
        </span>
      </button>
      {open ? (
        <>
          {/* Transparent click-catcher: closes the popover on any
           *  click outside the dialog without depending on document
           *  event delegation. */}
          <div
            onMouseDown={() => setOpen(false)}
            aria-hidden
            style={{
              position: "fixed",
              inset: 0,
              zIndex: 49,
              background: "transparent",
            }}
          />
          <div
            role="dialog"
            aria-label="Project schedule"
            onMouseDown={(e) => e.stopPropagation()}
            style={{
              position: "absolute",
              top: "calc(100% + 6px)",
              left: 0,
              zIndex: 50,
            minWidth: 360,
            maxWidth: 460,
            padding: 12,
            background: "var(--card-bg)",
            border: "1px solid var(--border-color)",
            borderRadius: 10,
            boxShadow: "0 10px 30px rgba(0,0,0,0.18)",
            display: "grid",
            gap: 8,
          }}
        >
          {SCHEDULE_PHASES_ORDER.map((key) => {
            const ph = getPhase(key);
            const inputStyle = {
              padding: "6px 8px",
              border: "1px solid var(--border-color)",
              borderRadius: 6,
              background: "var(--input-bg)",
              color: "var(--text-main)",
              font: "inherit",
              fontSize: 13,
              width: "100%",
            } as const;
            const arrowStyle = {
              color: "var(--text-muted)",
              textAlign: "center" as const,
              fontSize: 12,
            };
            const subLabelStyle = {
              fontSize: 10,
              fontWeight: 700,
              textTransform: "uppercase" as const,
              letterSpacing: 0.3,
              color: "var(--text-muted)",
              opacity: 0.8,
            };
            return (
              <div
                key={key}
                style={{
                  display: "grid",
                  gridTemplateColumns: "84px 1fr",
                  alignItems: "start",
                  gap: 8,
                  paddingBottom: 4,
                }}
              >
                <span
                  style={{
                    fontSize: 11,
                    fontWeight: 800,
                    textTransform: "uppercase",
                    letterSpacing: 0.4,
                    color: "var(--text-muted)",
                    paddingTop: 8,
                  }}
                >
                  {SCHEDULE_PHASE_LABELS[key]}
                </span>
                <div style={{ display: "grid", gap: 6 }}>
                  {/* Date row */}
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "32px 1fr 14px 1fr",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                    <span style={subLabelStyle}>Day</span>
                    <input
                      type="date"
                      value={ph.from}
                      aria-label={`${SCHEDULE_PHASE_LABELS[key]} from`}
                      onChange={(e) => setPhase(key, "from", e.target.value)}
                      style={inputStyle}
                    />
                    <span aria-hidden style={arrowStyle}>
                      →
                    </span>
                    <input
                      type="date"
                      value={ph.to}
                      min={ph.from || undefined}
                      aria-label={`${SCHEDULE_PHASE_LABELS[key]} to`}
                      onChange={(e) => setPhase(key, "to", e.target.value)}
                      style={inputStyle}
                    />
                  </div>
                  {/* Time row */}
                  <div
                    style={{
                      display: "grid",
                      gridTemplateColumns: "32px 1fr 14px 1fr",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                    <span style={subLabelStyle}>Time</span>
                    <input
                      type="time"
                      value={ph.fromTime ?? ""}
                      aria-label={`${SCHEDULE_PHASE_LABELS[key]} start time`}
                      onChange={(e) =>
                        setPhase(key, "fromTime", e.target.value)
                      }
                      style={inputStyle}
                    />
                    <span aria-hidden style={arrowStyle}>
                      →
                    </span>
                    <input
                      type="time"
                      value={ph.toTime ?? ""}
                      aria-label={`${SCHEDULE_PHASE_LABELS[key]} end time`}
                      onChange={(e) =>
                        setPhase(key, "toTime", e.target.value)
                      }
                      style={inputStyle}
                    />
                  </div>
                </div>
              </div>
            );
          })}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginTop: 6,
              paddingTop: 8,
              borderTop: "1px dashed var(--border-color)",
            }}
          >
            <button
              type="button"
              onClick={clearAll}
              style={{
                background: "transparent",
                border: "none",
                color: "var(--text-muted)",
                fontSize: 12,
                cursor: "pointer",
                padding: "4px 6px",
              }}
            >
              Reset schedule
            </button>
            <button
              type="button"
              onClick={() => setOpen(false)}
              style={{
                background: "var(--primary)",
                color: "white",
                border: "none",
                borderRadius: 6,
                padding: "6px 14px",
                fontWeight: 700,
                fontSize: 13,
                cursor: "pointer",
              }}
            >
              Done
            </button>
          </div>
          </div>
        </>
      ) : null}
    </div>
  );
}

export default App;
