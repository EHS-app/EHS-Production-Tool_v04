# EHS Rigging Load Report

  A standalone React + Vite calculator for rigging load reports.

  ## Run locally
  1. Install Node.js 18+ and pnpm (`npm install -g pnpm`) or use npm.
  2. From this folder:
     ```
     pnpm install      # or: npm install
     pnpm dev          # or: npm run dev
     ```
  3. Open the URL printed in the terminal (default http://localhost:5173).

  ## Build for production
  ```
  pnpm build          # or: npm run build
  pnpm preview        # serve the built bundle
  ```

  ## What's inside
  - `src/App.tsx` — main React component (UI, state, calculations, CSV/PDF export)
  - `src/index.css` — all styling (light/dark themes, print layout)
  - `index.html` — Vite entry point
  - `vite.config.ts` — Vite config
  - `package.json` — dependencies and scripts

  The app stores reports in your browser's localStorage under the key `ehs-rigging-report-v2`.
  